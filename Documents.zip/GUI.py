"""GUI frontend for the USB Universal Tester host utilities.

This application discovers an attached Arduino Due over serial, locks it into
listen mode, and exposes higher-level tooling for interacting with the
firmware's CLI endpoints defined in Database::handleSerialCommands().
"""

from __future__ import annotations

import csv
import io
import queue
import re
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PyQt5 import QtCore, QtGui, QtWidgets

try:
    import serial  # type: ignore
    import serial.tools.list_ports  # type: ignore
except ImportError as exc:  # pragma: no cover - handled at runtime
    raise SystemExit(
        "pyserial is required to run this tool. Install it with 'pip install pyserial'."
    ) from exc


APP_WIDTH = 1024
APP_HEIGHT = 800
CLI_HEIGHT = 200
BAUDRATE = 115200
HANDSHAKE = "£££"
COMMANDS = ["GETLOG", "ERASELOG", "GETCOUNTERS", "SAVECTR"]
LOG_LEVELS = ["DBG", "INFO", "WARN", "ERROR", "ALERT"]
LOG_DIR = Path("logs")
DEBUG_DIR = Path("debug")
COUNTS_DIR = Path("counts")
PRODUCT_DIR = Path("product_data")

for _dir in (LOG_DIR, DEBUG_DIR, COUNTS_DIR, PRODUCT_DIR):
    _dir.mkdir(parents=True, exist_ok=True)


COUNTER_METADATA: Dict[int, Tuple[str, str]] = {
    0: ("Pass Count", "Total number of USB units that passed all tests."),
    1: ("Fail: Voltage", "Units that failed due to incorrect voltage window."),
    2: ("Fail: Current", "Units that failed due to current draw issues."),
    3: ("Fail: Connector", "Units that failed connector ID verification."),
    4: ("Fail: PD", "Units that failed USB-C PD negotiation."),
    5: ("Fail: QC", "Units that failed Qualcomm QC negotiation."),
    6: ("Fail: Reverse", "Units tripping reverse polarity protections."),
    7: ("Fail: Thermal", "Units exceeding allowed thermal rise."),
    8: ("Rework", "Units flagged for manual rework."),
    9: ("Retest", "Units queued for retest after firmware push."),
}

ROW_INFO_TEXT = {
    "DBG": "Debug log entry – verbose diagnostic output.",
    "INFO": "Informational log entry.",
    "WARN": "Warning – unexpected but non-fatal event.",
    "ERROR": "Error – test flow failed and requires operator attention.",
    "ALERT": "Alert – safety critical or hardware protection triggered.",
}


@dataclass
class TableRow:
    timestamp: str
    level: str
    source: str
    message: str

    def as_list(self) -> List[str]:
        return [self.timestamp, self.level, self.source, self.message]


class SerialWorker(QtCore.QThread):
    """Background worker that owns the pyserial connection."""

    dataReceived = QtCore.pyqtSignal(str)
    status = QtCore.pyqtSignal(str)
    connected = QtCore.pyqtSignal(str)
    disconnected = QtCore.pyqtSignal()

    def __init__(self, baudrate: int = BAUDRATE, timeout: float = 0.1, parent: Optional[QtCore.QObject] = None):
        super().__init__(parent)
        self.baudrate = baudrate
        self.timeout = timeout
        self.write_queue: "queue.Queue[bytes]" = queue.Queue()
        self._serial: Optional[serial.Serial] = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._handshake_bytes = HANDSHAKE.encode("utf-8")
        self._awaiting_response = False

    def stop(self) -> None:
        self._stop_event.set()
        self.wait(2000)

    def run(self) -> None:  # pragma: no cover - continuous loop
        while not self._stop_event.is_set():
            if not self._serial or not self._serial.is_open:
                self._attempt_connection_cycle()
                continue

            self._flush_outgoing()
            self._pump_incoming()
            self.msleep(10)
        self._teardown()

    def send(self, payload: str) -> None:
        if not payload:
            return
        data = payload.encode("utf-8")
        self.write_queue.put(data)

    def _teardown(self) -> None:
        with self._lock:
            if self._serial and self._serial.is_open:
                try:
                    self._serial.close()
                except serial.SerialException:
                    pass
                finally:
                    self._serial = None

    def _attempt_connection_cycle(self) -> None:
        candidates = list(serial.tools.list_ports.comports())
        filtered = [p for p in candidates if self._looks_like_due(p)]
        if not filtered:
            filtered = candidates
        for port in filtered:
            if self._stop_event.is_set():
                return
            ser: Optional[serial.Serial] = None
            try:
                self.status.emit(f"Trying {port.device} ...")
                ser = serial.Serial(port.device, self.baudrate, timeout=self.timeout)
                time.sleep(0.05)
                ser.reset_input_buffer()
                ser.reset_output_buffer()
                ser.write(self._handshake_bytes)
                ser.flush()
                replied = self._await_handshake_response(ser)
                if not replied:
                    ser.close()
                    continue
                with self._lock:
                    self._serial = ser
                self.status.emit(f"Connected to {port.device}")
                self.connected.emit(port.device)
                break
            except (serial.SerialException, OSError) as exc:
                self.status.emit(f"Port {port.device} error: {exc}")
                if ser:
                    try:
                        ser.close()
                    except Exception:
                        pass
        else:
            self.status.emit("No suitable serial device detected. Retrying in 2s ...")
            self.msleep(2000)

    def _await_handshake_response(self, ser: serial.Serial) -> bool:
        deadline = time.time() + 0.75
        while time.time() < deadline and not self._stop_event.is_set():
            if ser.in_waiting:
                try:
                    data = ser.readline()
                except serial.SerialException:
                    return False
                if data:
                    self.dataReceived.emit(data.decode(errors="ignore"))
                    return True
            self.msleep(20)
        return False

    def _flush_outgoing(self) -> None:
        if not self._serial:
            return
        while not self.write_queue.empty():
            payload = self.write_queue.get()
            try:
                self._serial.write(payload)
                self._serial.flush()
            except serial.SerialException as exc:
                self.status.emit(f"Serial write failed: {exc}")
                self._handle_disconnect()
                break

    def _pump_incoming(self) -> None:
        if not self._serial:
            return
        try:
            if self._serial.in_waiting:
                incoming = self._serial.readline()
                if incoming:
                    self.dataReceived.emit(incoming.decode(errors="ignore"))
        except serial.SerialException as exc:
            self.status.emit(f"Serial read failed: {exc}")
            self._handle_disconnect()

    def _handle_disconnect(self) -> None:
        with self._lock:
            if self._serial:
                try:
                    self._serial.close()
                except serial.SerialException:
                    pass
                finally:
                    self._serial = None
        self.disconnected.emit()

    @staticmethod
    def _looks_like_due(port: serial.tools.list_ports_common.ListPortInfo) -> bool:
        description = (port.description or "").lower()
        manufacturer = (getattr(port, "manufacturer", "") or "").lower()
        hwid = (port.hwid or "").lower()
        return any(
            keyword in text
            for keyword in ("due", "arduino", "native usb", "sam3x", "usb serial device")
            for text in (description, manufacturer, hwid)
        )


class ProductDataView(QtWidgets.QWidget):
    updateRequested = QtCore.pyqtSignal(list, list)

    def __init__(self, parent: Optional[QtWidgets.QWidget] = None) -> None:
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        header = QtWidgets.QHBoxLayout()
        self.statusLabel = QtWidgets.QLabel("Awaiting product data ...")
        header.addWidget(self.statusLabel)
        header.addStretch(1)
        self.sendButton = QtWidgets.QPushButton("Send Updates")
        self.sendButton.setEnabled(False)
        self.sendButton.clicked.connect(self._emit_updates)
        header.addWidget(self.sendButton)
        layout.addLayout(header)

        self.table = QtWidgets.QTableWidget(0, 0)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.AllEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table)

    def load_csv(self, headers: List[str], rows: List[List[str]]) -> None:
        self.table.clear()
        self.table.setRowCount(len(rows))
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                item = QtWidgets.QTableWidgetItem(value)
                self.table.setItem(r, c, item)
        self.statusLabel.setText(f"Loaded {len(rows)} product rows")
        self.sendButton.setEnabled(True)

    def _emit_updates(self) -> None:
        headers = [self.table.horizontalHeaderItem(i).text() for i in range(self.table.columnCount())]
        rows: List[List[str]] = []
        for row in range(self.table.rowCount()):
            row_data = []
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                row_data.append(item.text() if item else "")
            rows.append(row_data)
        self.updateRequested.emit(headers, rows)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("USB Universal Tester Console")
        self.resize(APP_WIDTH, APP_HEIGHT)

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root = QtWidgets.QVBoxLayout(central)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(6)

        self.tabButton = QtWidgets.QPushButton("View Product Data")
        self.tabButton.setCheckable(True)
        self.tabButton.toggled.connect(self._toggle_tab)

        topBar = QtWidgets.QHBoxLayout()
        topBar.addWidget(QtWidgets.QLabel("Options"))
        topBar.addStretch(1)
        topBar.addWidget(self.tabButton)
        root.addLayout(topBar)

        # stacked views
        self.stack = QtWidgets.QStackedWidget()
        root.addWidget(self.stack, stretch=1)

        self.dashboardWidget = QtWidgets.QWidget()
        self.stack.addWidget(self.dashboardWidget)
        self.productView = ProductDataView()
        self.stack.addWidget(self.productView)
        self.productView.updateRequested.connect(self._send_product_updates)

        self._build_dashboard()

        # CLI command buttons along bottom
        self.cliOutput = QtWidgets.QPlainTextEdit()
        self.cliOutput.setReadOnly(True)
        self.cliOutput.setMaximumBlockCount(2000)
        self.cliOutput.setStyleSheet("background:#0c0c0c;color:#d0f0d0;font-family:Consolas;font-size:12px;")
        self.cliInput = QtWidgets.QLineEdit()
        self.cliInput.setPlaceholderText("Enter serial command and press Enter...")
        self.cliInput.returnPressed.connect(self._handle_cli_enter)

        cliFrame = QtWidgets.QFrame()
        cliFrame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        cliLayout = QtWidgets.QVBoxLayout(cliFrame)
        cliLayout.setContentsMargins(4, 4, 4, 4)
        cliLayout.addWidget(self.cliOutput, stretch=1)
        cliLayout.addWidget(self.cliInput)
        cliFrame.setMinimumHeight(CLI_HEIGHT)
        cliFrame.setMaximumHeight(CLI_HEIGHT)

        root.addWidget(cliFrame)

        buttonBar = QtWidgets.QHBoxLayout()
        for cmd in COMMANDS:
            btn = QtWidgets.QPushButton(cmd)
            btn.setProperty("command", cmd)
            btn.clicked.connect(self._handle_command_button)
            buttonBar.addWidget(btn)
        root.addLayout(buttonBar)

        # Serial worker
        self.serialWorker = SerialWorker()
        self.serialWorker.dataReceived.connect(self._handle_serial_data)
        self.serialWorker.status.connect(self._append_status)
        self.serialWorker.connected.connect(self._handle_connected)
        self.serialWorker.disconnected.connect(self._handle_disconnected)
        self.serialWorker.start()

        # state
        self.awaiting_log = False
        self.capturing_log = False
        self.log_buffer: List[str] = []
        self.log_errors: List[str] = []
        self.log_rows: List[TableRow] = []
        self.level_visibility = {lvl: True for lvl in LOG_LEVELS}
        self.awaiting_counters = False
        self.counter_buffer: List[Tuple[int, int]] = []
        self.counter_total: int = 0
        self.awaiting_erase_ack = False
        self.awaiting_savectr = False
        self.savectr_buffer: List[str] = []
        self.awaiting_productdata = False
        self.collecting_product_lines: List[str] = []
        self.expanded_row: Optional[int] = None

    def _build_dashboard(self) -> None:
        layout = QtWidgets.QVBoxLayout(self.dashboardWidget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        self.topFilterButtons = self._create_filter_row("Top Filters")
        layout.addLayout(self.topFilterButtons)

        splitter = QtWidgets.QSplitter(QtCore.Qt.Horizontal)
        layout.addWidget(splitter, stretch=1)

        leftPane = QtWidgets.QWidget()
        leftLayout = QtWidgets.QVBoxLayout(leftPane)
        leftLayout.setContentsMargins(0, 0, 0, 0)
        leftLayout.setSpacing(4)

        self.tableFilterButtons = self._create_filter_row("Table Filters")
        leftLayout.addLayout(self.tableFilterButtons)

        self.table = QtWidgets.QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Timestamp", "Level", "Source", "Message"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self._handle_row_selection)
        self.table.verticalHeader().setVisible(False)
        leftLayout.addWidget(self.table, stretch=1)

        splitter.addWidget(leftPane)

        rightPane = QtWidgets.QWidget()
        rightLayout = QtWidgets.QVBoxLayout(rightPane)
        rightLayout.setContentsMargins(4, 4, 4, 4)
        rightLayout.setSpacing(6)
        rightLayout.addWidget(QtWidgets.QLabel("Counters"))

        self.counterBoxes: List[Tuple[QtWidgets.QLabel, QtWidgets.QLineEdit]] = []
        for idx in range(10):
            box = QtWidgets.QGroupBox(f"Metric {idx}")
            v = QtWidgets.QVBoxLayout(box)
            label = QtWidgets.QLabel("Value")
            edit = QtWidgets.QLineEdit("0")
            edit.setReadOnly(True)
            edit.setAlignment(QtCore.Qt.AlignCenter)
            edit.setStyleSheet("font-weight:bold;font-size:16px;")
            v.addWidget(label)
            v.addWidget(edit)
            rightLayout.addWidget(box)
            self.counterBoxes.append((label, edit))
        rightLayout.addStretch(1)
        splitter.addWidget(rightPane)
        rightPane.setFixedWidth(140)
        splitter.setSizes([splitter.width() - 120, 120])

    def _create_filter_row(self, name: str) -> QtWidgets.QHBoxLayout:
        layout = QtWidgets.QHBoxLayout()
        layout.addWidget(QtWidgets.QLabel(name))
        for level in LOG_LEVELS:
            btn = QtWidgets.QPushButton(level)
            btn.setCheckable(True)
            btn.setChecked(True)
            btn.setProperty("level", level)
            btn.clicked.connect(self._handle_filter_toggle)
            layout.addWidget(btn)
        layout.addStretch(1)
        return layout

    def _append_status(self, text: str) -> None:
        self.cliOutput.appendPlainText(f"[STATUS] {text.strip()}")

    def _handle_connected(self, port: str) -> None:
        self.cliOutput.appendPlainText(f"Connected to {port}")
        self.serialWorker.send(HANDSHAKE)

    def _handle_disconnected(self) -> None:
        self.cliOutput.appendPlainText("Serial disconnected. Attempting reconnect ...")

    def _handle_serial_data(self, payload: str) -> None:
        if not payload:
            return
        self.cliOutput.appendPlainText(payload.rstrip("\n"))
        stripped = payload.strip()
        if self.awaiting_savectr and stripped:
            self.savectr_buffer.append(stripped)
        if not stripped:
            if self.awaiting_counters and self.counter_buffer:
                self._finalize_counters()
            if self.awaiting_savectr and self.savectr_buffer:
                self._finalize_savectr()
            if self.awaiting_productdata and self.collecting_product_lines:
                self._finalize_productdata()
            return

        if self.awaiting_log and stripped == "=== LOG DUMP START ===":
            self.capturing_log = True
            self.log_buffer.clear()
            self.log_errors.clear()
            return
        if self.capturing_log:
            if stripped == "=== LOG DUMP END ===":
                self.capturing_log = False
                self.awaiting_log = False
                self._persist_log_capture()
                return
            self.log_buffer.append(payload.rstrip("\n"))
            if any(token in payload for token in ("ERR", "ERROR", "ALT", "ALERT")):
                self.log_errors.append(payload.rstrip("\n"))
            return

        if stripped.startswith("Counters:"):
            self.awaiting_counters = True
            self.counter_buffer.clear()
            return
        if self.awaiting_counters and self._parse_counter_line(stripped):
            return

        if stripped == "Logs erased" and self.awaiting_erase_ack:
            self.awaiting_erase_ack = False
            QtWidgets.QMessageBox.information(self, "Erase Logs", "Logs erased successfully.")
            self._clear_data_views()
            return

        if "Counters saved" in stripped and self.awaiting_savectr:
            self._finalize_savectr()
            return

        if self.awaiting_productdata:
            if stripped.startswith("=== PRODUCTDATA END"):
                self._finalize_productdata()
            elif "," in stripped:
                self.collecting_product_lines.append(stripped)
            return

        if stripped.lower().startswith("unknown command") and self.awaiting_productdata:
            self.awaiting_productdata = False
            self.collecting_product_lines.clear()

    def _parse_counter_line(self, line: str) -> bool:
        match = re.match(r"^C(\d+):\s*(-?\d+)$", line)
        if match:
            idx = int(match.group(1))
            value = int(match.group(2))
            self.counter_buffer.append((idx, value))
            return True
        if line.startswith("Counters"):
            return True
        if self.counter_buffer and not line.startswith("C"):
            self._finalize_counters()
            return True
        return False

    def _finalize_counters(self) -> None:
        self.awaiting_counters = False
        data = dict(self.counter_buffer)
        self.counter_total = sum(max(v, 0) for v in data.values()) or 1
        for pos, (label, edit) in enumerate(self.counterBoxes):
            meta = COUNTER_METADATA.get(pos, (f"Counter {pos}", ""))
            label.setText(meta[0])
            edit.setText(str(data.get(pos, 0)))
        rows: List[TableRow] = []
        for idx, value in sorted(data.items()):
            name, desc = COUNTER_METADATA.get(idx, (f"Counter {idx}", ""))
            percent = 100.0 * value / self.counter_total
            rows.append(
                TableRow(
                    timestamp=str(idx),
                    level=f"{percent:.1f}%",
                    source=name,
                    message=desc or "Counter aggregate",
                )
            )
        self._load_rows(rows)
        self.cliOutput.appendPlainText("Counters updated.")

    def _finalize_savectr(self) -> None:
        self.awaiting_savectr = False
        if not self.savectr_buffer:
            return
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = self._write_unique_file(COUNTS_DIR, f"counts_{timestamp}", "txt")
        path.write_text("\n".join(self.savectr_buffer), encoding="utf-8")
        QtWidgets.QMessageBox.information(self, "Save Counters", f"Counters saved to {path}")
        self.savectr_buffer.clear()

    def _clear_data_views(self) -> None:
        self.table.setRowCount(0)
        self.log_rows.clear()
        for _, edit in self.counterBoxes:
            edit.setText("0")

    def _persist_log_capture(self) -> None:
        if not self.log_buffer:
            return
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        debug_path = DEBUG_DIR / f"debug_{timestamp}.txt"
        debug_path.write_text("\n".join(self.log_buffer), encoding="utf-8")

        errors_path = self._write_unique_file(LOG_DIR, f"log_{timestamp}", "txt")
        errors_path.write_text("\n".join(self.log_errors), encoding="utf-8")

        self.cliOutput.appendPlainText(f"Log captured to {debug_path} (errors -> {errors_path})")
        self._load_debug_file(debug_path)
        for level in LOG_LEVELS:
            enabled = level in ("ERROR", "ALERT")
            self.level_visibility[level] = enabled
        self._refresh_filter_buttons()
        self._apply_log_filters()

    def _load_debug_file(self, path: Path) -> None:
        rows: List[TableRow] = []
        pattern = re.compile(r"^\[(RAM|FLASH)\s+(\d+)\]\s+(DBG|INF|WRN|ERR|ALT):\s+(.*)$")
        with path.open("r", encoding="utf-8", errors="ignore") as fh:
            for line in fh:
                match = pattern.match(line.strip())
                if not match:
                    continue
                source = match.group(1)
                timestamp = match.group(2)
                level = match.group(3)
                message = match.group(4)
                level = self._normalise_level(level)
                rows.append(TableRow(timestamp=timestamp, level=level, source=source, message=message))
        self._load_rows(rows)

    def _normalise_level(self, token: str) -> str:
        mapping = {"DBG": "DBG", "INF": "INFO", "WRN": "WARN", "ERR": "ERROR", "ALT": "ALERT"}
        return mapping.get(token, token)

    def _load_rows(self, rows: List[TableRow]) -> None:
        self.log_rows = rows
        self.expanded_row = None
        self._apply_log_filters()

    def _apply_log_filters(self) -> None:
        filtered = [row for row in self.log_rows if self.level_visibility.get(row.level, True)]
        self.table.setRowCount(len(filtered))
        for r, row in enumerate(filtered):
            for c, value in enumerate(row.as_list()):
                item = QtWidgets.QTableWidgetItem(value)
                item.setData(QtCore.Qt.UserRole, row)
                self.table.setItem(r, c, item)
        self.table.resizeRowsToContents()

    def _handle_filter_toggle(self) -> None:
        button = self.sender()
        if not isinstance(button, QtWidgets.QPushButton):
            return
        level = button.property("level")
        if level in self.level_visibility:
            self.level_visibility[level] = button.isChecked()
            self._apply_log_filters()
            self._sync_filter_buttons(level, button.isChecked())

    def _refresh_filter_buttons(self) -> None:
        for layout in (self.topFilterButtons, self.tableFilterButtons):
            for idx in range(layout.count()):
                widget = layout.itemAt(idx).widget()
                if isinstance(widget, QtWidgets.QPushButton) and widget.property("level"):
                    level = widget.property("level")
                    widget.setChecked(self.level_visibility.get(level, True))

    def _sync_filter_buttons(self, level: str, state: bool) -> None:
        for layout in (self.topFilterButtons, self.tableFilterButtons):
            for idx in range(layout.count()):
                widget = layout.itemAt(idx).widget()
                if isinstance(widget, QtWidgets.QPushButton) and widget.property("level") == level:
                    if widget.isChecked() != state:
                        widget.blockSignals(True)
                        widget.setChecked(state)
                        widget.blockSignals(False)

    def _handle_cli_enter(self) -> None:
        text = self.cliInput.text().strip()
        self.cliInput.clear()
        if not text:
            return
        payload = text
        bare = text.lstrip("£")
        is_command = bare.upper() in COMMANDS
        if is_command and not text.startswith("£"):
            payload = f"£{bare}"
        payload += "\n"
        if is_command:
            self._handle_command_state(bare.upper())
        self.serialWorker.send(payload)
        self.cliOutput.appendPlainText(f"> {payload.strip()}")

    def _handle_command_button(self) -> None:
        button = self.sender()
        if not isinstance(button, QtWidgets.QPushButton):
            return
        cmd = button.property("command")
        if cmd:
            self._send_command(cmd)

    def _send_command(self, command: str) -> None:
        if command == "ERASELOG":
            response = QtWidgets.QMessageBox.question(
                self,
                "Erase Logs",
                "Are you sure you want to erase logs?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No,
            )
            if response != QtWidgets.QMessageBox.Yes:
                return
            self.awaiting_erase_ack = True
        if command == "SAVECTR":
            self.awaiting_savectr = True
            self.savectr_buffer.clear()
        self._handle_command_state(command)
        payload = f"£{command}\n"
        self.serialWorker.send(payload)
        self.cliOutput.appendPlainText(f"> {command}")

    def _handle_command_state(self, command: str) -> None:
        if command == "GETLOG":
            self.awaiting_log = True
            self.log_buffer.clear()
            self.log_errors.clear()
        elif command == "GETCOUNTERS":
            self.awaiting_counters = True
            self.counter_buffer.clear()
        elif command == "ERASELOG":
            self.awaiting_erase_ack = True
        elif command == "SAVECTR":
            self.awaiting_savectr = True
            self.savectr_buffer.clear()

    def _handle_row_selection(self) -> None:
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            self._collapse_expanded_row()
            return
        logical_row = selected_rows[0].row()
        item = self.table.item(logical_row, 0)
        if not item:
            return
        data = item.data(QtCore.Qt.UserRole)
        if not isinstance(data, TableRow):
            return
        info = ROW_INFO_TEXT.get(data.level, data.message)
        self._expand_row(logical_row, info)

    def _collapse_expanded_row(self) -> None:
        if self.expanded_row is None:
            return
        if self.expanded_row + 1 < self.table.rowCount():
            self.table.removeRow(self.expanded_row + 1)
        self.expanded_row = None

    def _expand_row(self, base_row: int, info: str) -> None:
        self._collapse_expanded_row()
        insert_at = base_row + 1
        self.table.insertRow(insert_at)
        item = QtWidgets.QTableWidgetItem(info)
        item.setFlags(QtCore.Qt.ItemIsEnabled)
        item.setForeground(QtGui.QBrush(QtGui.QColor("#555")))
        self.table.setItem(insert_at, 0, item)
        self.table.setSpan(insert_at, 0, 1, self.table.columnCount())
        self.expanded_row = base_row

    def _write_unique_file(self, directory: Path, base: str, ext: str) -> Path:
        idx = 0
        while True:
            suffix = f"_{idx}" if idx else ""
            candidate = directory / f"{base}{suffix}.{ext}"
            if not candidate.exists():
                return candidate
            idx += 1

    def _toggle_tab(self, checked: bool) -> None:
        self.stack.setCurrentIndex(1 if checked else 0)
        self.tabButton.setText("View Dashboard" if checked else "View Product Data")
        if checked:
            self._request_product_data()

    def _request_product_data(self) -> None:
        self.awaiting_productdata = True
        self.collecting_product_lines.clear()
        self.serialWorker.send("£PRODUCTDATA\n")
        self.cliOutput.appendPlainText(
            "Requested product data. Waiting for CSV stream (terminate with blank line)."
        )

    def _finalize_productdata(self) -> None:
        self.awaiting_productdata = False
        if not self.collecting_product_lines:
            self.productView.statusLabel.setText("No product data received yet.")
            return
        reader = csv.reader(io.StringIO("\n".join(self.collecting_product_lines)))
        rows = list(reader)
        if not rows:
            return
        headers = rows[0]
        data_rows = rows[1:]
        self.productView.load_csv(headers, data_rows)
        path = PRODUCT_DIR / f"product_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        with path.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(headers)
            writer.writerows(data_rows)
        self.cliOutput.appendPlainText(f"Product data saved to {path}")
        self.collecting_product_lines.clear()

    def _send_product_updates(self, headers: List[str], rows: List[List[str]]) -> None:
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(headers)
        writer.writerows(rows)
        payload = buffer.getvalue().strip().splitlines()
        self.serialWorker.send("£PRODUCTDATA\n")
        for line in payload:
            self.serialWorker.send(line + "\n")
        self.serialWorker.send("\n")
        self.cliOutput.appendPlainText("Pushed updated product data to device.")

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:  # pragma: no cover - UI callback
        self.serialWorker.stop()
        super().closeEvent(event)


def main() -> None:
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":  # pragma: no cover
    main()
