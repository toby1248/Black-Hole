"""Tkinter implementation of the USB Universal Tester host GUI.

Only depends on tkinter (bundled) and pyserial. Provides the same workflows
as the PyQt-based GUI.
"""

from __future__ import annotations

import csv
import io
import queue
import re
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import messagebox, ttk

try:
    import serial  # type: ignore
    import serial.tools.list_ports  # type: ignore
except ImportError as exc:  # pragma: no cover
    raise SystemExit("pyserial is required. Install with 'pip install pyserial'.") from exc

APP_WIDTH = 1024
APP_HEIGHT = 800
CLI_HEIGHT = 200
BAUDRATE = 115200
HANDSHAKE = "£££"
COMMANDS = ["GETLOG", "ERASELOG", "GETCOUNTERS", "SAVECTR"]
LOG_LEVELS = ["DBG", "INFO", "WARN", "ERROR", "ALERT"]
LOG_DIR = Path("logs")
DEBUG_DIR = Path("debug")
COUNTS_DIR = Path("counts")
PRODUCT_DIR = Path("product_data")

for directory in (LOG_DIR, DEBUG_DIR, COUNTS_DIR, PRODUCT_DIR):
    directory.mkdir(parents=True, exist_ok=True)

COUNTER_METADATA: Dict[int, Tuple[str, str]] = {
    0: ("Pass Count", "Units that passed all tests."),
    1: ("Fail Voltage", "Failed due to voltage window issues."),
    2: ("Fail Current", "Failed due to current draw."),
    3: ("Fail Conn", "Failed connector ID check."),
    4: ("Fail PD", "Failed USB-C PD negotiation."),
    5: ("Fail QC", "Failed QC negotiation."),
    6: ("Fail Reverse", "Reverse polarity issues."),
    7: ("Fail Thermal", "Thermal faults."),
    8: ("Rework", "Units flagged for rework."),
    9: ("Retest", "Units queued for retest."),
}

ROW_INFO_TEXT = {
    "DBG": "Verbose debug diagnostic entry.",
    "INFO": "Informational entry.",
    "WARN": "Warning – unexpected but non-fatal.",
    "ERROR": "Error – test flow failure.",
    "ALERT": "Alert – safety critical event.",
}


@dataclass
class TableRow:
    timestamp: str
    level: str
    source: str
    message: str


class SerialWorker(threading.Thread):
    def __init__(self, baudrate: int = BAUDRATE, timeout: float = 0.1) -> None:
        super().__init__(daemon=True)
        self.baudrate = baudrate
        self.timeout = timeout
        self._serial: Optional[serial.Serial] = None
        self._stop_event = threading.Event()
        self.write_queue: "queue.Queue[str]" = queue.Queue()
        self.result_queue: "queue.Queue[Tuple[str, str]]" = queue.Queue()

    def stop(self) -> None:
        self._stop_event.set()
        self.join(timeout=2)

    def run(self) -> None:  # pragma: no cover
        while not self._stop_event.is_set():
            if not self._serial or not self._serial.is_open:
                self._connect_cycle()
                continue
            self._handle_writes()
            self._handle_reads()
            time.sleep(0.01)
        self._close_serial()

    def send(self, payload: str) -> None:
        self.write_queue.put(payload)

    def _emit(self, kind: str, payload: str) -> None:
        self.result_queue.put((kind, payload))

    def _close_serial(self) -> None:
        if self._serial:
            try:
                self._serial.close()
            except serial.SerialException:
                pass
            self._serial = None

    def _connect_cycle(self) -> None:
        ports = list(serial.tools.list_ports.comports())
        filtered = [p for p in ports if self._looks_like_due(p)] or ports
        for port in filtered:
            if self._stop_event.is_set():
                return
            ser: Optional[serial.Serial] = None
            try:
                self._emit("status", f"Trying {port.device}...")
                ser = serial.Serial(port.device, self.baudrate, timeout=self.timeout)
                time.sleep(0.05)
                ser.reset_input_buffer()
                ser.reset_output_buffer()
                ser.write(HANDSHAKE.encode("utf-8"))
                ser.flush()
                if self._wait_for_response(ser):
                    self._serial = ser
                    self._emit("status", f"Connected to {port.device}")
                    self._emit("connected", port.device)
                    return
                ser.close()
            except (serial.SerialException, OSError) as exc:
                self._emit("status", f"Port {port.device} error: {exc}")
                if ser:
                    try:
                        ser.close()
                    except Exception:
                        pass
        self._emit("status", "No suitable device. Retrying in 2s...")
        time.sleep(2)

    def _wait_for_response(self, ser: serial.Serial) -> bool:
        deadline = time.time() + 0.75
        while time.time() < deadline and not self._stop_event.is_set():
            if ser.in_waiting:
                try:
                    line = ser.readline().decode(errors="ignore")
                except serial.SerialException:
                    return False
                if line:
                    self._emit("data", line)
                    return True
            time.sleep(0.02)
        return False

    def _handle_writes(self) -> None:
        if not self._serial:
            return
        while not self.write_queue.empty():
            payload = self.write_queue.get()
            try:
                self._serial.write(payload.encode("utf-8"))
                self._serial.flush()
            except serial.SerialException as exc:
                self._emit("status", f"Write failed: {exc}")
                self._emit("disconnected", "")
                self._close_serial()
                break

    def _handle_reads(self) -> None:
        if not self._serial:
            return
        try:
            if self._serial.in_waiting:
                line = self._serial.readline().decode(errors="ignore")
                if line:
                    self._emit("data", line)
        except serial.SerialException as exc:
            self._emit("status", f"Read failed: {exc}")
            self._emit("disconnected", "")
            self._close_serial()

    @staticmethod
    def _looks_like_due(port: serial.tools.list_ports_common.ListPortInfo) -> bool:
        description = (port.description or "").lower()
        manufacturer = (getattr(port, "manufacturer", "") or "").lower()
        hwid = (port.hwid or "").lower()
        return any(
            keyword in text
            for keyword in ("arduino", "due", "sam3x", "native usb")
            for text in (description, manufacturer, hwid)
        )


class TkGui:
    def __init__(self) -> None:
        self.root = tk.Tk()
        self.root.title("USB Universal Tester Console (Tkinter)")
        self.root.geometry(f"{APP_WIDTH}x{APP_HEIGHT}")

        self.serial_worker = SerialWorker()
        self.serial_worker.start()

        self.level_visibility = {lvl: tk.BooleanVar(value=True) for lvl in LOG_LEVELS}
        self.log_rows: List[TableRow] = []
        self.expanded_item: Optional[str] = None
        self.awaiting_log = False
        self.capturing_log = False
        self.log_buffer: List[str] = []
        self.log_errors: List[str] = []
        self.awaiting_counters = False
        self.counter_buffer: List[Tuple[int, int]] = []
        self.awaiting_erase_ack = False
        self.awaiting_savectr = False
        self.savectr_buffer: List[str] = []
        self.awaiting_productdata = False
        self.product_lines: List[str] = []

        self._build_ui()
        self.root.after(100, self._poll_worker)

    # UI construction -------------------------------------------------
    def _build_ui(self) -> None:
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True)

        self.dashboard_frame = ttk.Frame(self.notebook)
        self.product_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.dashboard_frame, text="Dashboard")
        self.notebook.add(self.product_frame, text="Product Data")

        self._build_dashboard()
        self._build_product_tab()

    def _build_dashboard(self) -> None:
        top_bar = ttk.Frame(self.dashboard_frame)
        top_bar.pack(fill="x", padx=6, pady=4)
        ttk.Label(top_bar, text="Options", font=("Segoe UI", 11, "bold")).pack(side="left")
        self.switch_btn = ttk.Button(top_bar, text="Go to Product Data", command=self._open_product_tab)
        self.switch_btn.pack(side="right")

        self._make_filter_row(self.dashboard_frame, "Top Filters")

        splitter = ttk.Panedwindow(self.dashboard_frame, orient="horizontal")
        splitter.pack(fill="both", expand=True, padx=6, pady=4)

        left_frame = ttk.Frame(splitter)
        right_frame = ttk.Frame(splitter, width=120)
        splitter.add(left_frame, weight=4)
        splitter.add(right_frame, weight=1)

        self._make_filter_row(left_frame, "Table Filters")

        self.table = ttk.Treeview(
            left_frame,
            columns=("timestamp", "level", "source", "message"),
            show="headings",
            selectmode="browse",
        )
        for col, width in zip(("timestamp", "level", "source", "message"), (120, 80, 80, 400)):
            self.table.heading(col, text=col.title())
            self.table.column(col, width=width, anchor="w")
        self.table.bind("<<TreeviewSelect>>", self._handle_row_select)
        vsb = ttk.Scrollbar(left_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=vsb.set)
        self.table.pack(side="left", fill="both", expand=True, padx=(6, 0), pady=4)
        vsb.pack(side="right", fill="y", padx=(0, 6), pady=4)

        ttk.Label(right_frame, text="Counters", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=4, pady=4)
        self.counter_vars: List[tk.StringVar] = []
        for idx in range(10):
            frame = ttk.LabelFrame(right_frame, text=f"Metric {idx}")
            frame.pack(fill="x", padx=4, pady=4)
            label = ttk.Label(frame, text="Value")
            label.pack(anchor="w")
            var = tk.StringVar(value="0")
            entry = ttk.Entry(frame, textvariable=var, justify="center", state="readonly", font=("Segoe UI", 12, "bold"))
            entry.pack(fill="x", pady=2)
            self.counter_vars.append(var)

        cli_rows = max(5, CLI_HEIGHT // 20)
        self.cli_output = tk.Text(
            self.dashboard_frame,
            height=cli_rows,
            bg="#0c0c0c",
            fg="#d0f0d0",
            insertbackground="#d0f0d0",
        )
        self.cli_output.pack(fill="x", padx=6, pady=4)
        self.cli_output.configure(state="disabled")
        input_frame = ttk.Frame(self.dashboard_frame)
        input_frame.pack(fill="x", padx=6, pady=(0, 6))
        self.cli_input = ttk.Entry(input_frame)
        self.cli_input.pack(side="left", fill="x", expand=True)
        self.cli_input.bind("<Return>", self._handle_cli_enter)

        button_frame = ttk.Frame(self.dashboard_frame)
        button_frame.pack(fill="x", padx=6, pady=(0, 6))
        for cmd in COMMANDS:
            ttk.Button(button_frame, text=cmd, command=lambda c=cmd: self._send_button_command(c)).pack(side="left", padx=4)

    def _make_filter_row(self, parent: tk.Widget, title: str) -> None:
        row = ttk.Frame(parent)
        row.pack(fill="x", padx=6, pady=2)
        ttk.Label(row, text=title).pack(side="left")
        for level in LOG_LEVELS:
            btn = ttk.Checkbutton(
                row,
                text=level,
                variable=self.level_visibility[level],
                command=self._apply_filters,
            )
            btn.pack(side="left", padx=2)

    def _build_product_tab(self) -> None:
        info = ttk.Label(self.product_frame, text="Product data will appear below once requested.")
        info.pack(anchor="w", padx=6, pady=4)
        self.product_table = ttk.Treeview(self.product_frame, show="headings")
        self.product_table.pack(fill="both", expand=True, padx=6, pady=4)
        self.product_table.bind("<Double-1>", self._start_product_edit)
        self._product_editor: Optional[ttk.Entry] = None
        btn_bar = ttk.Frame(self.product_frame)
        btn_bar.pack(fill="x", padx=6, pady=(0, 6))
        self.send_product_btn = ttk.Button(btn_bar, text="Send Updates", command=self._send_product_updates, state="disabled")
        self.send_product_btn.pack(side="right")

    # Serial + state handling ----------------------------------------
    def _poll_worker(self) -> None:
        while not self.serial_worker.result_queue.empty():
            kind, payload = self.serial_worker.result_queue.get()
            if kind == "status":
                self._append_cli(f"[STATUS] {payload.strip()}")
            elif kind == "data":
                self._handle_serial_line(payload)
            elif kind == "connected":
                self.serial_worker.send(HANDSHAKE + "\n")
                self._append_cli(f"Connected to {payload}")
            elif kind == "disconnected":
                self._append_cli("Serial disconnected. Reconnecting...")
        self.root.after(100, self._poll_worker)

    def _append_cli(self, text: str) -> None:
        self.cli_output.configure(state="normal")
        self.cli_output.insert("end", text + "\n")
        self.cli_output.see("end")
        self.cli_output.configure(state="disabled")

    def _handle_serial_line(self, payload: str) -> None:
        line = payload.rstrip("\n")
        self._append_cli(line)
        stripped = line.strip()
        if self.awaiting_savectr and stripped:
            self.savectr_buffer.append(stripped)
        if not stripped:
            if self.awaiting_counters and self.counter_buffer:
                self._finalize_counters()
            if self.awaiting_savectr and self.savectr_buffer:
                self._finalize_savectr()
            if self.awaiting_productdata and self.product_lines:
                self._finalize_productdata()
            return

        if self.awaiting_log and stripped == "=== LOG DUMP START ===":
            self.capturing_log = True
            self.log_buffer.clear()
            self.log_errors.clear()
            return
        if self.capturing_log:
            if stripped == "=== LOG DUMP END ===":
                self.capturing_log = False
                self.awaiting_log = False
                self._persist_log_capture()
                return
            self.log_buffer.append(stripped)
            if any(token in stripped for token in ("ERR", "ERROR", "ALT", "ALERT")):
                self.log_errors.append(stripped)
            return

        if stripped.startswith("Counters:"):
            self.awaiting_counters = True
            self.counter_buffer.clear()
            return
        if self.awaiting_counters and self._parse_counter_line(stripped):
            return

        if stripped == "Logs erased" and self.awaiting_erase_ack:
            self.awaiting_erase_ack = False
            messagebox.showinfo("Erase Logs", "Logs erased successfully.")
            self._clear_views()
            return

        if "Counters saved" in stripped and self.awaiting_savectr:
            self._finalize_savectr()
            return

        if self.awaiting_productdata:
            if stripped.startswith("=== PRODUCTDATA END"):
                self._finalize_productdata()
            elif "," in stripped:
                self.product_lines.append(stripped)
            return

    def _parse_counter_line(self, line: str) -> bool:
        match = re.match(r"^C(\d+):\s*(-?\d+)$", line)
        if match:
            self.counter_buffer.append((int(match.group(1)), int(match.group(2))))
            return True
        if self.counter_buffer and not line.startswith("C"):
            self._finalize_counters()
            return True
        return False

    def _finalize_counters(self) -> None:
        self.awaiting_counters = False
        data = dict(self.counter_buffer)
        total = sum(max(v, 0) for v in data.values()) or 1
        for idx, var in enumerate(self.counter_vars):
            var.set(str(data.get(idx, 0)))
        rows: List[TableRow] = []
        for idx, value in sorted(data.items()):
            name, desc = COUNTER_METADATA.get(idx, (f"Counter {idx}", ""))
            percent = 100.0 * value / total
            rows.append(TableRow(timestamp=str(idx), level=f"{percent:.1f}%", source=name, message=desc))
        self.log_rows = rows
        self._apply_filters()
        self._append_cli("Counters updated.")

    def _finalize_savectr(self) -> None:
        self.awaiting_savectr = False
        if not self.savectr_buffer:
            return
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = self._unique_file(COUNTS_DIR, f"counts_{timestamp}", "txt")
        path.write_text("\n".join(self.savectr_buffer), encoding="utf-8")
        messagebox.showinfo("Save Counters", f"Counters saved to {path}")
        self.savectr_buffer.clear()

    def _clear_views(self) -> None:
        for item in self.table.get_children():
            self.table.delete(item)
        for var in self.counter_vars:
            var.set("0")
        self.log_rows.clear()

    def _persist_log_capture(self) -> None:
        if not self.log_buffer:
            return
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        debug_path = DEBUG_DIR / f"debug_{timestamp}.txt"
        debug_path.write_text("\n".join(self.log_buffer), encoding="utf-8")
        error_path = self._unique_file(LOG_DIR, f"log_{timestamp}", "txt")
        error_path.write_text("\n".join(self.log_errors), encoding="utf-8")
        self._append_cli(f"Logs saved to {debug_path} (errors -> {error_path})")
        self._load_debug(debug_path)
        for level in LOG_LEVELS:
            self.level_visibility[level].set(level in ("ERROR", "ALERT"))
        self._apply_filters()

    def _load_debug(self, path: Path) -> None:
        rows: List[TableRow] = []
        pattern = re.compile(r"^\[(RAM|FLASH)\s+(\d+)\]\s+(DBG|INF|WRN|ERR|ALT):\s+(.*)$")
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            match = pattern.match(line)
            if not match:
                continue
            rows.append(
                TableRow(
                    timestamp=match.group(2),
                    level=self._normalise_level(match.group(3)),
                    source=match.group(1),
                    message=match.group(4),
                )
            )
        self.log_rows = rows
        self._apply_filters()

    @staticmethod
    def _normalise_level(token: str) -> str:
        return {"DBG": "DBG", "INF": "INFO", "WRN": "WARN", "ERR": "ERROR", "ALT": "ALERT"}.get(token, token)

    def _apply_filters(self) -> None:
        for item in self.table.get_children():
            self.table.delete(item)
        self.expanded_item = None
        for row in self.log_rows:
            var = self.level_visibility.get(row.level)
            if var is not None and not var.get():
                continue
            self.table.insert("", "end", values=(row.timestamp, row.level, row.source, row.message), tags=(row.level,))

    def _handle_row_select(self, _: tk.Event) -> None:
        if self.expanded_item:
            if self.table.exists(self.expanded_item):
                self.table.delete(self.expanded_item)
            self.expanded_item = None
        selection = self.table.selection()
        if not selection:
            return
        item_id = selection[0]
        values = self.table.item(item_id, "values")
        if not values:
            return
        level = values[1]
        info = ROW_INFO_TEXT.get(level, values[3])
        index = self.table.index(item_id)
        self.expanded_item = self.table.insert("", index + 1, values=("", "", "Info", info))

    def _unique_file(self, directory: Path, base: str, ext: str) -> Path:
        idx = 0
        while True:
            suffix = f"_{idx}" if idx else ""
            candidate = directory / f"{base}{suffix}.{ext}"
            if not candidate.exists():
                return candidate
            idx += 1

    # CLI + buttons --------------------------------------------------
    def _handle_cli_enter(self, _: tk.Event) -> None:
        text = self.cli_input.get().strip()
        self.cli_input.delete(0, "end")
        if not text:
            return
        bare = text.lstrip("£")
        is_command = bare.upper() in COMMANDS
        payload = text
        if is_command and not text.startswith("£"):
            payload = f"£{bare}"
        payload += "\n"
        if is_command:
            self._update_command_state(bare.upper())
        self.serial_worker.send(payload)
        self._append_cli(f"> {payload.strip()}")

    def _send_button_command(self, command: str) -> None:
        if command == "ERASELOG":
            if not messagebox.askyesno("Erase Logs", "Are you sure?"):
                return
            self.awaiting_erase_ack = True
        if command == "SAVECTR":
            self.awaiting_savectr = True
            self.savectr_buffer.clear()
        self._update_command_state(command)
        payload = f"£{command}\n"
        self.serial_worker.send(payload)
        self._append_cli(f"> {command}")

    def _update_command_state(self, command: str) -> None:
        if command == "GETLOG":
            self.awaiting_log = True
            self.log_buffer.clear()
            self.log_errors.clear()
        elif command == "GETCOUNTERS":
            self.awaiting_counters = True
            self.counter_buffer.clear()
        elif command == "ERASELOG":
            self.awaiting_erase_ack = True
        elif command == "SAVECTR":
            self.awaiting_savectr = True
            self.savectr_buffer.clear()

    # Product data tab -----------------------------------------------
    def _open_product_tab(self) -> None:
        self.notebook.select(self.product_frame)
        self._request_product_data()

    def _request_product_data(self) -> None:
        self.awaiting_productdata = True
        self.product_lines.clear()
        self.serial_worker.send("£PRODUCTDATA\n")
        self._append_cli("Requested product data...")

    def _finalize_productdata(self) -> None:
        self.awaiting_productdata = False
        if not self.product_lines:
            return
        reader = csv.reader(io.StringIO("\n".join(self.product_lines)))
        rows = list(reader)
        if not rows:
            return
        headers, *data_rows = rows
        self.product_table.config(columns=headers)
        for col in headers:
            self.product_table.heading(col, text=col)
            self.product_table.column(col, width=120, anchor="w")
        for item in self.product_table.get_children():
            self.product_table.delete(item)
        for row in data_rows:
            self.product_table.insert("", "end", values=row)
        self.send_product_btn.config(state="normal")
        path = PRODUCT_DIR / f"product_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        with path.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(headers)
            writer.writerows(data_rows)
        self._append_cli(f"Product data saved to {path}")
        self.product_lines.clear()

    def _send_product_updates(self) -> None:
        headers = self.product_table["columns"]
        if not headers:
            return
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(headers)
        for item in self.product_table.get_children():
            writer.writerow(self.product_table.item(item, "values"))
        payload_lines = buffer.getvalue().strip().splitlines()
        self.serial_worker.send("£PRODUCTDATA\n")
        for line in payload_lines:
            self.serial_worker.send(line + "\n")
        self.serial_worker.send("\n")
        self._append_cli("Pushed updated product data.")

    def _start_product_edit(self, event: tk.Event) -> None:
        if self._product_editor is not None:
            self._product_editor.destroy()
            self._product_editor = None
        region = self.product_table.identify("region", event.x, event.y)
        if region != "cell":
            return
        row_id = self.product_table.identify_row(event.y)
        col_id = self.product_table.identify_column(event.x)
        if not row_id or not col_id:
            return
        bbox = self.product_table.bbox(row_id, col_id)
        if not bbox:
            return
        x, y, width, height = bbox
        value = self.product_table.set(row_id, col_id)
        editor = ttk.Entry(self.product_table)
        editor.insert(0, value)
        editor.place(x=x, y=y, width=width, height=height)
        editor.focus()
        self._product_editor = editor

        def finish(_: Optional[tk.Event] = None) -> None:
            self.product_table.set(row_id, col_id, editor.get())
            editor.destroy()
            self._product_editor = None

        editor.bind("<Return>", finish)
        editor.bind("<FocusOut>", finish)

    # lifecycle ------------------------------------------------------
    def run(self) -> None:
        try:
            self.root.mainloop()
        finally:
            self.serial_worker.stop()


def main() -> None:
    gui = TkGui()
    gui.run()


if __name__ == "__main__":  # pragma: no cover
    main()
