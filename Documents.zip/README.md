# USB Universal Tester Host GUI

Python/PyQt interface for the USB Universal Tester firmware running on an Arduino Due. The tool auto-discovers the serial port, locks the firmware into listen mode, and exposes GUI workflows for log retrieval, counter aggregation, and product data management.

## Features

- Automatic scanning of available serial ports (prefers Arduino Due identifiers) with handshake validation and `£££` listen request.
- Terminal-style CLI panel for direct command entry and streamed output.
- Dedicated buttons for `GETLOG`, `ERASELOG`, `GETCOUNTERS`, and `SAVECTR` commands.
- Dual-layer log-level filter buttons plus scrollable log table with inline row expansion.
- Persistent capture of log dumps (full `debug_*.txt` plus filtered `log_*.txt`) and counter snapshots (`counts_*.txt`).
- Ten numeric counter tiles aligned along the right edge for quick KPI visibility.
- Product data tab that fetches the CSV representation of `products[]`, renders an editable table, and pushes updates back to the device.
- Safe handling for destructive commands (confirmation + acknowledgement flow for `ERASELOG`).

## Requirements

- Python 3.9+
- PyQt5
- pyserial

Install the dependencies with:

```powershell
pip install -r requirements.txt
```

## Running the GUI

```powershell
python GUI.py
```

On launch the application scans serial ports, sends `£££`, and waits for the tester to respond. Once connected:

- Use the CLI at the bottom to type commands (the app automatically prepends `£` for recognised commands).
- Use the command buttons for one-click access to the firmware handlers listed in `Database::handleSerialCommands()`.
- After issuing `GETLOG`, the tool captures the `=== LOG DUMP START/END ===` block, writes timestamped files under `debug/` and `logs/`, and populates the main table with only ERROR/ALERT entries enabled by default.
- After issuing `GETCOUNTERS`, the numeric tiles update and the table shows aggregate fail-code percentages; clicking a row expands it with contextual info.
- Switching to the *Product Data* view requests `£PRODUCTDATA` and displays the CSV data in an editable grid. Use **Send Updates** to push edits back to the tester (the CSV is also archived under `product_data/`).

Log/error files accumulate without overwriting—new captures get numeric suffixes automatically.

## Notes

- The GUI keeps retrying connections if the Arduino Due is unplugged/replugged.
- Files are stored relative to the working directory (`logs/`, `debug/`, `counts/`, `product_data/`).
- The application has not been tested on macOS/Linux, but only the serial port naming heuristics may require adjustments.
