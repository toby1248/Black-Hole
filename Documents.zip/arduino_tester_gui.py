#!/usr/bin/env python3
"""
USB Universal Tester GUI
Python interface for Arduino Due USB tester
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import serial
import serial.tools.list_ports
import threading
import queue
import time
from datetime import datetime
import os
import re
import csv
import io

# Try to import failcode reference data
try:
    from failcode_reference import FAILCODE_INFO, COUNTER_INFO
except ImportError:
    FAILCODE_INFO = {}
    COUNTER_INFO = {}

class ArduinoTesterGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("USB Universal Tester - Control Interface")
        self.root.geometry("1024x800")
        
        # Serial communication
        self.serial_port = None
        self.serial_queue = queue.Queue()
        self.serial_lock = threading.Lock()
        self.receiving_log = False
        self.log_buffer = []
        self.receiving_counters = False
        self.counter_buffer = []
        self.waiting_eraselog_ack = False
        self.receiving_product_data = False
        self.product_data_buffer = []
        
        # Available commands from Database::handleSerialCommands()
        self.commands = ["GETLOG", "ERASELOG", "GETCOUNTERS", "SAVECTR", "PRODUCTDATA"]
        
        # Log level filters (DBG, INFO, WARN, ERROR, ALERT)
        self.log_levels = ["DBG", "INF", "WRN", "ERR", "ALT"]
        self.log_filters = {level: tk.BooleanVar(value=(level in ["ERR", "ALT"])) 
                           for level in self.log_levels}
        
        # Current tab
        self.current_tab = "main"
        
        # Fail code info lookup
        self.failcode_info = self.load_failcode_info()
        
        self.setup_ui()
        self.connect_arduino()
        
    def load_failcode_info(self):
        """Load fail code information lookup"""
        # Use imported failcode data, with fallback defaults
        base_info = {
            "0xE1": "Tester is uncalibrated",
            "0xE2": "Calibration required on reboot",
            "0xE4": "Power delivery test failed",
            "0xF5": "Quick Charge test failed",
            "0xF6": "PD PDOs mismatch",
            "0xF7": "Voltage measurement error",
            "0xF10": "UVLO test failed - 24V product did not shut down"
        }
        
        # Merge with imported data
        base_info.update(FAILCODE_INFO)
        return base_info
    
    def setup_ui(self):
        """Setup the main UI components"""
        # Top button bar
        self.setup_top_bar()
        
        # Main content area (changes based on tab)
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        self.setup_main_tab()
        
        # CLI at bottom (always visible)
        self.setup_cli()
    
    def setup_top_bar(self):
        """Setup top button bar with tab switching"""
        top_frame = tk.Frame(self.root, bg='lightgray', height=40)
        top_frame.pack(side=tk.TOP, fill=tk.X)
        top_frame.pack_propagate(False)
        
        # Tab buttons
        tk.Button(top_frame, text="Main View", 
                 command=lambda: self.switch_tab("main"),
                 width=12).pack(side=tk.LEFT, padx=5, pady=5)
        
        tk.Button(top_frame, text="Product Data Editor", 
                 command=lambda: self.switch_tab("product"),
                 width=18).pack(side=tk.LEFT, padx=5, pady=5)
        
        # Connection status
        self.conn_label = tk.Label(top_frame, text="Not Connected", 
                                   bg='red', fg='white', padx=10)
        self.conn_label.pack(side=tk.RIGHT, padx=5, pady=5)
    
    def setup_main_tab(self):
        """Setup main tab with log display and counters"""
        # Clear main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()
        
        # Filter buttons at top
        filter_frame = tk.Frame(self.main_frame, height=40)
        filter_frame.pack(fill=tk.X, padx=5, pady=5)
        
        tk.Label(filter_frame, text="Show Levels:").pack(side=tk.LEFT, padx=5)
        for level in self.log_levels:
            cb = tk.Checkbutton(filter_frame, text=level, 
                              variable=self.log_filters[level],
                              command=self.apply_log_filter)
            cb.pack(side=tk.LEFT, padx=5)
        
        # Main content - split into table and data boxes
        content_frame = tk.Frame(self.main_frame)
        content_frame.pack(fill=tk.BOTH, expand=True, padx=5)
        
        # Left side - scrollable table for logs/counters
        table_frame = tk.Frame(content_frame)
        table_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Treeview for data display
        self.tree = ttk.Treeview(table_frame, columns=('Time', 'Level', 'Message'), 
                                show='tree headings', height=20)
        self.tree.heading('#0', text='#')
        self.tree.heading('Time', text='Timestamp')
        self.tree.heading('Level', text='Level')
        self.tree.heading('Message', text='Message')
        
        self.tree.column('#0', width=50)
        self.tree.column('Time', width=120)
        self.tree.column('Level', width=80)
        self.tree.column('Message', width=600)
        
        # Scrollbar for tree
        tree_scroll = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, 
                                   command=self.tree.yview)
        self.tree.configure(yscrollcommand=tree_scroll.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Bind click event to expand rows
        self.tree.bind('<ButtonRelease-1>', self.on_tree_click)
        
        # Right side - data boxes (100px wide)
        data_frame = tk.Frame(content_frame, width=100)
        data_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=5)
        data_frame.pack_propagate(False)
        
        tk.Label(data_frame, text="Counters", font=('Arial', 10, 'bold')).pack(pady=5)
        
        # Create 10 data boxes with descriptions
        self.data_boxes = []
        for i in range(10):
            frame = tk.Frame(data_frame, relief=tk.SUNKEN, borderwidth=1)
            frame.pack(fill=tk.X, pady=3)
            
            # Get counter description if available
            desc = COUNTER_INFO.get(i, f"C{i}")
            label = tk.Label(frame, text=desc, font=('Arial', 7), wraplength=90)
            label.pack(anchor=tk.W)
            
            value = tk.Label(frame, text="0", font=('Arial', 10, 'bold'))
            value.pack(anchor=tk.W)
            
            self.data_boxes.append(value)
    
    def setup_product_tab(self):
        """Setup product data editor tab"""
        # Clear main frame
        for widget in self.main_frame.winfo_children():
            widget.destroy()
        
        # Control buttons
        btn_frame = tk.Frame(self.main_frame)
        btn_frame.pack(fill=tk.X, padx=5, pady=5)
        
        tk.Button(btn_frame, text="Refresh from Device", 
                 command=self.load_product_data).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="Send Update to Device", 
                 command=self.send_product_data).pack(side=tk.LEFT, padx=5)
        
        # Product data table
        table_frame = tk.Frame(self.main_frame)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create treeview for product data
        columns = ['partNumber', 'hasPD', 'hasQC', 'Is24VoltOnly', 
                  'VOutMaxLower', 'VOutMinLower', 'IOutMaxLower', 
                  'connectorLower', 'PDQCVMaxLower', 'PDQCIMaxLower',
                  'VOutMaxUpper', 'VOutMinUpper', 'IOutMaxUpper',
                  'connectorUpper', 'PDQCVMaxUpper', 'PDQCIMaxUpper',
                  'LEDColour', 'PDOsIndex', 'DeratePDOsIndex', 
                  'connectorID', 'extraCapacitance']
        
        self.product_tree = ttk.Treeview(table_frame, columns=columns, 
                                        show='tree headings', height=25)
        
        # Set up column headings
        self.product_tree.heading('#0', text='ID')
        self.product_tree.column('#0', width=40)
        
        for col in columns:
            self.product_tree.heading(col, text=col)
            self.product_tree.column(col, width=100)
        
        # Scrollbars
        y_scroll = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, 
                               command=self.product_tree.yview)
        x_scroll = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, 
                               command=self.product_tree.xview)
        
        self.product_tree.configure(yscrollcommand=y_scroll.set, 
                                   xscrollcommand=x_scroll.set)
        
        self.product_tree.grid(row=0, column=0, sticky='nsew')
        y_scroll.grid(row=0, column=1, sticky='ns')
        x_scroll.grid(row=1, column=0, sticky='ew')
        
        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)
        
        # Make cells editable
        self.product_tree.bind('<Double-1>', self.edit_product_cell)
        
        # Load initial data
        self.load_product_data()
    
    def setup_cli(self):
        """Setup CLI area at bottom"""
        cli_frame = tk.Frame(self.root, bg='white', height=250)
        cli_frame.pack(side=tk.BOTTOM, fill=tk.X)
        cli_frame.pack_propagate(False)
        
        # Command buttons
        cmd_btn_frame = tk.Frame(cli_frame, bg='lightgray')
        cmd_btn_frame.pack(fill=tk.X, pady=2)
        
        for cmd in self.commands:
            btn = tk.Button(cmd_btn_frame, text=cmd, 
                          command=lambda c=cmd: self.send_command(c),
                          width=12)
            btn.pack(side=tk.LEFT, padx=2)
        
        # Serial display
        tk.Label(cli_frame, text="Serial Monitor:", bg='white').pack(anchor=tk.W, padx=5)
        
        self.cli_text = scrolledtext.ScrolledText(cli_frame, height=8, 
                                                 bg='black', fg='green',
                                                 font=('Courier', 9))
        self.cli_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=2)
        
        # Command input
        input_frame = tk.Frame(cli_frame, bg='white')
        input_frame.pack(fill=tk.X, padx=5, pady=2)
        
        tk.Label(input_frame, text=">", bg='white').pack(side=tk.LEFT)
        
        self.cli_input = tk.Entry(input_frame)
        self.cli_input.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        self.cli_input.bind('<Return>', self.send_cli_command)
        
        tk.Button(input_frame, text="Send", 
                 command=self.send_cli_command).pack(side=tk.RIGHT)
    
    def connect_arduino(self):
        """Attempt to connect to Arduino Due"""
        # List all serial ports
        ports = serial.tools.list_ports.comports()
        arduino_port = None
        
        # Try to find Arduino
        for port in ports:
            # Arduino Due usually shows up with specific VID/PID or description
            if 'Arduino' in port.description or 'Due' in port.description:
                arduino_port = port.device
                break
            # Also check common Arduino VID
            if port.vid in [0x2341, 0x2A03]:  # Arduino VID
                arduino_port = port.device
                break
        
        # If not found by description, try all ports
        if arduino_port is None:
            for port in ports:
                try:
                    self.cli_print(f"Trying port {port.device}...")
                    ser = serial.Serial(port.device, 115200, timeout=1)
                    time.sleep(2)  # Wait for Arduino to reset
                    
                    # Send lock command
                    ser.write(b'\xc2\xa3\xc2\xa3\xc2\xa3\n')  # £££ in UTF-8
                    time.sleep(0.5)
                    
                    # Check if we get a response
                    if ser.in_waiting > 0:
                        arduino_port = port.device
                        ser.close()
                        break
                    ser.close()
                except Exception as e:
                    continue
        
        if arduino_port:
            try:
                self.serial_port = serial.Serial(arduino_port, 115200, timeout=0.1)
                time.sleep(2)  # Wait for Arduino to reset
                
                # Send lock command
                self.serial_port.write(b'\xc2\xa3\xc2\xa3\xc2\xa3\n')  # £££
                
                self.conn_label.config(text=f"Connected: {arduino_port}", bg='green')
                self.cli_print(f"Connected to Arduino on {arduino_port}")
                
                # Start reading thread
                self.read_thread = threading.Thread(target=self.read_serial, daemon=True)
                self.read_thread.start()
                
                # Start processing thread
                self.process_thread = threading.Thread(target=self.process_serial_data, 
                                                      daemon=True)
                self.process_thread.start()
                
                return True
            except Exception as e:
                self.cli_print(f"Error connecting: {e}")
                return False
        else:
            messagebox.showerror("Connection Error", 
                               "Could not find Arduino Due. Please check connection.")
            self.cli_print("Arduino Due not found. Please connect and restart.")
            return False
    
    def read_serial(self):
        """Thread to continuously read from serial port"""
        while True:
            try:
                if self.serial_port and self.serial_port.in_waiting:
                    line = self.serial_port.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        self.serial_queue.put(line)
            except Exception as e:
                self.cli_print(f"Read error: {e}")
                time.sleep(0.1)
            time.sleep(0.01)
    
    def process_serial_data(self):
        """Thread to process incoming serial data"""
        while True:
            try:
                line = self.serial_queue.get(timeout=0.1)
                
                # Handle log dump
                if "=== LOG DUMP START ===" in line:
                    self.receiving_log = True
                    self.log_buffer = []
                    self.cli_print(line)
                    continue
                
                if "=== LOG DUMP END ===" in line:
                    self.receiving_log = False
                    self.cli_print(line)
                    self.process_log_dump()
                    continue
                
                if self.receiving_log:
                    self.log_buffer.append(line)
                    self.cli_print(line)
                    continue
                
                # Handle counter data
                if line.startswith("Counters:"):
                    self.receiving_counters = True
                    self.counter_buffer = []
                    self.cli_print(line)
                    continue
                
                if self.receiving_counters:
                    if line.startswith("C") and ":" in line:
                        self.counter_buffer.append(line)
                        self.cli_print(line)
                    else:
                        self.receiving_counters = False
                        self.process_counter_data()
                        self.cli_print(line)
                    continue
                
                # Handle ERASELOG acknowledgment
                if self.waiting_eraselog_ack and "Logs erased" in line:
                    self.waiting_eraselog_ack = False
                    self.cli_print(line)
                    self.root.after(0, self.handle_eraselog_success)
                    continue
                
                # Handle product data (CSV format)
                # Start marker could be "PRODUCT_DATA_START" or just start with CSV data
                if "PRODUCT_DATA_START" in line or (self.receiving_product_data and "PRODUCT_DATA_END" not in line):
                    self.receiving_product_data = True
                    if "PRODUCT_DATA_START" not in line:
                        self.product_data_buffer.append(line)
                    self.cli_print(line)
                    continue
                
                if "PRODUCT_DATA_END" in line:
                    self.receiving_product_data = False
                    self.cli_print(line)
                    self.root.after(0, self.populate_product_table)
                    continue
                
                # Regular output
                self.cli_print(line)
                
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Process error: {e}")
    
    def process_log_dump(self):
        """Process received log dump"""
        if not self.log_buffer:
            return
        
        # Save full debug log
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        debug_file = f"debug_{timestamp}.txt"
        
        with open(debug_file, 'w') as f:
            f.write('\n'.join(self.log_buffer))
        
        self.cli_print(f"Debug log saved to {debug_file}")
        
        # Extract ERROR and ALERT entries
        error_alert_lines = []
        for line in self.log_buffer:
            if 'ERR:' in line or 'ALT:' in line:
                error_alert_lines.append(line)
        
        if error_alert_lines:
            # Save error/alert log
            log_file = f"log_{timestamp}.txt"
            counter = 1
            while os.path.exists(log_file):
                log_file = f"log_{timestamp}_{counter}.txt"
                counter += 1
            
            with open(log_file, 'w') as f:
                f.write('\n'.join(error_alert_lines))
            
            self.cli_print(f"Error/Alert log saved to {log_file}")
        
        # Load into table
        self.root.after(0, self.populate_log_table)
    
    def populate_log_table(self):
        """Populate the tree view with log data"""
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Parse and add log entries
        for idx, line in enumerate(self.log_buffer):
            # Parse log format: [RAM/FLASH timestamp] LEVEL: message
            match = re.match(r'\[(RAM|FLASH)\s+(\d+)\]\s+(\w+):\s+(.*)', line)
            if match:
                source, timestamp, level, message = match.groups()
                
                # Check if this level should be shown
                if not self.log_filters[level].get():
                    continue
                
                # Determine tag for coloring
                tag = 'error' if level == 'ERR' else 'alert' if level == 'ALT' else 'normal'
                
                self.tree.insert('', 'end', text=str(idx), 
                               values=(timestamp, level, message),
                               tags=(tag,))
        
        # Configure tags for colors
        self.tree.tag_configure('error', background='#ffcccc')
        self.tree.tag_configure('alert', background='#ffffcc')
        self.tree.tag_configure('normal', background='white')
    
    def process_counter_data(self):
        """Process received counter data"""
        if not self.counter_buffer:
            return
        
        # Update data boxes
        for line in self.counter_buffer:
            match = re.match(r'C(\d+):\s+(\d+)', line)
            if match:
                counter_id = int(match.group(1))
                value = match.group(2)
                if counter_id < len(self.data_boxes):
                    self.root.after(0, lambda id=counter_id, v=value: 
                                  self.data_boxes[id].config(text=v))
        
        # Calculate aggregate failcode data
        # This would parse the counters and display aggregated data
        # For now, just populate the tree with counter summary
        self.root.after(0, self.populate_counter_table)
    
    def save_counters_to_file(self):
        """Save current counter data to a timestamped file"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"counts_{timestamp}.txt"
        
        try:
            with open(filename, 'w') as f:
                f.write(f"Counter Data Snapshot - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write("=" * 60 + "\n\n")
                
                for i, box in enumerate(self.data_boxes):
                    value = box.cget('text')
                    desc = COUNTER_INFO.get(i, f"Counter {i}")
                    f.write(f"C{i}: {value:>10}  # {desc}\n")
                
                f.write("\n" + "=" * 60 + "\n")
                f.write("Raw buffer data:\n")
                for line in self.counter_buffer:
                    f.write(line + "\n")
            
            self.cli_print(f"Counters saved to {filename}")
            messagebox.showinfo("Success", f"Counters saved to {filename}")
        except Exception as e:
            self.cli_print(f"Error saving counters: {e}")
            messagebox.showerror("Error", f"Failed to save counters: {e}")
    
    def handle_eraselog_success(self):
        """Handle successful log erasure"""
        # Clear the log table
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Show success message
        messagebox.showinfo("Success", "Logs erased successfully!")
        self.cli_print("Log display cleared.")
    
    def populate_counter_table(self):
        """Populate tree view with counter aggregate data"""
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Parse counters and create aggregate view
        # This is a placeholder - you would implement actual aggregation logic
        for idx, line in enumerate(self.counter_buffer):
            match = re.match(r'C(\d+):\s+(\d+)', line)
            if match:
                counter_id = match.group(1)
                value = match.group(2)
                
                self.tree.insert('', 'end', text=counter_id,
                               values=('Counter', f"C{counter_id}", 
                                     f"Count: {value}"))
    
    def apply_log_filter(self):
        """Re-filter the log display based on selected levels"""
        self.populate_log_table()
    
    def on_tree_click(self, event):
        """Handle tree item click to show expanded info"""
        item = self.tree.selection()
        if not item:
            return
        
        values = self.tree.item(item[0], 'values')
        if len(values) >= 3:
            message = values[2]
            
            # Look for fail codes in the message
            failcode_match = re.search(r'(0x[EF][0-9A-F]+)', message)
            if failcode_match:
                failcode = failcode_match.group(1)
                info = self.failcode_info.get(failcode, "No additional information available")
                
                # Show info in a popup or expand in tree
                # For now, just show in CLI
                self.cli_print(f"\n--- Info for {failcode} ---")
                self.cli_print(info)
                self.cli_print("------------------------\n")
    
    def send_command(self, command):
        """Send a command to the Arduino"""
        if command == "ERASELOG":
            if not messagebox.askyesno("Confirm", 
                                      "Are you sure you want to erase all logs?"):
                return
            self.waiting_eraselog_ack = True
        
        self.send_serial(f"£{command}")
        
        # Handle SAVECTR - also save locally
        if command == "SAVECTR":
            # Wait a moment for the response, then save current counter data
            self.root.after(500, self.save_counters_to_file)
    
    def send_cli_command(self, event=None):
        """Send command from CLI input"""
        command = self.cli_input.get().strip()
        if not command:
            return
        
        self.cli_input.delete(0, tk.END)
        
        # Check if it's a known command
        cmd_upper = command.upper()
        if cmd_upper in self.commands:
            # Add £ prefix if not present
            if not command.startswith('£'):
                command = '£' + command
        elif command.upper() in [c for c in self.commands]:
            command = '£' + command
        
        self.cli_print(f"> {command}")
        self.send_serial(command)
    
    def send_serial(self, data):
        """Send data to serial port"""
        if self.serial_port:
            with self.serial_lock:
                try:
                    self.serial_port.write((data + '\n').encode('utf-8'))
                except Exception as e:
                    self.cli_print(f"Send error: {e}")
    
    def cli_print(self, text):
        """Print text to CLI display"""
        def update():
            self.cli_text.insert(tk.END, text + '\n')
            self.cli_text.see(tk.END)
        
        self.root.after(0, update)
    
    def switch_tab(self, tab):
        """Switch between main and product data tabs"""
        self.current_tab = tab
        
        if tab == "main":
            self.setup_main_tab()
        elif tab == "product":
            self.setup_product_tab()
    
    def load_product_data(self):
        """Load product data from Arduino"""
        self.product_data_buffer = []
        self.send_serial("£PRODUCTDATA")
        self.cli_print("Requesting product data...")
        
        # The response would be handled by the serial processing thread
        # and would populate the product_tree
    
    def populate_product_table(self):
        """Parse CSV product data and populate the table"""
        if not hasattr(self, 'product_tree'):
            return
        
        # Clear existing data
        for item in self.product_tree.get_children():
            self.product_tree.delete(item)
        
        if not self.product_data_buffer:
            self.cli_print("No product data received")
            return
        
        try:
            # Parse CSV data
            csv_data = io.StringIO('\n'.join(self.product_data_buffer))
            reader = csv.reader(csv_data)
            
            for idx, row in enumerate(reader):
                if len(row) > 0:
                    # Insert into tree with proper columns
                    self.product_tree.insert('', 'end', text=str(idx), values=row)
            
            self.cli_print(f"Loaded {idx + 1} product entries")
        except Exception as e:
            self.cli_print(f"Error parsing product data: {e}")
            messagebox.showerror("Error", f"Failed to parse product data: {e}")
    
    def edit_product_cell(self, event):
        """Make product data cells editable"""
        item = self.product_tree.selection()[0]
        column = self.product_tree.identify_column(event.x)
        
        # Get column number
        col_num = int(column.replace('#', '')) - 1
        
        if col_num < 0:
            return
        
        # Get current value
        values = self.product_tree.item(item, 'values')
        if col_num >= len(values):
            return
        
        current_value = values[col_num]
        
        # Create entry widget
        bbox = self.product_tree.bbox(item, column)
        if not bbox:
            return
        
        entry = tk.Entry(self.product_tree)
        entry.place(x=bbox[0], y=bbox[1], width=bbox[2], height=bbox[3])
        entry.insert(0, current_value)
        entry.focus()
        
        def save_edit(event=None):
            new_value = entry.get()
            new_values = list(values)
            new_values[col_num] = new_value
            self.product_tree.item(item, values=new_values)
            entry.destroy()
        
        entry.bind('<Return>', save_edit)
        entry.bind('<FocusOut>', save_edit)
    
    def send_product_data(self):
        """Send updated product data back to Arduino"""
        # Collect all data from tree
        product_data = []
        for item in self.product_tree.get_children():
            values = self.product_tree.item(item, 'values')
            product_data.append(values)
        
        # Convert to CSV format and send
        # This would need to match the format expected by the Arduino
        self.cli_print("Sending product data update...")
        # Implementation would go here
        messagebox.showinfo("Info", "Product data update not yet implemented")

def main():
    root = tk.Tk()
    app = ArduinoTesterGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
