/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : calibrate.cpp
 * Description  : calibration functions for the USB universal tester
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */


#include <Adafruit_AS7341.h>
#include <wire.h>
#include <stdint.h>
#include <Arduino.h>
#include <DueFlashStorage.h>
#include "globaldefines.h"
#include "ui.h"
#include "calibrate.h"

extern Adafruit_AS7341 as7341;
extern const as7341_color_channel_t VisChannels[8];

//Flash memory addresses for calibration data
const uint32_t LOAD1_CAL_ADDRESS      = 4;
const uint32_t LOAD2_CAL_ADDRESS      = 24;
const uint32_t ADC_CAL_ADDRESS        = 44;
const uint32_t COLOUR_CAL_ADDRESS     = 52;

//Max allowable offsets for colour sensor cal data
const uint16_t MAX_CHANNEL_CAL_OFFSET = 10000; //placeholders
const uint32_t MAX_TOTAL_CAL_OFFSET   = 50000;

//Visible channel order for AS7341
const as7341_color_channel_t VisChannels[8] = {
  AS7341_CHANNEL_415nm_F1, // 415 nm (Violet)
  AS7341_CHANNEL_445nm_F2, // 445 nm (Blue)
  AS7341_CHANNEL_480nm_F3, // 480 nm (Blue/Cyan)
  AS7341_CHANNEL_515nm_F4, // 515 nm (Green)
  AS7341_CHANNEL_555nm_F5, // 555 nm (Green)
  AS7341_CHANNEL_590nm_F6, // 590 nm (Yellow/Amber)
  AS7341_CHANNEL_630nm_F7, // 630 nm (Red)
  AS7341_CHANNEL_680nm_F8  // 680 nm (Deep Red)
};

/**
 * @brief Check if the calibration area in flash is blank / marked as needing calibration.
 *
 * Reads a single marker byte in flash (address 0) which is used to indicate if
 * calibration is required. Returns true when blank/marker is set (non-zero).
 *
 * @return true  Calibration is required / marker set
 * @return false Calibration marker unset
 */
bool calibrate::isBlank(){
  uint8_t checkByte = dueFlashStorage.read(0);
  if(checkByte != 0)  return true;
  return false;
}


/**
 * @brief Load calibration blocks from flash into runtime structures.
 *
 * Reads the stored calibration blocks for the two load banks, the ADC
 * calibration factor and the colour sensor offsets. On any flash read error
 * the function sets the calibration-needed marker and returns false.
 *
 * @return true  All calibration blocks successfully loaded
 * @return false At least one block failed to read from flash
 */
bool calibrate::loadData(){
  struct CalBlock {
    void* data;
    size_t size;
    uint32_t address;
    const char* label;
  };
  CalBlock blocks[] = {
    { &load1Cal, sizeof(load1Cal), LOAD1_CAL_ADDRESS, "Load 1" },
    { &load2Cal, sizeof(load2Cal), LOAD2_CAL_ADDRESS, "Load 2" },
    { &ADCCalFactor, sizeof(ADCCalFactor), ADC_CAL_ADDRESS, "ADC" },
    { &colourCal, sizeof(colourCal), COLOUR_CAL_ADDRESS, "Colour" }
  };

  for (auto& block : blocks) {
    byte* b = dueFlashStorage.readAddress(block.address);
    if (b != nullptr) {
      memcpy(block.data, b, block.size);
    } else {
      Serial.println("Flash read error for " + String(block.label) + " calibration data");
      dueFlashStorage.write(0, 255); //Sets the needs calibration flag for next reboot
      return false;
    }
  }

  Serial.println("Load 1 calibrated gain: " + String(load1Cal.gain, 2) + ", offset: " + String(load1Cal.offset, 2));
  Serial.println("Load 2 calibrated gain: " + String(load2Cal.gain, 2) + ", offset: " + String(load2Cal.offset, 2));
  Serial.println("ADC cal factor: " + String(ADCCalFactor, 8));
  return true;
}


/**
 * @brief Persist current calibration blocks into flash.
 *
 * Writes the load bank calibrations, ADC factor and colour offsets to their
 * reserved flash addresses then clears the calibration-needed marker.
 */
void calibrate::save(){
  struct CalBlock {
    void* data;
    size_t size;
    uint32_t address;
  };
  CalBlock blocks[] = {
    { &load1Cal, sizeof(load1Cal), LOAD1_CAL_ADDRESS },
    { &load2Cal, sizeof(load2Cal), LOAD2_CAL_ADDRESS },
    { &ADCCalFactor, sizeof(ADCCalFactor), ADC_CAL_ADDRESS },
    { &colourCal, sizeof(colourCal), COLOUR_CAL_ADDRESS }
  };

  for (auto& block : blocks) {
    byte buffer[block.size];
    memcpy(buffer, block.data, block.size);
    dueFlashStorage.write(block.address, buffer, block.size);
  }
  dueFlashStorage.write(0, 0); //Unset the calibration needed flag
}



/**
 * @brief Interactive calibration routine for a load bank.
 *
 * Guides the operator through setting the PWM duty to obtain 1A and 3A
 * reference points measured with an external meter. Computes and stores a
 * linear gain and offset for converting ADC counts to current.
 *
 * @param port Load bank number (1 or 2)
 * @return true  Calibration succeeded
 * @return false Calibration failed or invalid port
 */
bool calibrate::calibrateLoad(int port){

  if (port != 1 && port != 2) {
    Serial.println("Invalid port number: " + String(port));
    return false;
  }

  int PWMchannel = port + 1;
  byte currentPort = (port == 1) ? CN1_CURRENT
                    :(port == 2) ? CN2_CURRENT
                    :0;
  byte loadDisable = (port == 1) ? LOAD1_DISABLE
                    :(port == 2) ? LOAD2_DISABLE
                    :0;

  digitalWrite(loadDisable, LOW);

  printToLCD("Load " + String(port) + " Cal. Connect voltmeter and test unit then press OK, 10mv=1A");
  delay(1000);
  while(digitalRead(OK) == HIGH){}


  //Step 1 - find duty cycle needed to draw 1A
  printToLCD("Load " + String(port) + " Calibration Press UP/DOWN until voltmeter reads 10mV then press OK");
  delay(1000);  

  int loadDuty = 200;                                  //20% duty cycle, roughly 1A
  while(digitalRead(OK) == HIGH){                //Manually adjust the load setting with UP and DOWN keys, wait for OK press to save the setting
    if(digitalRead(UP) == LOW){
      if(loadDuty == 1000){                        //If the load reaches 100% and hasn't risen to the target current, reset to zero and fail the calibration
        PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = 0;
        digitalWrite(loadDisable, HIGH);
        return false;
      }
      loadDuty++;
      Serial.println("Load duty cycle: " + String(loadDuty / 10) + "%");
      PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = loadDuty;
      delay(200);
    }

    if(digitalRead(DOWN) == LOW){
      if(loadDuty > 0){
        loadDuty--;
      }
      else{
        digitalWrite(loadDisable, HIGH);
        PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = 0;
        return false;
      }
      Serial.println("Load duty cycle: " + String(loadDuty / 10) + "%");
      PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = loadDuty;      
      delay(200);
    }
  }

  float oneAmpReading = multiSampleRead(currentPort);
   
  //Intermediate step so that the following 3A step isn't accidentally skipped 
  printToLCD("Load " + String(port) + " Calibration Press OK to continue");
  delay(1000);
  while(digitalRead(OK) == HIGH){}

  //Step 2 - find duty cycle needed to draw 3A
  printToLCD("Load " + String(port) + " Calibration  Press UP/DOWN until the voltmeter reads 30mV then press OK");
  delay(1000);

  loadDuty = 600;                                 //60% duty cycle, roughly 3A
  while(digitalRead(OK) == HIGH){               //Manually adjust the load setting with UP and DOWN keys, wait for OK press to save the setting
    if(digitalRead(UP) == LOW){
      if(loadDuty == 1000){                       //If the load reaches 100% and hasn't risen to the target current, reset to zero and fail the calibration
        PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = 0;
        digitalWrite(loadDisable, HIGH);
        return false;
      }
      loadDuty++;
      Serial.println("Load duty cycle: " + String(loadDuty / 10) + "%");
      PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = loadDuty;
      delay(200);
    }

    if(digitalRead(DOWN) == LOW){
      if(loadDuty > 0){
        loadDuty--;
      }
      else{
        PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = 0;
        digitalWrite(loadDisable, HIGH);
        return false;
      }
      Serial.println("Load duty cycle: " + String(loadDuty / 10) + "%");
      PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = loadDuty;      
      delay(200);
    }
  }

  float threeAmpReading = multiSampleRead(currentPort);

  //Step 3 - calculate calibration gain and offset values, assuming linear load current response.
  float gain = (threeAmpReading - oneAmpReading) /2;      //Gain = ADC counts per amp
  float offset = oneAmpReading - gain;                    //Offset = ADC counts for zero current

  if(port == 1){
  load1Cal.gain = gain;                       
  load1Cal.offset = offset;                   
  load1Cal.oneAmpReading = oneAmpReading;
  load1Cal.threeAmpReading = threeAmpReading;
  }

  if(port == 2){
  load2Cal.gain = gain;
  load2Cal.offset = offset;
  load2Cal.oneAmpReading = oneAmpReading;
  load2Cal.threeAmpReading = threeAmpReading;
  }

  Serial.println("Load " + String(port) + " calibrated gain: " + String(gain, 2) + ", offset: " + String(offset, 2));
  Serial.println(String("1A reading: ") + String(oneAmpReading, 1) + "\n3A reading: " + String(threeAmpReading, 1));
  
  digitalWrite(loadDisable, HIGH);
  PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = 0;
  return true;

}

/**
 * @brief Calibrate the AS7341 colour sensor against ambient light.
 *
 * Reads all visible channels and checks for excessive ambient light or
 * channel outliers. If within limits, stores the measured channel offsets
 * into the colourCal array.
 *
 * @return true  Colour calibration accepted
 * @return false Calibration failed (excessive ambient light or read error)
 */
bool calibrate::calibrateColour() {

  digitalWrite(HV_ENABLE, LOW);
  digitalWrite(_10V_ENABLE, LOW);
  printToLCD("Colour sensor Cal. Ensure ambient light level is normal then press OK");
  delay(1000);
  while(digitalRead(OK) == HIGH){}
  printToLCD("Push down clamp then press OK");
  delay(1000);
  while(digitalRead(OK) == HIGH){}

  uint32_t total = 0;
  uint16_t chn = 0;
  bool pass = true;
  uint16_t ch[8] = {0};

  if (!as7341.readAllChannels()){
    printToLCD("Sensor data read failed");
    Serial.println("Sensor data read failed");
    delay(1000);
    return false;
  }
  Serial.println("Colour sensor raw data readout: ");

  for (int i = 0; i < 8; i++) {
    chn = as7341.getChannel(VisChannels[i]);
    ch[i] = chn;
    Serial.print(String(chn) + ", ");
    total += chn;
    //Fail the cal if the ambient is too bright or any one channel stands out too much, placeholder values
    if(chn >= MAX_CHANNEL_CAL_OFFSET || total >= MAX_TOTAL_CAL_OFFSET){
      pass = false;
    } 
  }
  Serial.println("Total: "+ String(total));

  if(pass){
    memcpy(&colourCal, ch, sizeof(colourCal));
  }
  else{
    printToLCD("Excessive ambient light leakage at LED sensor");
    Serial.println("Calibration failed: excessive light leakage detected - ensure the jig is assembled correctly and not in direct sunlight then try again");
    delay(3000);
  }
  return pass;
}


/**
 * @brief Populate runtime calibration structures with safe default values.
 *
 * Used when no valid calibration exists in flash. Sets reasonable default
 * gains/offsets for the load banks, a nominal ADC scaling factor and clears
 * the colour offsets.
 */
void calibrate::setDefault(){ 

  //First time running, set defaults
  load1Cal.gain = 190;       
  load1Cal.offset = 4;
  load1Cal.oneAmpReading = 0;     
  load1Cal.threeAmpReading = 0;
  load2Cal.gain = 188;       
  load2Cal.offset = -9;
  load2Cal.oneAmpReading = 0;     
  load2Cal.threeAmpReading = 0;
  ADCCalFactor = 0.00080566; //default = 3.3/4096
  for (int i = 0; i < 8; i++){
  colourCal[i] = {0};
  }
  printToLCD("Default calibration values loaded");
  delay(1000);

}

/**
 * @brief Calibrate the ADC scaling factor used for voltage measurements.
 *
 * Prompts the operator to measure the main supply with a calibrated meter
 * and enter the value. Computes the ADC scaling factor based on the 11:1
 * divider and the multi-sampled ADC reading. Performs a sanity range check
 * before accepting the value.
 *
 * @return true  ADC calibration accepted
 * @return false Computed factor outside expected range or invalid input
 */
bool calibrate::calibrateADC(){

  printToLCD("Measure main supply voltage with a calibrated meter then press OK");
  delay(1000);
  while(digitalRead(OK)){}
  printToLCD("Press UP/DOWN to input measured supply voltage then press OK:");

  float inputVoltageRef = 27.00;
  delay(500);

  while(digitalRead(OK)){
    printToLCD(String(inputVoltageRef , 2) + "V",13,3,false);
    if(digitalRead(UP) == LOW) inputVoltageRef += 0.01;
    if(digitalRead(DOWN) == LOW) inputVoltageRef -= 0.01;
    delay(70);    //70ms delay 'feels' best to use
  }

  float result = inputVoltageRef / 11.0 / multiSampleRead(VINF_MEASURE) ; // 11:1 voltage divider

  if(result < 0.0007 || result > 0.0009){     
    Serial.println("ADC Cal sanity check pass range 0.0007-0.0009, measured " + String(result, 8));
    return false;
  }
  else{
    ADCCalFactor = result;
    return true;
  }
}
