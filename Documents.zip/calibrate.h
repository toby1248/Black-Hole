/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : calibrate.h
 * Description  : calibration functions for the USB universal tester
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */

#ifndef CALIBRATE_H
#define CALIBRATE_H

#include <Adafruit_AS7341.h>
#include <wire.h>
#include <stdint.h>
#include <Arduino.h>
#include <DueFlashStorage.h>
#include "globaldefines.h"
#include "productdata.h"
#include "ui.h"



class calibrate{
    public:

    DueFlashStorage dueFlashStorage;

    //Calibration data for the loads
    struct loadcal {
        float gain;
        float offset;
        float oneAmpReading;
        float threeAmpReading;
    };
    loadcal load1Cal;
    loadcal load2Cal;

    //Ambient light calibration data for the AS7341 colour channels
    uint16_t colourCal[8];

    //Calibration data for the arduino ADC
    float ADCCalFactor;

    bool isBlank();

    bool loadData();

    void save();

    bool calibrateLoad(int port);

    //bool calibrate1();

    //bool calibrate2();

    /**
     * @brief Calibrates the ADC using the input voltage supply as a reference.
     *
     * @note 
     * - Writes the calibration factor to flash at address 44 before returning
     *
     * @return The calculated calibration factor as a float.
     */ 
    bool calibrateADC();

    /**
     * @brief Calibrates the AS7341 colour sensor under typical lighting.
     *
     * @details
     * 1. Gives instructions on the LCD display
     * 2. Measures sensor response with a dummy unit under the clamp.
     *
     * If all channels are within acceptable limits, calibration data is saved to flash memory.
     * If calibration fails due to excessive light or noise, a failout is triggered.
     * After success, the user can validate production units with live colour readout.
     *
     * @return true if calibration succeeds; false if it fails.
     */ 
    bool calibrateColour();

    //DEV ONLY FUNCTION, MUST NOT BE CALLED IN PRODUCTION BUILDS
    void setDefault();
};

float multiSampleRead(byte pin);


#endif