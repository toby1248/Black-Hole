#include "database.h"

extern void streamProductTablesAsJson();

/**
 * @brief Construct a new Database object and initialise runtime defaults.
 *
 * Sets up in-memory log pointers and default behaviour for serial output and
 * immediate flash saves for each log level.
 */
Database::Database() {
  ramHead = 0;
  ramCount = 0;
  flashWritePtr = DB_FLASH_REGION_ADDR;
  flashLoopOverwrite = false;
  counterSlotsNextIndex = 0;

  // defaults
  levelSendSerial[DBG]   = false;
  levelSendSerial[INFO]  = true;
  levelSendSerial[WARN]  = true;
  levelSendSerial[ERROR] = true;
  levelSendSerial[ALERT] = true;

  levelImmediateSave[DBG]   = false;
  levelImmediateSave[INFO]  = false;
  levelImmediateSave[WARN]  = false;
  levelImmediateSave[ERROR] = true;
  levelImmediateSave[ALERT] = true;
}

/**
 * @brief Initialise the Database subsystem.
 *
 * Loads persistent counters from flash and locates the next write pointer for
 * the log flash region.
 */
void Database::begin() {
  loadCountersFromFlash();
  scanFlashForWritePtr();
}

/**
 * @brief Format and record a log entry at the given level.
 *
 * This variant uses the configured serial and immediate-save behaviour for
 * the provided log level. The formatted message is stored in the RAM buffer
 * and optionally printed to Serial and flushed to flash.
 *
 * @param level Log level (DBG/INFO/WARN/ERROR/ALERT)
 * @param fmt   printf-style format string followed by arguments
 */
void Database::log(LogLevel level, const char* fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  char buf[DB_RAM_MSG_LEN];
  vformatToBuf(buf, sizeof(buf), fmt, ap);
  va_end(ap);

  uint32_t ts = millis();
  bool sendSerial = levelSendSerial[level];
  bool immediateSave = levelImmediateSave[level];

  if (sendSerial) {
    Serial.print("[");
    switch(level){
      case DBG: Serial.print("DBG"); break;
      case INFO: Serial.print("INF"); break;
      case WARN: Serial.print("WRN"); break;
      case ERROR: Serial.print("ERR"); break;
      case ALERT: Serial.print("ALT"); break;
    }
    Serial.print(" ");
    Serial.print(ts);
    Serial.print("] ");
    Serial.println(buf);
  }

  ramStore(ts, level, buf, (uint16_t)strlen(buf));

  if (immediateSave) {
    saveRamToFlash();
  }
}

/**
 * @brief Format and record a log entry with explicit serial/save controls.
 *
 * Allows overriding whether the message is printed to Serial and whether it
 * should be saved immediately to flash. If sendSerialOverride == 0xFF the
 * per-level default is used.
 *
 * @param level               Log level
 * @param sendSerialOverride  0 = don't send, 1 = send, 0xFF = use level default
 * @param saveImmediately     If true the RAM buffer will be flushed to flash
 * @param fmt                 printf-style format string and args
 */
void Database::log(LogLevel level, uint8_t sendSerialOverride, bool saveImmediately, const char* fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  char buf[DB_RAM_MSG_LEN];
  vformatToBuf(buf, sizeof(buf), fmt, ap);
  va_end(ap);

  uint32_t ts = millis();
  bool send = (sendSerialOverride == 0xFF) ? levelSendSerial[level] : (sendSerialOverride != 0);
  if (send) {
    Serial.print("[");
    switch(level){
      case DBG: Serial.print("DBG"); break;
      case INFO: Serial.print("INF"); break;
      case WARN: Serial.print("WRN"); break;
      case ERROR: Serial.print("ERR"); break;
      case ALERT: Serial.print("ALT"); break;
    }
    Serial.print(" ");
    Serial.print(ts);
    Serial.print("] ");
    Serial.println(buf);
  }
  ramStore(ts, level, buf, (uint16_t)strlen(buf));
  if (saveImmediately) saveRamToFlash();
}

/**
 * @brief Store a formatted log entry into the in-RAM circular buffer.
 *
 * Copies up to DB_RAM_MSG_LEN-1 characters and advances the head pointer.
 *
 * @param timestamp  Millis timestamp for the entry
 * @param level      Log level as an enum
 * @param txt        Pointer to the message text
 * @param len        Length of the message in bytes
 */
void Database::ramStore(uint32_t timestamp, LogLevel level, const char* txt, uint16_t len) {
  if (len >= DB_RAM_MSG_LEN) len = DB_RAM_MSG_LEN - 1;
  RamEntry &e = ramLog[ramHead];
  e.timestamp = timestamp;
  e.level = (uint8_t)level;
  e.len = len;
  memcpy(e.msg, txt, len);
  e.msg[len] = '\0';
  ramHead = (ramHead + 1) % DB_RAM_LOG_ENTRIES;
  if (ramCount < DB_RAM_LOG_ENTRIES) ramCount++;
}

/**
 * @brief Return a pointer to the flash memory at a given address.
 *
 * Uses DueFlashStorage to read a pointer to flash memory for zero-copy
 * inspection of stored entries.
 *
 * @param address Absolute flash address to read
 * @return const uint8_t* Pointer to data in flash or nullptr on error
 */
const uint8_t* Database::flashReadPtr(uint32_t address) {
  return dueFlash.readAddress(address);
}

/**
 * @brief Write a buffer into flash memory at the specified address.
 *
 * Wrapper around DueFlashStorage::write. Returns true for compatibility with
 * callers; DueFlashStorage handles underlying flash sector management.
 *
 * @param address Absolute flash address to write
 * @param buf     Source buffer
 * @param size    Number of bytes to write
 * @return true   Always returns true (assumes DueFlashStorage succeeded)
 */
bool Database::flashWrite(uint32_t address, const uint8_t* buf, size_t size) {
  // DueFlashStorage::write(address, buffer, length) is used elsewhere in this project (see calibrate)
  dueFlash.write(address, (byte*)buf, (uint32_t)size);
  return true;
}

/**
 * @brief Scan the log region in flash to find the next free write pointer.
 *
 * Walks stored entries and validates the DB_LOG_MAGIC. If loop overwrite is
 * enabled it wraps to the start, otherwise it sets the write pointer to the
 * end of the region to signal 'full'.
 */
void Database::scanFlashForWritePtr() {
  uint32_t addr = DB_FLASH_REGION_ADDR;
  uint32_t end = DB_FLASH_REGION_ADDR + DB_FLASH_REGION_SIZE;
  while (addr + 12 < end) {
    const uint8_t* p = flashReadPtr(addr);
    if (!p) break;
    uint32_t magic;
    memcpy(&magic, p, sizeof(uint32_t));
    if (magic != DB_LOG_MAGIC) {
      flashWritePtr = addr;
      return;
    }
    uint32_t ts;
    uint16_t len;
    uint8_t lvl;
    memcpy(&ts, p + 4, sizeof(uint32_t));
    memcpy(&lvl, p + 8, sizeof(uint8_t));
    memcpy(&len, p + 9, sizeof(uint16_t));
    uint32_t entrySize = 4 + 4 + 1 + 2 + (uint32_t)len;
    if (entrySize == 0) {
      flashWritePtr = addr;
      return;
    }
    addr += entrySize;
  }
  if (flashLoopOverwrite) {
    flashWritePtr = DB_FLASH_REGION_ADDR;
  } else {
    flashWritePtr = DB_FLASH_REGION_ADDR + DB_FLASH_REGION_SIZE;
  }
}

/**
 * @brief Append a log entry to the flash log region.
 *
 * Constructs the entry header (magic, timestamp, level, length) and writes
 * the header+payload to flash. Updates the persistent flash metadata pointer
 * after a successful write.
 *
 * @param timestamp Millis timestamp
 * @param level     Log level
 * @param txt       Message text buffer
 * @param len       Number of bytes in message
 * @return true     Write succeeded
 * @return false    Not enough room and looping disabled
 */
bool Database::flashAppendEntry(uint32_t timestamp, LogLevel level, const char* txt, uint16_t len) {
  if (flashWritePtr + 16 + len > DB_FLASH_REGION_ADDR + DB_FLASH_REGION_SIZE) {
    if (!flashLoopOverwrite) return false;
    flashWritePtr = DB_FLASH_REGION_ADDR;
  }

  uint32_t magic = DB_LOG_MAGIC;
  uint32_t ts = timestamp;
  uint8_t lvl = (uint8_t) level;
  uint16_t llen = len;

  size_t headerSize = 4 + 4 + 1 + 2;
  size_t total = headerSize + llen;
  uint8_t buf[headerSize + DB_RAM_MSG_LEN];
  memcpy(buf + 0, &magic, 4);
  memcpy(buf + 4, &ts, 4);
  memcpy(buf + 8, &lvl, 1);
  memcpy(buf + 9, &llen, 2);
  if (llen) memcpy(buf + headerSize, txt, llen);

  if (!flashWrite(flashWritePtr, buf, total)) return false;

  flashWritePtr += total;
  uint32_t meta = flashWritePtr;
  dueFlash.write(DB_FLASH_META_ADDR, (byte*)&meta, sizeof(meta));
  return true;
}

/**
 * @brief Flush all RAM-stored log entries to the flash log region.
 *
 * Iterates the circular RAM buffer in chronological order and appends each
 * entry to flash. Clears the RAM buffer on success.
 *
 * @return true  All entries saved
 * @return false A flash append failed (caller must handle persistence)
 */
bool Database::saveRamToFlash() {
  if (ramCount == 0) return true;
  uint16_t oldest = (ramHead + DB_RAM_LOG_ENTRIES - ramCount) % DB_RAM_LOG_ENTRIES;
  for (uint16_t i = 0; i < ramCount; i++) {
    uint16_t idx = (oldest + i) % DB_RAM_LOG_ENTRIES;
    RamEntry &e = ramLog[idx];
    if (!flashAppendEntry(e.timestamp, (LogLevel)e.level, e.msg, e.len)) {
      return false;
    }
  }
  ramHead = 0;
  ramCount = 0;
  return true;
}

/**
 * @brief Load persistent counters from the flash counter slots.
 *
 * Scans configured counter slots for a valid magic and the highest sequence
 * number. Loads the counters from that slot and sets the next slot index for
 * future writes.
 */
void Database::loadCountersFromFlash() {
  for (unsigned i = 0; i < DB_MAX_COUNTERS; ++i) counters[i] = 0;

  uint32_t slotSize = 4 + 4 + (4 * DB_MAX_COUNTERS);
  uint32_t base = DB_FLASH_COUNTERS_ADDR;
  uint32_t bestSeq = 0;
  int bestSlot = -1;
  for (int s = 0; s < DB_COUNTER_SLOTS; ++s) {
    uint32_t addr = base + s * slotSize;
    const uint8_t *p = flashReadPtr(addr);
    if (!p) break;
    uint32_t magic;
    memcpy(&magic, p, 4);
    if (magic != DB_COUNTER_MAGIC) continue;
    uint32_t seq;
    memcpy(&seq, p + 4, 4);
    if (seq >= bestSeq) {
      bestSeq = seq;
      bestSlot = s;
    }
  }
  if (bestSlot >= 0) {
    uint32_t addr = base + bestSlot * slotSize;
    const uint8_t *p = flashReadPtr(addr);
    memcpy(counters, p + 8, 4 * DB_MAX_COUNTERS);
    counterSlotsNextIndex = (bestSlot + 1) % DB_COUNTER_SLOTS;
  } else {
    counterSlotsNextIndex = 0;
  }
}

/**
 * @brief Save the current counters to flash in the next rotating slot.
 *
 * Uses a simple magic+sequence+payload layout so the latest valid slot can
 * be determined by sequence when reading. Advances the slot pointer on
 * success.
 *
 * @return true  Save succeeded
 * @return false Flash write failed
 */
bool Database::saveCountersToFlash() {
  uint32_t slotSize = 4 + 4 + (4 * DB_MAX_COUNTERS);
  uint8_t buf[4 + 4 + (4 * DB_MAX_COUNTERS)];
  uint32_t magic = DB_COUNTER_MAGIC;
  uint32_t seq = millis();
  memcpy(buf + 0, &magic, 4);
  memcpy(buf + 4, &seq, 4);
  memcpy(buf + 8, counters, 4 * DB_MAX_COUNTERS);

  uint32_t addr = DB_FLASH_COUNTERS_ADDR + counterSlotsNextIndex * slotSize;
  if (!flashWrite(addr, buf, sizeof(buf))) return false;
  counterSlotsNextIndex = (counterSlotsNextIndex + 1) % DB_COUNTER_SLOTS;
  return true;
}

/**
 * @brief Atomically increment an in-memory counter.
 *
 * @param id  Counter index (0..DB_MAX_COUNTERS-1)
 * @param inc Amount to increment
 */
void Database::incrementCounter(uint8_t id, uint32_t inc) {
  if (id >= DB_MAX_COUNTERS) return;
  counters[id] += inc;
}

/**
 * @brief Retrieve the current value of an in-memory counter.
 *
 * @param id Counter index
 * @return uint32_t Counter value or 0 if the index is invalid
 */
uint32_t Database::getCounter(uint8_t id) {
  if (id >= DB_MAX_COUNTERS) return 0;
  return counters[id];
}

/**
 * @brief Set an in-memory counter to a specific value.
 *
 * @param id    Counter index
 * @param value New counter value
 */
void Database::setCounter(uint8_t id, uint32_t value) {
  if (id >= DB_MAX_COUNTERS) return;
  counters[id] = value;
}

/**
 * @brief Dump RAM and flash logs to the Serial console.
 *
 * Prints the current in-RAM circular buffer followed by parsed entries from
 * the flash log region until an invalid magic or end of region is reached.
 */
void Database::dumpSerial() {
  Serial.println("=== LOG DUMP START ===");
  uint16_t count = ramCount;
  uint16_t oldest = (ramHead + DB_RAM_LOG_ENTRIES - count) % DB_RAM_LOG_ENTRIES;
  for (uint16_t i = 0; i < count; ++i) {
    uint16_t idx = (oldest + i) % DB_RAM_LOG_ENTRIES;
    RamEntry &e = ramLog[idx];
    Serial.print("[RAM ");
    Serial.print(e.timestamp);
    Serial.print("] ");
    switch(e.level){
      case DBG: Serial.print("DBG: "); break;
      case INFO: Serial.print("INF: "); break;
      case WARN: Serial.print("WRN: "); break;
      case ERROR: Serial.print("ERR: "); break;
      case ALERT: Serial.print("ALT: "); break;
    }
    Serial.println(e.msg);
  }

  Serial.println("--- FLASH LOGS ---");
  uint32_t addr = DB_FLASH_REGION_ADDR;
  uint32_t end = DB_FLASH_REGION_ADDR + DB_FLASH_REGION_SIZE;
  while (addr + 12 <= end) {
    const uint8_t *p = flashReadPtr(addr);
    if (!p) break;
    uint32_t magic;
    memcpy(&magic, p, 4);
    if (magic != DB_LOG_MAGIC) break;
    uint32_t ts; uint8_t lvl; uint16_t len;
    memcpy(&ts, p + 4, 4);
    memcpy(&lvl, p + 8, 1);
    memcpy(&len, p + 9, 2);
    char tmp[DB_RAM_MSG_LEN];
    if (len > 0 && len < DB_RAM_MSG_LEN) {
      memcpy(tmp, p + 11, len);
      tmp[len] = '\0';
    } else {
      tmp[0] = '\0';
    }
    Serial.print("[FLASH ");
    Serial.print(ts);
    Serial.print("] ");
    switch((LogLevel)lvl){
      case DBG: Serial.print("DBG: "); break;
      case INFO: Serial.print("INF: "); break;
      case WARN: Serial.print("WRN: "); break;
      case ERROR: Serial.print("ERR: "); break;
      case ALERT: Serial.print("ALT: "); break;
    }
    Serial.println(tmp);
    uint32_t entrySize = 11 + (uint32_t)len;
    addr += entrySize;
  }
  Serial.println("=== LOG DUMP END ===");
}

/**
 * @brief Handle simple serial commands to inspect and manage logs/counters.
 *
 * Supported commands: GETLOG, ERASELOG, GETCOUNTERS, SAVECTR.
 */
void Database::handleSerialCommands() {
  if (!Serial.available()) return;
  String line = Serial.readStringUntil('\n');
  handleSerialCommands(line);
}

void Database::handleSerialCommands(const String& commandLine) {
  String line = commandLine;
  line.trim();
  if (line.length() == 0) return;
  if (line.equalsIgnoreCase("GETLOG")) {
    dumpSerial();
  } else if (line.equalsIgnoreCase("ERASELOG")) {
    uint8_t marker = 0xFF;
    dueFlash.write(DB_FLASH_REGION_ADDR, &marker, 1);
    flashWritePtr = DB_FLASH_REGION_ADDR;
    Serial.println("Logs erased (note: actual flash sector erase depends on DueFlashStorage internals).");
  } else if (line.equalsIgnoreCase("GETCOUNTERS")) {
    Serial.println("Counters:");
    for (uint8_t i = 0; i < DB_MAX_COUNTERS; ++i) {
      Serial.print("C");
      Serial.print(i);
      Serial.print(": ");
      Serial.println(counters[i]);
    }
  } else if (line.equalsIgnoreCase("SAVECTR")) {
    if (saveCountersToFlash()) Serial.println("Counters saved");
    else Serial.println("Counter save failed");
  } else if (line.equalsIgnoreCase("PRODUCTDATA")) {
    streamProductTablesAsJson();
  } else {
    Serial.print("Unknown command: ");
    Serial.println(line);
    Serial.println("Commands: GETLOG, ERASELOG, GETCOUNTERS, SAVECTR, PRODUCTDATA");
  }
}

/**
 * @brief Safe vsnprintf wrapper that always NUL-terminates the buffer.
 *
 * @param buf     Destination buffer
 * @param bufSize Size of destination buffer
 * @param fmt     Format string
 * @param ap      va_list of arguments
 */
void Database::vformatToBuf(char* buf, size_t bufSize, const char* fmt, va_list ap) {
  if (!fmt || !buf) return;
  int n = vsnprintf(buf, bufSize, fmt, ap);
  if (n < 0) buf[0] = '\0';
  else if ((size_t)n >= bufSize) buf[bufSize-1] = '\0';
}

/**
 * @brief Enable or disable wrap-around behaviour for the flash log region.
 *
 * When enabled new entries will overwrite the oldest entries in flash once
 * the region is full. When disabled the region will be treated as full and
 * further appends will fail.
 *
 * @param enable true to enable loop overwrite, false to disable
 */
void Database::setFlashLoopOverwrite(bool enable) {
  flashLoopOverwrite = enable;
}
