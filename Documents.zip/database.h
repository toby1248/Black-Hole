#ifndef DATABASE_H
#define DATABASE_H

#include <Arduino.h>
#include <DueFlashStorage.h>
#include <stdarg.h>

// ----------------- CONFIG -----------------
#define DB_RAM_LOG_ENTRIES   128
#define DB_RAM_MSG_LEN       128
#define DB_FLASH_REGION_ADDR 4096
#define DB_FLASH_REGION_SIZE (64*1024)
#define DB_FLASH_META_ADDR   1024
#define DB_FLASH_COUNTERS_ADDR 8192
#define DB_MAX_COUNTERS      32
#define DB_COUNTER_SLOTS     16

#define DB_LOG_MAGIC 0xDB10DB10UL
#define DB_COUNTER_MAGIC 0xC0DE7171UL


class Database {
public:
  enum LogLevel : uint8_t {
    DBG = 0,
    INFO,
    WARN,
    ERROR,
    ALERT
  };

  struct RamEntry {
    uint32_t timestamp;
    uint8_t  level;
    uint16_t len;
    char     msg[DB_RAM_MSG_LEN];
  };

  Database();

  void begin();

  // primary logging (printf style)
  void log(LogLevel level, const char* fmt, ...);
  void log(LogLevel level, uint8_t sendSerialOverride /*0/1/0xFF*/, bool saveImmediately, const char* fmt, ...);

  bool saveRamToFlash();
  bool saveCountersToFlash();
  void dumpSerial();
  void handleSerialCommands();
  void handleSerialCommands(const String& commandLine);

  void incrementCounter(uint8_t id, uint32_t inc = 1);
  uint32_t getCounter(uint8_t id);
  void setCounter(uint8_t id, uint32_t value);

  void setFlashLoopOverwrite(bool enable);

private:
  DueFlashStorage dueFlash;

  RamEntry ramLog[DB_RAM_LOG_ENTRIES];
  volatile uint16_t ramHead;
  volatile uint16_t ramCount;

  uint32_t flashWritePtr;
  bool flashLoopOverwrite;

  bool levelSendSerial[5];
  bool levelImmediateSave[5];

  uint32_t counters[DB_MAX_COUNTERS];
  uint32_t counterSlotsNextIndex;

  void ramStore(uint32_t timestamp, LogLevel level, const char* txt, uint16_t len);
  bool flashAppendEntry(uint32_t timestamp, LogLevel level, const char* txt, uint16_t len);
  void scanFlashForWritePtr();
  void loadCountersFromFlash();
  bool flashWrite(uint32_t address, const uint8_t* buf, size_t size);
  const uint8_t* flashReadPtr(uint32_t address);

  void vformatToBuf(char* buf, size_t bufSize, const char* fmt, va_list ap);
};

#endif // DATABASE_H
