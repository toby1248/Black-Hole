/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : functions.cpp
 * Description  : Product test functions and associated helpers
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-09-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */


#include <Adafruit_AS7341.h>
#include <Wire.h>
#include <stdint.h>
#include <Arduino.h>
#include <chip.h>
#include "globaldefines.h"
#include "ui.h"
#include "functions.h"




byte readBuf[READ_BUFF_LENGTH] = {0};
byte writeBuf[WRITE_BUFF_LENGTH] = {0};

bool loadFailed = false;

Adafruit_AS7341 as7341;

//Better for readability to convert the colour sensor channel indices to these names
static const char* colourNames[8] = {
  "Violet", "Blue", "Blue", "Green", "Green", "Yellow", "Red", "Red"
};

//Visible channel order for AS7341
const as7341_color_channel_t VisChannels[8] = {
  AS7341_CHANNEL_415nm_F1, // 415 nm (Violet)
  AS7341_CHANNEL_445nm_F2, // 445 nm (Blue)
  AS7341_CHANNEL_480nm_F3, // 480 nm (Blue/Cyan)
  AS7341_CHANNEL_515nm_F4, // 515 nm (Green)
  AS7341_CHANNEL_555nm_F5, // 555 nm (Green)
  AS7341_CHANNEL_590nm_F6, // 590 nm (Yellow/Amber)
  AS7341_CHANNEL_630nm_F7, // 630 nm (Red)
  AS7341_CHANNEL_680nm_F8  // 680 nm (Deep Red)
};

/**
 * @brief Start AS7341 colour sensor
 *
 * Sets up the hardware, initialises I2C, verifies the connection. Prints an error
 * and enters an infinite loop if connection failed. Configures the chip if successful
 *  
 */
  void colourInit(){
    if (!as7341.begin()){
      printToLCD("AS7341 colour sensor chip not found");
      blink();
    }
    as7341.setATIME(100);
    as7341.setASTEP(999);
    as7341.setGain(AS7341_GAIN_128X);
    Serial.println("Colour sensor AS7341 initialised");   
  }

/**
 * @brief Determines the dominant LED colour using AS7341 visible spectrum readings.
 *
 * @param verbose  Prints raw output data to serial if true, default true.
 * This function reads all 8 visible channels from the AS7341 sensor and identifies the peak intensity.
 * Calibration readings are subtracted from the measurement to increase contrast
 * It performs a dominance test to ensure the peak channel is sufficiently stronger than its neighbors and the rest of the spectrum.
 * If total light is below a threshold, returns "Dark". If no clear peak is found, returns "White".
 *  
 * @return A String representing the detected colour name (e.g., "Red", "Green", "Blue").
 */
String getLEDColour(bool verbose) {
  uint16_t total = 0;
  int peakIdx = -1;
  uint16_t peakVal = 0;
  delay(100);

  uint16_t ch[8] = {0};
  if (!as7341.readAllChannels()){
    return "Error";
  }
  if (verbose) Serial.print("Raw colour values: ");
  for (int i = 0; i < 8; i++) { 
    uint16_t v = as7341.getChannel(VisChannels[i]);

    if(v == 65535){
      return "Saturated";
    }

    ch[i] = (v <= Calibrate.colourCal[i]) ? 0 : v - Calibrate.colourCal[i];
    total += ch[i];
    if(verbose) Serial.print(String(v)  + " ");
    if (ch[i] > peakVal) {
      peakVal = ch[i];
      peakIdx = i;
    }
  }
  if(verbose) Serial.println(" ");
  // placeholder values
  if (total < 200 && peakVal < 100) return "Dark";

  // Sum neighbors (guard edges)
  uint32_t adjacent = 0;
  uint32_t distant = 0;
  if (peakIdx > 0)   adjacent += ch[peakIdx - 1];
  if (peakIdx < 7)   adjacent += ch[peakIdx + 1];
  distant = total - adjacent - peakVal;

  // Dominance ratio test: peak >= both adjacent channels AND >= the remaining 5 channels combined
  if (peakVal >= adjacent && peakVal >= distant) {
    return String(colourNames[peakIdx]);
  }

  // Fallback if not dark but theres no clear peak
  return "White";
}


/**
 * @brief Maximum ADC accuracy for calibration, slow
 *  
 * @param pin  The analog input pin to read from.
 *  
 * The function performs 100 analog reads from the specified pin, with a 1ms delay between each
 * to integrate over time and reduce noise. It then returns the average value as a float.
 *
 * @return The averaged analog reading from the specified pin.
 */
float multiSampleRead(byte pin) {
  uint32_t readingAverage = 0;

  for (int i = 0; i < 100; i++) {
    readingAverage += analogRead(pin);
    delay(1);  // Integrate over time to average out ripple
  }

  float result = readingAverage / 100.0;
  return result;
}



/**
 * @brief Checks that the DUT's reverse polarity protection is functional.
 *  
 * @param waitTime  The time to wait after initialising before running the test.
 *    
 * The function disconnects the positive supply voltages and switches in the negative rail. 
 * It then waits the specified time to allow capacitors to charge before reading the test result
 * from the INVERSE_VERIFY pin  
 * 
 * @note Switches off both positive voltage rails before the test but does not switch either back on again after
 *  
 * @return True = test pass, false = test fail.
 */ 
bool inversePolarity(int waitTime){
  digitalWrite(HV_ENABLE, LOW);
  digitalWrite(_10V_ENABLE, LOW);
  digitalWrite(INVERSE_DISABLE, LOW);     
  delay(waitTime);
  bool pass = digitalRead(INVERSE_VERIFY);
  digitalWrite(INVERSE_DISABLE, HIGH);
  return(pass);
}


/**
 * @brief Writes data to an AP33772S chip over I2C using a specified TwoWire interface.
 *
 * @param twowire   Reference to the I2C interface (e.g., Wire or Wire1).
 * @param slvAddr   7-bit I2C slave address of the AP33772S chip.
 * @param cmdAddr   Command/register address to write to.
 * @param writeBuf  Pointer to the buffer containing data to be written.
 * @param len       Number of bytes to write from the buffer.
 *
 * After transmission, the write buffer is cleared by setting all elements to zero.
 */
void i2c_write(TwoWire &twowire, byte slvAddr, byte cmdAddr, byte writeBuf[], byte len) {
  twowire.beginTransmission(slvAddr);
  twowire.write(cmdAddr);
  for (byte i = 0; i < len; i++) {
    twowire.write(writeBuf[i]);
  }
  twowire.endTransmission();

  for (byte i = 0; i < WRITE_BUFF_LENGTH; i++) {
    writeBuf[i] = 0;
  }
}

/**
 * @brief Reads data from a PD chip over I2C using a specified TwoWire interface.
 *
 * @param wirePort  Reference to the I2C interface (e.g., Wire or Wire1).
 * @param slvAddr   7-bit I2C slave address of the PD chip - default 0x52 for AP77332S.
 * @param cmdAddr   Command/register address to initiate the read.
 * @param len       Number of bytes to read from the device.
 * @param readBuf   Pointer to the buffer where the read data will be stored.
 *
 * The function first clears the read buffer, then sends the command address.
 * If the transmission is successful, it requests 'len' bytes from the slave device
 * and stores them in the read buffer.
 */
void i2c_read(TwoWire &wirePort, byte slvAddr, byte cmdAddr, byte len, byte *readBuf) {
  // Clear buffer
  memset(readBuf, 0, READ_BUFF_LENGTH);

  wirePort.beginTransmission(slvAddr);
  wirePort.write(cmdAddr);
  byte error = wirePort.endTransmission();
  if (error != 0) {
    Serial.println("I2C transmission error: " + String(error));
    return;
  }

  byte bytesReceived = wirePort.requestFrom(slvAddr, len);
  if (bytesReceived != len) {
    Serial.println("I2C read error: expected " + String(len) + " bytes, received " + String(bytesReceived));
    return;
  }

  for (byte i = 0; i < len && wirePort.available(); i++) {
    readBuf[i] = wirePort.read();
  }
}



/**
 * @brief Measures the DUT output voltage at zero load and maximum load
 *
 * @param port        indicates which port to test, 1 = upper, 2 = lower
 * @param testCurrent current in A to pull from the DUT
 * @param Vmin        Minimum voltage under load to pass
 * @param Vmax        Maximum voltage to pass 
 *
 * The function measures the output voltage of the DUT to the specified port at zero load
 * then ramps the load current to the specified level and measures the output voltage again. 
 * Returns 0 if the voltage stays within the specified range, 2 if it does not. Returns 1 if
 * a fault with the load bank is detected
 * 
 * @return 0 = test pass, 1 = load fault, 2 = test fail.  
 */
int measureDUT(int port, float testCurrent, float Vmin, float Vmax){

  byte currentPort = (port == 1) ? CN1_CURRENT
                    :(port == 2) ? CN2_CURRENT
                    :0;
  byte voltagePort = (port == 1) ? CN1_VOLTAGE
                    :(port == 2) ? CN2_VOLTAGE
                    :0;
  byte loadDis     = (port == 1) ? LOAD1_DISABLE
                    :(port == 2) ? LOAD2_DISABLE
                    :0;
  String portName  = (port == 1) ? "upper"
                    :(port == 2) ? "lower"
                    :" ";

  Serial.println("Testing " + portName + " port at " + String(testCurrent) + "A, " + String(Vmin, 1) + "-" + String(Vmax, 1) + "V");

  delay(100);

  float voltage = measureVoltage(voltagePort);
  float current = measureCurrent(currentPort);
  Serial.println("Leakage zero point = " + String(current));

  /*if(abs(current) > LOAD_LEAKAGE_LIMIT){
    Serial.print("Load " + String(port) + " calibration problem or leaking current while disabled. Measured " + String(current) + "A");
    return 1;
  }*/
  if(voltage > Vmax || voltage < Vmin){
    Serial.print(portName + " port zero load output voltage out of range. Expected " +  String(Vmin, 1) + "-" + String(Vmax, 1) + "V, measured " + String(voltage) + "V");
    return 2;
  }

  digitalWrite(loadDis, LOW);
  loadPWM(port, testCurrent);
  voltage = measureVoltage(voltagePort);
  current = measureCurrent(currentPort);
  digitalWrite(loadDis, HIGH);

  if(loadFailed == true){
    loadFailed = false;
    loadPWM(port, 0);
    return 1;
  }
  loadPWM(port, 0); 

  if(current < 0.9 * testCurrent){
    Serial.print(portName + " port max current too low. Expected " + String(testCurrent) + "A, measured " + String(current) + "A");
    return 2;
  }
  if(voltage > Vmax || voltage < Vmin){
    Serial.print(portName + " port max load output voltage out of range. Expected " +  String(Vmin, 1) + "-" + String(Vmax, 1) + "V, measured " + String(voltage) + "V");
    return 2;
  }
  return 0;
}



/**
 * @brief Retrieves the Power Data Objects (PDOs) from the PD chip on the specified port.
 *
 * @param portNumber  The port to query (1 for Wire, 2 for Wire1). Any other value returns all zeroes
 *
 * The function sends an I2C read command to the PD chip to fetch 12 bytes of source capabilities.
 * These bytes are grouped into 6 PDOs (2 bytes each), which are parsed and stored in a static array.
 * Each PDO is printed to the Serial monitor in hexadecimal format.
 *
 * @return Pointer to a static array of 6 integers representing the retrieved PDOs.
 *         If an invalid port is specified, the array will contain all zeros. 
 */
int* getPDOs(int portNumber) {
  static int PDOs[6] = {0x0000,0x0000,0x0000,0x0000,0x0000,0x0000};
  Serial.println("Get PD Source Power Capabilities:");

  if (portNumber == 1) {
    i2c_read(Wire, PD_CHIP_ADDRESS, 0x20, 12, readBuf);
  }
  else if (portNumber == 2) {
    i2c_read(Wire1, PD_CHIP_ADDRESS, 0x20, 12, readBuf);
  }
  else {
    Serial.println("Invalid i2c parameters");
    return PDOs;
  }

  Serial.println("Detected PDOs:");
  for (int i = 0; i < 12; i += 2) {
    int pdoIndex = i / 2;
    PDOs[pdoIndex] = (readBuf[i+1] << 8) | readBuf[i];
    Serial.println("PDO " + String(pdoIndex) + ": " + String(PDOs[pdoIndex], HEX));
  }
  return PDOs;
}

/**
 * @brief Compares expected PDOs from configuration against detected PDOs for a given port.
 *
 * @param port           Port number (1 or 2). If greater than 1, offset is applied to config lookup.
 * @param configsIndex   Index into the PDOsConfigs array to select the expected configuration.
 * @param detectedPDOs   Pointer to an array containing the PDOs detected from the device.
 *
 * The function checks whether each expected PDO (from PDOsConfigs) is present in the detectedPDOs array.
 * A match is considered valid if the expected PDO is found or if the expected value is zero (treated as a wildcard).
 * It prints the result of each comparison to the Serial monitor and returns true only if all expected PDOs match.
 *
 * @return true if all expected PDOs are found in the detected list; false otherwise.
 */
bool checkPDOsMatch(int port, int configsIndex, int *detectedPDOs) {

    // Check each expected PDO against the detected list
    for (int i = 0; i < MAX_PDO_ENTRIES; i++) {
        int arrayEntry = (port > 1) ? i+MAX_PDO_ENTRIES : i;
        int expectedPDO = PDOsConfigs[configsIndex][arrayEntry];
        bool found = false;

        // Search for a match in detectedPDOs
        for (int j = 0; j < MAX_PDO_ENTRIES; j++) {
            if (detectedPDOs[j] == expectedPDO || expectedPDO == 0) {
                found = true;
                break;
            }
        }
        Serial.print("Expected PDO " + String(i) + ": " + String(expectedPDO, HEX) + " " + (found ? (expectedPDO ? " Pass\n" : "Skip\n") : " Fail\n"));

        if (!found) {
            return false;
        }
    }
    return true;
}



/**
 * @brief Measures voltage from the specified port using analog input and calibration data.
 *
 * @param pin  Pin ID to read from. If the supplied pin is not on the following 
 *             list it will return zero:
 *                                      CN1_VOLTAGE
 *                                      CN2_VOLTAGE
 *                                      VINF_MEASURE
 *                                      _10V_MEASURE
 * 
 * The function reads the voltage on the given analog pin, then converts the raw ADC reading
 * to Volts by multiplying by the voltage divider ratio and the stored calibration factor
 * 
 * @return The measured current in volts as a float. Returns 0 if the port number is invalid.
 */ 
float measureVoltage(int pin){
  analogRead(pin); //Discard first reading, stale value
  float voltage = ((pin == CN1_VOLTAGE)  ? float(analogRead(CN1_VOLTAGE))  * VOUT_MEASURE_DIVIDER 
                  :(pin == CN2_VOLTAGE)  ? float(analogRead(CN2_VOLTAGE))  * VOUT_MEASURE_DIVIDER
                  :(pin == VINF_MEASURE) ? float(analogRead(VINF_MEASURE)) * VINF_MEASURE_DIVIDER
                  :(pin == _10V_MEASURE) ? float(analogRead(_10V_MEASURE)) * _10V_MEASURE_DIVIDER
                  :0)
                  * Calibrate.ADCCalFactor;
  return voltage;
}

/**
 * @brief Measures current from the specified port using analog input and calibration data.
 *
 * @param port  Port number to read from:
 *              - 1: Reads from CN1_CURRENT using load1Cal calibration
 *              - 2: Reads from CN2_CURRENT using load2Cal calibration
 *              - Any other value returns 0
 *
 * @return The measured current in amperes as a float. Returns 0 if the port number is invalid.
 */ 
float measureCurrent(int port){
  analogRead(port); //Discard first reading, stale value
  if (Calibrate.load1Cal.gain == 0 || Calibrate.load2Cal.gain == 0) return NAN;
  float current = ((port == CN1_CURRENT) ? float((analogRead(CN1_CURRENT)) - Calibrate.load1Cal.offset) / Calibrate.load1Cal.gain
                  :(port == CN2_CURRENT) ? float((analogRead(CN2_CURRENT)) - Calibrate.load2Cal.offset) / Calibrate.load2Cal.gain
                  :0);
  return current;
}



/**
 * @brief Initialise PWM and pin routing for both load banks.
 *
 * Configures the MCU peripherals and pin multiplexing for the two
 * differential PWM channels used by the load banks (channels 2 and 3).
 * Sets the PWM clock, period (resolution) and enables the channels.
 */
void loadInit(){             
  // PWM Set-up on pins PC7 and PA20 (Arduino Pins 39(PWMH2) and 43(PWML2)): see Datasheet chap. 38.5.1 page 973
  // PWM Set-up on pins PC9 and PC8 (Arduino Pins 41(PWMH3) and 40(PWML3))
  PMC->PMC_PCER1 |= PMC_PCER1_PID36;  // PWM power ON (Enable peripheral clock) only needed once for PWM system

  PWM->PWM_DIS = PWM_DIS_CHID3 + PWM_DIS_CHID2;  // Disable PWM channel 2 and 3

  // Select Instance=PWM; Signal=PWMH2 (channel 2); I/O Line=PC7 (P7, Arduino pin 39, see pinout diagram) ; Peripheral type =B
  PIOC->PIO_PDR |= PIO_PDR_P7;  // Set the pin to the peripheral PWM, not the GPIO
  PIOC->PIO_ABSR |= PIO_PC7B_PWMH2;  // Set PWM pin perhipheral type B
  // Select Instance=PWM; Signal=PWML2 (channel 2); I/O Line=PA20 (P20, Arduino pin 43, see pinout diagram) ; Peripheral=B
  PIOA->PIO_PDR |= PIO_PDR_P20;  // Set the pin to the peripheral PWM, not the GPIO
  PIOA->PIO_ABSR |= PIO_PA20B_PWML2;  // Set PWM pin perhipheral type B

    // Select Instance=PWM; Signal=PWMH3 (channel 3); I/O Line=PC9 (P9, Arduino pin 41, see pinout diagram) ; Peripheral type =B
  PIOC->PIO_PDR |= PIO_PDR_P9;  // Set the pin to the peripheral PWM, not the GPIO
  PIOC->PIO_ABSR |= PIO_PC9B_PWMH3;  // Set PWM pin perhipheral type B
  // Select Instance=PWM; Signal=PWML3 (channel 3); I/O Line=PC8 (P8, Arduino pin 40, see pinout diagram) ; Peripheral=B
  PIOC->PIO_PDR |= PIO_PDR_P8;  // Set the pin to the peripheral PWM, not the GPIO
  PIOC->PIO_ABSR |= PIO_PC8B_PWML3;  // Set PWM pin perhipheral type B

  // Enable the PWM channel 2 and 3 (see datasheet page 973)

  PWM->PWM_CLK = PWM_CLK_PREA(0) | PWM_CLK_DIVA(2);  // Set the PWM clock rate to 42MHz (84MHz/2). Adjust DIVA for the resolution you are looking for
  
  PWM->PWM_CH_NUM[2].PWM_CMR = PWM_CMR_CPRE_CLKA;  // The period is left aligned, clock source as CLKA on channel 2
  PWM->PWM_CH_NUM[2].PWM_CPRD = 1000;  // Channel 2 : Set the PWM frequency 42MHz/(2 * CPRD) = F ;
  PWM->PWM_CH_NUM[2].PWM_CDTY = 0;  // Channel 2: Set the PWM duty cycle to x%= (CDTY/ CPRD)  * 100 % ;

  PWM->PWM_CH_NUM[3].PWM_CMR = PWM_CMR_CPRE_CLKA;  // The period is left aligned, clock source as CLKA on channel 2
  PWM->PWM_CH_NUM[3].PWM_CPRD = 1000;  // Channel 2 : Set the PWM frequency 42MHz/(2 * CPRD) = F ;
  PWM->PWM_CH_NUM[3].PWM_CDTY = 0;  // Channel 2: Set the PWM duty cycle to x%= (CDTY/ CPRD)  * 100 % ;

  PWM->PWM_ENA = PWM_ENA_CHID3 + PWM_ENA_CHID2;

}

/**
 * @brief Ramp load to currentSetting amps, reset to zero if currentSetting can't be reached.
 *
* @param port             Port number to read from:
*                         - 1: Uses PWM channel 2, monitors CN1_CURRENT and CN1_VOLTAGE
*                         - 2: Uses PWM channel 3, monitors CN2_CURRENT and CN2_VOLTAGE
*                         - Any other value returns false
 * @param currentsetting  Current in A to ramp the load to
 *
 * @return The measured current in amperes as a float. Returns 0 if the port number is invalid.
 */
bool loadPWM(int port, float currentSetting){    

  if (port != 1 && port != 2) {
    Serial.println("Invalid port");
    return false;
  }                      

  //Serial.print("Load #" + String(port));
  int PWMchannel = port + 1;
  byte currentPort = (port == 1) ? CN1_CURRENT
                    :(port == 2) ? CN2_CURRENT
                    :0;
  byte voltagePort = (port == 1) ? CN1_VOLTAGE
                    :(port == 2) ? CN2_VOLTAGE
                    :0;
                    

  //PWM duty cycle, parts per thousand
  int loadDuty = 0;
  if(currentSetting == 0){                                                //If target current is zero turn off PWM and exit regardless of cal values
    PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = loadDuty;
    Serial.println("Load #" + String(port) + " reset");
    return true;
  }

  //Serial.println(" setting to " + String(currentSetting, 2) + "A");
  float voltage = measureVoltage(voltagePort);
  float current = measureCurrent(currentPort);
  Serial.println("Load " + String(port) + " Voltage: " + String(voltage, 2) + "V, Current: " + String(current, 2));
  printToLCD("Port " + String(port) + " load test\nVoltage: " + String(voltage, 2) + "V\nCurrent: " + String(current, 2) + "A ");

  if(isnan(current) || current > LOAD_CURRENT_LIMIT){     //Sanity check the current readings
    loadDuty = 0;
    loadFailed = true;
    Serial.println("Failed - load appears to be pulling " + String(current, 2) + " Amps");
    return false;
  }

  while(current < currentSetting){                                  //Progressively ramp up load current until it exceeds the target setting
    if(loadDuty == 1000){                                                //If the load reaches 100% and hasn't risen to the target current, fail the test and exit
      //loadDuty = 0;
      Serial.println("load maxed");
      return false;
    }

    loadDuty += 1;
    PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = loadDuty;
    delay(1);

    voltage = measureVoltage(voltagePort);
    current = measureCurrent(currentPort);
    if(loadDuty % 50 == 0){
      printToLCD(String(voltage, 2) + "V  ", 9, 1, false);
      printToLCD(String(current, 2) + "A  ", 9, 2, false);
      Serial.println("Load " + String(port) + " Voltage: " + String(voltage, 2) + "V, Current: " + String(current, 2));
    }
  }    

  Serial.println("Current setting: " + String(currentSetting) + "A");
  while(current > currentSetting){                                  //Back off the current setting if it overshoots the target

    if(loadDuty == 0){                                                      //If load setting reaches zero, fail the test and exit
      loadFailed = true;
      Serial.println("load zeroed, measured current remaining at zero PWM: " + String(current, 2) + "A");
      return false;
    }

    loadDuty--;
    PWM->PWM_CH_NUM[PWMchannel].PWM_CDTY = loadDuty;      
    delay(5);                          
    voltage = measureVoltage(voltagePort);
    current = measureCurrent(currentPort);

    if(loadDuty % 10 == 0){
      printToLCD(String(voltage, 2) + "V  ", 9, 1, false);
      printToLCD(String(current, 2) + "A  ", 9, 2, false);
    }
  }
  return true;
}


uint32_t failCount = 0;

 struct ErrorMessage {
  int code;
  const char* message;
};
// Error messages to display on the LCD. More can be added just by adding lines to this array
// Error codes are passed as hex integers for easy letter categories
ErrorMessage errorMessages[] = {
  {0xE1, "Calibration Needed"},
  {0xE2, "Internal fault"},
  {0xE3, "Wrong connector board"},
  {0xE4, "Load failed"},
  {0xE5, "Check power supply voltage"},
  {0xE6, "Excessive ambient light leakage at LED sensor"},
  {0xF1, "LED colour fail"},
  {0xF2, "Continuity fail"},
  {0xF3, "Inverse voltage fail"},
  {0xF4, "5V fail"},
  {0xF5, "QC fail"},
  {0xF6, "PD software fail"},
  {0xF7, "PD hardware fail"},
  {0xF8, "PD voltage fail"},
  {0xF9, "PD current fail"},
  {0xF10, "UVLO fail"}
};

/** 
 * @brief Handles LCD and serial output during system failures or error conditions.
 *
 * @note 
 * - This function resets I/O, updates status indicators, and displays error messages.
 * - It does not return; if the error code is unrecognized, it enters an infinite blinking loop.
 *
 * @param failCode  Integer error code representing the failure condition.
 * @param comment   More specific message for the serial monitor, for use by engineering and repairs
 *
 * Behavior:  
 * - Activates the FAIL LED and deactivates the PASS LED.
 * - Prints the provided comment to the serial monitor.
 * - Increments `failCount` if the error code is 0xF0 or higher, meaning product fails but not tester faults.
 * - Searches for a matching error message in the `errorMessages` array.
 *   - If found, displays the error code and message on the LCD.
 *   - If not found, displays a generic fault message and enters an infinite loop
 *     with blinking FAIL indicator to lock out the buggy software from further use
 */
void failout(int failCode, String comment) {
  resetIO();
  String failCodeStr = String(failCode, HEX);
  failCodeStr.toUpperCase();
  digitalWrite(FAIL, HIGH);
  Serial.println(comment);

  if (failCode > 0xEF) {
    failCount++;
  }
  lastActionTime = millis();
  // Look up the error message in the array
  bool found = false;
  for (uint16_t i = 0; i < sizeof(errorMessages) / sizeof(errorMessages[0]); i++) {
    if (errorMessages[i].code == failCode) {
      printToLCD("Error Code: " + failCodeStr + "\n" + errorMessages[i].message);
      found = true;
      break;
    }
  }
  if (!found) {
    printToLCD("Error Code: " + failCodeStr + " Software fault, contact engineering");
    Serial.println("Software exception:, unknown error code " + failCodeStr + " was sent. If this happened in a previously stable deployed tester this indicates a hardware fault in the Arduino or flash corruption.");
    blink();
  }
}

//Flashes the fail LED in an infinite loop - panic function to force a hard reset
void blink(){
    Serial.println("Device locked out due to fatal error, restart required");
    while (1) {
        digitalWrite(FAIL, HIGH);
        delay(500);
        digitalWrite(FAIL, LOW);
        delay(500);    
    }
}

//Set every configurable IO pin to its default idle state and shut off any PWM signals to the loads
void resetIO(){

  PWM->PWM_CH_NUM[2].PWM_CDTY = 0;
  PWM->PWM_CH_NUM[3].PWM_CDTY = 0;

  for (uint16_t i = 0; i < sizeof(buttonPins)/sizeof(buttonPins[0]); i++) {
    pinMode(buttonPins[i], INPUT_PULLUP);
  }
  for (uint16_t i = 0; i < sizeof(inputPins)/sizeof(inputPins[0]); i++) {
    pinMode(inputPins[i], INPUT);
  }
  for (uint16_t i = 0; i < sizeof(defaultHighPins)/sizeof(defaultHighPins[0]); i++) {
    pinMode(defaultHighPins[i], OUTPUT);
    digitalWrite(defaultHighPins[i], HIGH);
  }
  for (uint16_t i = 0; i < sizeof(defaultLowPins)/sizeof(defaultLowPins[0]); i++) {
    pinMode(defaultLowPins[i], OUTPUT);
    digitalWrite(defaultLowPins[i], LOW);
  }
}


/** 
 * @brief Blocks further testing until the DUT is removed from the tester.
 * @param productLEDColour  The just-confirmed LED colour of the product that just passed.  
 * 
 * The function monitors the voltage on both ports and the LED colour using the AS7341 sensor.
 * For products with "Error" or "White" LED it skips the LED check and only waits for voltage to drop.
 * Once both voltage and LED presence are no longer detected, it resets the I/O and returns control.
 */ 
void detectRemoval(String productLEDColour){
    unsigned long passTime = millis();
    Serial.println("Waiting for product removal");
    delay(1000);  //Minimum 1 second delay before the PASS indicators can be cleared to ensure they arent accidentally skipped or missed

    bool voltagePresent = true;
    bool LEDPresent = true;

    while(voltagePresent || LEDPresent){

    voltagePresent = (measureVoltage(CN1_VOLTAGE) < 2.0 && measureVoltage(CN2_VOLTAGE) < 2.0) ? false : true;

    //If the sensor is lit and colour doesn't match the test it just passed, product has been removed
    String currentColour = getLEDColour(false);                       
    LEDPresent = (currentColour != productLEDColour && currentColour != "Dark") ? false : true;          

                  

    //After 5 seconds cut power on voltage drop detect, prevents shorts on the power pins, delay in case of power glitches
    if(passTime + 5000 < millis() && voltagePresent == false){       

    //LED is now off, sensor needs to see any light to indicate removal
      digitalWrite(HV_ENABLE, LOW);
      LEDPresent = (currentColour != "Dark") ? false : true;   

      if(digitalRead(OK) == LOW){
          LEDPresent = false; //Failsafe escape from the lockout if the sensor is stuck on for any reason
          Serial.println("WARNING: OK button pressed, removal detect bypassed");
          //Validate the LED sensor is working correctly after bypass
          if(!validateLEDSensor()){
            //+++++++++++++Add the maintenance flag
            failout(0xE1, "LED sensor validation failed after post-test device removal check bypass");  
          }          
        }
      }

    if(passTime + 30000 < millis()){  //After 30 seconds display instructions on display
      printToLCD("Remove product or press OK to continue", 0,2,false);
    }
  }
  printToLCD("Ready ",7,1,false);
  Serial.println("Product removed");
  resetIO();
}




bool validateLEDSensor(){
  Serial.println("Validating LED sensor");

  if (!as7341.readAllChannels()){
    Serial.println("Light sensor fault detected, tester locked out.\nUnable to read AS7341 sensor");
    return false;
  }

  String currentColour = getLEDColour(true);
  while(measureVoltage(CN1_VOLTAGE) > 2.0 || measureVoltage(CN2_VOLTAGE) > 2.0 || currentColour == "Dark" || currentColour =="Error"){
    printToLCD("Clear socket to validate light sensor");
    delay(200);
  }

  uint16_t ch[8] = {0};
  uint16_t changes = 0;
  uint16_t freezes = 0;
  uint16_t loops = 0;
  uint16_t lastchange = 0;

  while(changes < 20){
    for (int i = 0; i < 8; i++) { 
      uint16_t v = as7341.getChannel(VisChannels[i]);

    if(v != ch[i]){                    //Channel value has changed, real data always has noise so identical values mean no real data
        lastchange = freezes; //Freeze count since last good reading
        changes++;
      }
      else if(v != 65535 && v > 10) freezes++; //Saturated channels are not frozen, close to zero readings arent noisy enough to discount
      ch[i] = v;
    }
    loops++;
    if((loops > 4 && changes < 4 * loops) || freezes > 50 || freezes - lastchange > 10){
      Serial.println("Light sensor fault detected, tester locked out.\nOut of " + String(loops * 8) + " test readings " + String(changes) + " were valid data");   
      return false;
    }
  }

  return true;
}