/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : functions.h
 * Description  : Product test functions and associated helpers
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H



#include <wire.h>
#include <stdint.h>
#include <Arduino.h>
#include <chip.h>
#include "globaldefines.h"
#include "ui.h"
#include "calibrate.h"



extern calibrate Calibrate;

float measureVoltage(int port);

float measureCurrent(int port);

int* getPDOs(int portNumber);

bool inversePolarity(int waitTime);

bool checkPDOsMatch(int port, int configsIndex, int *detectedPDOs);

void i2c_write(TwoWire &twowire, byte slvAddr, byte cmdAddr, byte writeBuf[], byte len);

void i2c_read(TwoWire &wirePort, byte slvAddr, byte cmdAddr, byte len, byte *readBuf);

void loadInit();

bool loadPWM(int, float);

String getLEDColour(bool verbose = true);

void resetIO();

void blink();

void failout(int failCode, String comment);

float multiSampleRead(byte pin);

void colourInit();

void setQC(int port, int voltage);

int measureDUT(int port, float testCurrent, float Vmin, float Vmax);

void resetArduino();

void detectRemoval(String productLEDColour);

bool validateLEDSensor();

#endif