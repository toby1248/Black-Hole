import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from tkinter.scrolledtext import ScrolledText
import serial
import serial.tools.list_ports
import threading
import queue
import time
import datetime
import csv
import io

# --- Configuration ---
WINDOW_WIDTH = 1024
WINDOW_HEIGHT = 800
CLI_HEIGHT = 200
RIGHT_PANEL_WIDTH = 100
BAUD_RATE = 115200
CONNECTION_TIMEOUT = 2  # Seconds
SERIAL_HANDSHAKE = "£££"
COMMANDS = ["GETLOG", "ERASELOG", "GETCOUNTERS", "SAVECTR", "PRODUCTDATA"]

# Define product data structure based on productdata.cpp
# This will be used for the Product Data tab table headers
PRODUCT_DATA_HEADERS = [
    "partNumber", "hasPD", "hasQC", "Is24VoltOnly",
    "VOutMaxLower", "VOutMinLower", "IOutMaxLower", "connectorLower", "PDQCVMaxLower", "PDQCIMaxLower",
    "VOutMaxUpper", "VOutMinUpper", "IOutMaxUpper", "connectorUpper", "PDQCVMaxUpper", "PDQCIMaxUpper",
    "LEDColour", "PDOsIndex", "DeratePDOsIndex", "connectorID", "extraCapacitance"
]

class ArduinoGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Arduino Due Control Interface")
        self.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

        self.serial_port = None
        self.serial_thread = None
        self.serial_queue = queue.Queue()
        self.stop_thread = False
        self.app_state = "IDLE"  # To track what data we are expecting
        self.counter_data_buffer = [] # For SAVECTR

        self.create_widgets()
        self.find_and_connect_arduino()

        # Start the queue polling
        self.after(100, self.process_serial_queue)

    def create_widgets(self):
        # --- Main Container ---
        self.main_frame = ttk.Frame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # --- Product Data Container (initially hidden) ---
        self.product_data_frame = ttk.Frame(self)
        # self.product_data_frame.pack(fill=tk.BOTH, expand=True) # Will be packed when shown

        # --- 1. Top Options Bar (in main_frame) ---
        top_bar = ttk.Frame(self.main_frame, height=50)
        top_bar.pack(fill=tk.X, side=tk.TOP, padx=5, pady=5)

        self.product_data_btn = ttk.Button(top_bar, text="Product Data Tab", command=self.show_product_data_tab)
        self.product_data_btn.pack(side=tk.LEFT, padx=5)
        
        self.main_tab_btn = ttk.Button(top_bar, text="Main Tab", command=self.show_main_tab)
        # self.main_tab_btn.pack(side=tk.LEFT, padx=5) # Only pack this in the product tab

        # Logging type buttons (placeholder)
        for i in range(5):
            btn = ttk.Button(top_bar, text=f"Log Type {i+1}")
            btn.pack(side=tk.LEFT, padx=2)

        # --- 4. Bottom CLI Area (in main_frame) ---
        cli_frame = ttk.Frame(self.main_frame, height=CLI_HEIGHT)
        cli_frame.pack(fill=tk.X, side=tk.BOTTOM, padx=5, pady=5)
        cli_frame.pack_propagate(False) # Prevent resizing

        # --- 5. Command Buttons (at the very bottom) ---
        command_bar = ttk.Frame(cli_frame)
        command_bar.pack(fill=tk.X, side=tk.BOTTOM, pady=(5, 0))
        
        for cmd in COMMANDS:
            if cmd != "PRODUCTDATA": # PRODUCTDATA is on its own tab
                btn = ttk.Button(command_bar, text=cmd, command=lambda c=cmd: self.on_command_button_click(c))
                btn.pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        # CLI Output
        self.cli_output = ScrolledText(cli_frame, height=10, state=tk.DISABLED, bg="#f0f0f0", fg="black")
        self.cli_output.pack(fill=tk.BOTH, expand=True, side=tk.TOP)

        # CLI Input
        self.cli_input_var = tk.StringVar()
        cli_input_entry = ttk.Entry(cli_frame, textvariable=self.cli_input_var)
        cli_input_entry.pack(fill=tk.X, side=tk.BOTTOM, pady=(5, 0))
        cli_input_entry.bind("<Return>", self.on_cli_input)
        
        # --- 2. Middle Main Area (in main_frame) ---
        middle_area = ttk.Frame(self.main_frame)
        middle_area.pack(fill=tk.BOTH, expand=True, side=tk.TOP)

        # --- 3. Right Panel (in middle_area) ---
        right_panel = ttk.Frame(middle_area, width=RIGHT_PANEL_WIDTH)
        right_panel.pack(fill=tk.Y, side=tk.RIGHT, padx=5, pady=5)
        right_panel.pack_propagate(False)

        self.data_boxes = {}
        for i in range(10):
            lbl = ttk.Label(right_panel, text=f"C{i}:")
            lbl.pack(anchor="w", pady=(10, 0))
            var = tk.StringVar(value="---")
            entry = ttk.Entry(right_panel, textvariable=var, state="readonly", justify="center")
            entry.pack(fill=tk.X)
            self.data_boxes[f"C{i}"] = var

        # --- 6. Data Display Area (Left of Right Panel) ---
        data_area = ttk.Frame(middle_area)
        data_area.pack(fill=tk.BOTH, expand=True, side=tk.LEFT, padx=5, pady=5)
        
        # Buttons above the table (placeholder)
        data_area_top_bar = ttk.Frame(data_area)
        data_area_top_bar.pack(fill=tk.X, side=tk.TOP, pady=(0, 5))
        for i in range(5):
            btn = ttk.Button(data_area_top_bar, text=f"Data View {i+1}")
            btn.pack(side=tk.LEFT, padx=2)

        # Scrollable Table
        table_cols = ("Timestamp", "Level", "Message")
        self.data_table = ttk.Treeview(data_area, columns=table_cols, show="headings")
        for col in table_cols:
            self.data_table.heading(col, text=col)
            self.data_table.column(col, width=150)
        self.data_table.column("Message", width=400)
        
        # Add Scrollbars
        v_scroll = ttk.Scrollbar(data_area, orient="vertical", command=self.data_table.yview)
        h_scroll = ttk.Scrollbar(data_area, orient="horizontal", command=self.data_table.xview)
        self.data_table.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)

        v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.data_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # --- 7. Create Product Data Tab Widgets ---
        self.create_product_data_widgets()


    def create_product_data_widgets(self):
        # Top bar
        top_bar = ttk.Frame(self.product_data_frame)
        top_bar.pack(fill=tk.X, side=tk.TOP, padx=5, pady=5)
        
        self.main_tab_btn_prod = ttk.Button(top_bar, text="Main Tab", command=self.show_main_tab)
        self.main_tab_btn_prod.pack(side=tk.LEFT, padx=5)

        btn_refresh = ttk.Button(top_bar, text="Refresh Data (from Arduino)", command=self.refresh_product_data)
        btn_refresh.pack(side=tk.LEFT, padx=5)
        
        btn_update = ttk.Button(top_bar, text="Send Update to Arduino", command=self.send_product_data_update)
        btn_update.pack(side=tk.LEFT, padx=5)

        # Table
        self.product_table = ttk.Treeview(self.product_data_frame, columns=PRODUCT_DATA_HEADERS, show="headings")
        
        for col in PRODUCT_DATA_HEADERS:
            self.product_table.heading(col, text=col)
            self.product_table.column(col, width=100, anchor="w")
        
        # Add Scrollbars
        v_scroll = ttk.Scrollbar(self.product_data_frame, orient="vertical", command=self.product_table.yview)
        h_scroll = ttk.Scrollbar(self.product_data_frame, orient="horizontal", command=self.product_table.xview)
        self.product_table.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)

        v_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        h_scroll.pack(side=tk.BOTTOM, fill=tk.X)
        self.product_table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Bind double-click to edit
        self.product_table.bind("<Double-1>", self.on_product_table_edit)
        
    def show_main_tab(self):
        self.product_data_frame.pack_forget()
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
    def show_product_data_tab(self):
        self.main_frame.pack_forget()
        self.product_data_frame.pack(fill=tk.BOTH, expand=True)
        self.refresh_product_data() # Automatically request data

    def refresh_product_data(self):
        # Clear existing table data
        for item in self.product_table.get_children():
            self.product_table.delete(item)
            
        self.send_serial_command("PRODUCTDATA")
        self.app_state = "WAITING_FOR_PRODUCTDATA"
        self.log_to_cli("Requesting product data...\n")

    def on_product_table_edit(self, event):
        """ Handle double-click to edit a cell """
        region = self.product_table.identify_region(event.x, event.y)
        if region != "cell":
            return

        item = self.product_table.identify_row(event.y)
        column_id = self.product_table.identify_column(event.x)
        column_index = int(column_id.replace('#', '')) - 1
        
        if not item or column_index < 0:
            return

        # Get current value
        current_values = self.product_table.item(item, 'values')
        current_value = current_values[column_index]
        
        # Ask user for new value
        new_value = simpledialog.askstring("Edit Cell", f"Enter new value for {PRODUCT_DATA_HEADERS[column_index]}:",
                                           initialvalue=current_value, parent=self)

        if new_value is not None:
            new_values = list(current_values)
            new_values[column_index] = new_value
            self.product_table.item(item, values=tuple(new_values))

    def send_product_data_update(self):
        """ Send all data in the product table back to the Arduino """
        if not self.serial_port or not self.serial_port.is_open:
            self.log_to_cli("Error: Serial port not connected.\n", "error")
            return
            
        self.log_to_cli("Sending product data updates to Arduino...\n")
        # We need a command to tell the Arduino to *receive* data
        # Assuming a command like £UPDATEPRODUCTDATA
        self.send_to_serial("£UPDATEPRODUCTDATA\n")
        
        time.sleep(0.1) # Give Arduino time to prepare
        
        for item in self.product_table.get_children():
            values = self.product_table.item(item, 'values')
            csv_line = ",".join(map(str, values)) + "\n"
            self.send_to_serial(csv_line)
            time.sleep(0.01) # Small delay between lines
            
        self.log_to_cli("Product data update sent.\n")


    def find_and_connect_arduino(self):
        self.log_to_cli("Scanning for Arduino Due...\n")
        ports = serial.tools.list_ports.comports()
        arduino_ports = [p for p in ports if "Arduino Due" in p.description or "USB Serial" in p.description]

        if not arduino_ports:
            self.log_to_cli("No potential Arduino ports found. Please connect the device.\n", "error")
            return

        for port in arduino_ports:
            self.log_to_cli(f"Attempting to connect to {port.device}...\n")
            try:
                self.serial_port = serial.Serial(port.device, BAUD_RATE, timeout=CONNECTION_TIMEOUT)
                
                # Send handshake
                self.serial_port.write(SERIAL_HANDSHAKE.encode('utf-8'))
                
                # Give it a moment to respond
                time.sleep(0.5)
                
                # Check if Arduino is in listen mode (this is an assumption)
                # A better way would be to wait for a specific response, but
                # for now, we'll assume connection is good.
                
                self.log_to_cli(f"Successfully connected to {port.device}!\n", "success")
                
                # Start the serial reader thread
                self.stop_thread = False
                self.serial_thread = threading.Thread(target=self.read_serial_data)
                self.serial_thread.daemon = True
                self.serial_thread.start()
                return  # Stop searching once connected

            except serial.SerialException as e:
                self.log_to_cli(f"Failed to connect to {port.device}: {e}\n", "error")
                if self.serial_port:
                    self.serial_port.close()
                self.serial_port = None

        self.log_to_cli("Could not connect to any Arduino port.\n", "error")

    def read_serial_data(self):
        """ Runs in a separate thread to read from serial port """
        while not self.stop_thread:
            if self.serial_port and self.serial_port.is_open:
                try:
                    line = self.serial_port.readline().decode('utf-8').strip()
                    if line:
                        self.serial_queue.put(line)
                except serial.SerialException as e:
                    self.serial_queue.put(f"SERIAL_ERROR: {e}")
                    self.stop_thread = True # Stop thread on error
                except UnicodeDecodeError:
                    pass # Ignore bytes that can't be decoded
            else:
                time.sleep(0.1) # Wait if port is closed
        
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()

    def process_serial_queue(self):
        """ Process items from the serial queue in the main GUI thread """
        try:
            while not self.serial_queue.empty():
                line = self.serial_queue.get_nowait()
                
                if line.startswith("SERIAL_ERROR:"):
                    self.log_to_cli(f"Serial port disconnected: {line}\n", "error")
                    self.serial_port = None
                    return # Stop processing
                
                # Log *all* serial data to the CLI
                self.log_to_cli(line + "\n")
                
                # --- State-based Parsing ---
                
                if self.app_state == "WAITING_FOR_ERASE_ACK":
                    if line.strip() == "Logs erased":
                        messagebox.showinfo("Success", "Logs successfully erased.")
                        self.app_state = "IDLE"
                        self.clear_data_readouts()
                    # Implement a timeout logic if needed
                    
                elif self.app_state == "WAITING_FOR_LOG_START":
                    if line.strip() == "=== LOG DUMP START ===":
                        self.app_state = "LOGGING"
                
                elif self.app_state == "LOGGING":
                    if line.strip() == "=== LOG DUMP END ===":
                        self.app_state = "IDLE"
                    else:
                        self.parse_and_add_log_entry(line)

                elif self.app_state == "WAITING_FOR_COUNTERS" or self.app_state == "SAVING_COUNTERS":
                    self.parse_counter_data(line)

                elif self.app_state == "WAITING_FOR_PRODUCTDATA":
                    self.parse_product_data(line)

        finally:
            self.after(100, self.process_serial_queue)

    def parse_and_add_log_entry(self, line):
        """ Parse a log line and add it to the main data table """
        # Assuming format like: [TYPE TTTTS] Message
        try:
            parts = line.split(']', 1)
            if len(parts) == 2:
                header = parts[0].strip('[ ')
                message = parts[1].strip()
                
                header_parts = header.split()
                if len(header_parts) == 2:
                    log_type = header_parts[0]
                    timestamp = header_parts[1]
                    self.data_table.insert("", tk.END, values=(timestamp, log_type, message))
                    self.data_table.yview_moveto(1.0) # Auto-scroll
        except Exception:
            # Fallback: just dump the raw line
            self.data_table.insert("", tk.END, values=("N/A", "RAW", line))
            self.data_table.yview_moveto(1.0)
            
    def parse_counter_data(self, line):
        """ Parse a counter line (e.g., "C0: 123") and update GUI """
        try:
            if ':' in line:
                parts = line.split(':')
                key = parts[0].strip()
                value = parts[1].strip()
                
                if key in self.data_boxes:
                    self.data_boxes[key].set(value)
                    
                if self.app_state == "SAVING_COUNTERS":
                    self.counter_data_buffer.append(f"{key}: {value}")
                    
        except Exception as e:
            self.log_to_cli(f"Error parsing counter data: {e}\n", "error")

    def parse_product_data(self, line):
        """ Parse a CSV line and add it to the product data table """
        try:
            # Assume end of data is marked by a blank line or specific token
            if line.strip() == "":
                self.app_state = "IDLE"
                self.log_to_cli("Product data loaded.\n", "success")
                return

            # Use csv reader for a single line
            reader = csv.reader(io.StringIO(line))
            for row in reader:
                if len(row) == len(PRODUCT_DATA_HEADERS):
                    self.product_table.insert("", tk.END, values=tuple(row))
                else:
                    self.log_to_cli(f"Skipping malformed CSV line: {line}\n", "error")
        except Exception as e:
            self.log_to_cli(f"Error parsing product data: {e}\n", "error")


    def on_command_button_click(self, command):
        if command == "ERASELOG":
            if messagebox.askyesno("Confirm Erase", "Are you sure you want to erase all logs on the device?"):
                self.send_serial_command(command)
                self.app_state = "WAITING_FOR_ERASE_ACK"
                # Start a timer to show "Fail" if no ack is received
                self.after(5000, self.check_erase_ack_timeout)
        elif command == "GETLOG":
            self.app_state = "WAITING_FOR_LOG_START"
            self.send_serial_command(command)
        elif command == "GETCOUNTERS":
            self.app_state = "WAITING_FOR_COUNTERS"
            self.send_serial_command(command)
        elif command == "SAVECTR":
            self.app_state = "SAVING_COUNTERS"
            self.counter_data_buffer = [f"Data saved: {datetime.datetime.now().isoformat()}\n"]
            self.send_serial_command("GETCOUNTERS") # Request data to save
            # We need a way to know when counters are done.
            # For now, we'll assume they come in fast and we'll save after a delay.
            self.after(2000, self.save_counter_data_to_file)
        else:
            self.send_serial_command(command)
            
    def save_counter_data_to_file(self):
        if self.app_state != "SAVING_COUNTERS":
            return
            
        self.app_state = "IDLE"
        if not self.counter_data_buffer:
            self.log_to_cli("No counter data received to save.\n", "error")
            return
            
        filename = f"counts_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        try:
            with open(filename, 'w') as f:
                f.write("\n".join(self.counter_data_buffer))
            self.log_to_cli(f"Counter data saved to {filename}\n", "success")
        except Exception as e:
            self.log_to_cli(f"Failed to save counter data: {e}\n", "error")
        
        self.counter_data_buffer = []

    def check_erase_ack_timeout(self):
        if self.app_state == "WAITING_FOR_ERASE_ACK":
            self.app_state = "IDLE"
            messagebox.showerror("Timeout", "Failed to erase logs. No acknowledgment received.")

    def on_cli_input(self, event):
        command = self.cli_input_var.get().strip()
        if not command:
            return
        
        self.cli_input_var.set("") # Clear input
        self.send_serial_command(command)
        
        # Handle state changes for CLI commands too
        if command.upper() == "GETLOG" or command.upper() == "£GETLOG":
            self.app_state = "WAITING_FOR_LOG_START"
        elif command.upper() == "ERASELOG" or command.upper() == "£ERASELOG":
            self.app_state = "WAITING_FOR_ERASE_ACK" # No popup for CLI
            self.after(5000, self.check_erase_ack_timeout)
        elif command.upper() == "GETCOUNTERS" or command.upper() == "£GETCOUNTERS":
            self.app_state = "WAITING_FOR_COUNTERS"
        elif command.upper() == "SAVECTR" or command.upper() == "£SAVECTR":
            self.app_state = "SAVING_COUNTERS"
            self.counter_data_buffer = [f"Data saved: {datetime.datetime.now().isoformat()}\n"]
            self.after(2000, self.save_counter_data_to_file)

    def send_serial_command(self, command):
        """ Prepares and sends a command string to the serial port. """
        cmd_upper = command.upper()
        
        # Add '£' prefix if it's a known command without it
        if cmd_upper in COMMANDS and not command.startswith('£'):
            command = f"£{command}"
            
        # Add newline terminator
        if not command.endswith('\n'):
            command += '\n'
            
        self.send_to_serial(command)

    def send_to_serial(self, data):
        """ Low-level send to serial port """
        if self.serial_port and self.serial_port.is_open:
            try:
                self.serial_port.write(data.encode('utf-8'))
                # Log sent commands to CLI as well
                self.log_to_cli(f"> {data.strip()}\n", "info")
            except serial.SerialException as e:
                self.log_to_cli(f"Error writing to serial: {e}\n", "error")
                self.serial_port.close()
                self.serial_port = None
        else:
            self.log_to_cli("Error: Serial port not connected.\n", "error")

    def log_to_cli(self, message, tag=None):
        """ Add a message to the CLI output window with optional styling """
        self.cli_output.configure(state=tk.NORMAL)
        
        if tag == "error":
            self.cli_output.insert(tk.END, message, "error")
        elif tag == "success":
            self.cli_output.insert(tk.END, message, "success")
        elif tag == "info":
            self.cli_output.insert(tk.END, message, "info")
        else:
            self.cli_output.insert(tk.END, message)
            
        self.cli_output.yview(tk.END) # Auto-scroll
        self.cli_output.configure(state=tk.DISABLED)

    def clear_data_readouts(self):
        """ Clear the data table and the 10 numeric boxes """
        # Clear table
        for item in self.data_table.get_children():
            self.data_table.delete(item)
            
        # Clear data boxes
        for key in self.data_boxes:
            self.data_boxes[key].set("---")

    def on_closing(self):
        """ Handle window close event """
        self.stop_thread = True
        if self.serial_thread:
            self.serial_thread.join(timeout=1)
        if self.serial_port and self.serial_port.is_open:
            self.serial_port.close()
        self.destroy()

if __name__ == "__main__":
    app = ArduinoGUI()
    
    # Configure tags for CLI styling
    app.cli_output.tag_config("error", foreground="red")
    app.cli_output.tag_config("success", foreground="green")
    app.cli_output.tag_config("info", foreground="blue")

    app.mainloop()