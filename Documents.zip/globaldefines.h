/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : globaldefines.h
 * Description  : Global constants and IO pin names
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */

#ifndef GLOBALDEFINES_H
#define GLOBALDEFINES_H
#include <stdint.h>
#include <Arduino.h>




const byte LCD_ADDRESS      = 0x27;         //I2C address of the main LCD display
const byte PD_CHIP_ADDRESS  = 0x52;         //I2C address of the AP33772S I2C chips. One on each I2C bus, both have this address.
const int MAX_PDO_ENTRIES   = 6;            //The PDOsconfigs table must have exactly 2x as many columns as this
const int READ_BUFF_LENGTH  = 12;           //I2C read buffer for PD PDOs
const int WRITE_BUFF_LENGTH = 6;            //I2C write buffer for PD PDOs
const int I2C_CLOCK         = 400000;


//LCD display dimensions. Minimum supported without code modifications is 20x4, larger should be fine
const int LCD_COLS = 20;
const int LCD_ROWS = 4;


//Pin definitions
const byte  //QC mode control
            CN1_DPLUS_HS      = 52, 
            CN1_DMINUS_HS     = 50,
            CN2_DPLUS_HS      = 48,
            CN2_DMINUS_HS     = 46,
            CN1_DPLUS_LS      = 53,
            CN1_DMINUS_LS     = 51,
            CN2_DPLUS_LS      = 49,
            CN2_DMINUS_LS     = 47, 

            //UI
            PASS              = 19,
            FAIL              = 18,
            DOWN              = 7,
            UP                = 6,
            RIGHT             = 5,
            LEFT              = 4,
            OK                = 3,
            START             = 2,

            //Power management
            HV_ENABLE         = 14,
            _10V_ENABLE       = 15,
            INVERSE_DISABLE   = 16,      
            INVERSE_VERIFY    = 17,
            _10V_MEASURE      = A9,
            VINF_MEASURE      = A8,
            LOAD1_DISABLE     = A5,
            LOAD2_DISABLE     = A2, 
            CN1_CURRENT       = A6,
            CN1_VOLTAGE       = A7,
            CN2_CURRENT       = A3,
            CN2_VOLTAGE       = A4,

            HEADER_ID1        = A10,
            HEADER_ID2        = A11;


//Categories for the pins used by resetIO function to avoid repetitive pinMode/digitalWrite/etc statements and unexpected states
const int defaultHighPins[] = {CN1_DPLUS_HS, CN1_DMINUS_HS, CN2_DPLUS_HS, CN2_DMINUS_HS, LOAD1_DISABLE, LOAD2_DISABLE, INVERSE_DISABLE};
const int defaultLowPins[] = {CN1_DPLUS_LS, CN1_DMINUS_LS, CN2_DPLUS_LS, CN2_DMINUS_LS, HV_ENABLE, _10V_ENABLE, PASS, FAIL};
const int buttonPins[] = {UP, DOWN, LEFT, RIGHT, START, OK};
const int inputPins[] = {INVERSE_VERIFY, _10V_MEASURE, VINF_MEASURE, HEADER_ID1, /*HEADER_ID2,*/ CN1_CURRENT, CN1_VOLTAGE, CN2_CURRENT, CN2_VOLTAGE};

//Ratios of the voltage dividers on the ADC pins
const float VOUT_MEASURE_DIVIDER = 9.2;
const float VINF_MEASURE_DIVIDER = 11;
const float _10V_MEASURE_DIVIDER = 7;

const float LOAD_CURRENT_LIMIT = 6;     //Current reading to trip the load's OCP
const float LOAD_LEAKAGE_LIMIT = 0.5;   //Maximum acceptable measured current through a disabled load. Compare to the absolute value of the measurement to cover calibration errors


#endif