/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : main.cpp
 * Description  : Software for the USB universal tester box. Can be configured to test 
 *                any single or dual USB power product including PD, QC, type A or C.
 *                NOTE: see productdata.cpp for configuration info 
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */

#include <Wire.h>
#include <stdint.h>
#include <Arduino.h>
#include "globaldefines.h"
#include "productdata.h"
#include "ui.h"
#include "functions.h"
#include "calibrate.h"
#include "database.h"

Database db;




//*******************************************************DEV MODE FLAGS***************************************************************

//ALL OF THESE MUST BE COMMENTED OUT FOR PRODUCTION BUILDS

//#define HARDWARE_TEST           //Override entire loop, display live USB and LED status on LCD
#define DEV_CAL                 //Skip calibration routine, load defaults instead
//#define SKIP_LED_COLOUR         //Skip the colour sensor test so the tester works outside the lightproof box
//#define SKIP_PDO_CHECK          //Ignore PD firmware mismatches, run power tests at whatever voltage the DUT advertises
//#define IGNORE_CONNECTOR_ID     //Ignore wrong USB connector daughter board


//************************************************************************************************************************************

extern byte writeBuf[WRITE_BUFF_LENGTH];
calibrate Calibrate;

//total test cycles passed since last reboot
uint32_t passCount = 0;
extern uint32_t failCount;


uint16_t selected = 1; //currently selected product from the products table
uint16_t range = 0;    //currently selected range from the productranges table

const uint32_t STANDARD_INVERSE_PUMP_TIME = 300;    //Time in ms for the -10V charge pump 
const uint32_t EXTRA_INVERSE_PUMP_TIME = 1000;      //Extended -10V charge pump time for products with unprotected input capacitance (eg PD Marine)


//Button and LCD timing controls
const unsigned long debounceMs = 250; //time since last input when further inputs are blocked
//const unsigned long idleTimeout = 60000; //time to leave PASSED on the display before returning to product select screen
unsigned long lastActionTime   = 0;
bool needsRefresh = false;


//Structure of the AP33772S PD chip's i2c register
typedef struct {
  union {
    struct {
      unsigned int VOLTAGE_SEL: 8;  // Bits 7:0, Output Voltage Select
      unsigned int CURRENT_SEL: 4;  // Bits 11:8, Operating Current Select
      unsigned int PDO_INDEX: 4;  // Bits 15:12, Source PDO index select
      
    } REQMSG_Fields;
    struct {
      byte byte0;
      byte byte1;
    };
  unsigned long data;
  };
} RDO_DATA_T;



//******************************************************************GUI startup*************************************************************
void setup() {

  resetIO(); //Make sure the IO pins are properly configured before doing anything
  int error = 0;

  Wire.begin();
  Wire1.begin();
  Serial.begin(115200);
  while (!Serial) delay(10);
  delay(100);  // Add a delay to prevent flooding the serial output

  Wire.setClock(I2C_CLOCK);
  Wire1.setClock(I2C_CLOCK);
  Wire.beginTransmission(LCD_ADDRESS);
  error = Wire.endTransmission();
  db.begin();                // init flash scanning & load counters
  db.log(Database::INFO, "System start"); // example

  if (error == 0) { 
    Serial.println("LCD found.");
    initialiseLCD();
    delay(500);
    needsRefresh = true;
  } else {                
    Serial.println("LCD not found.");
    blink();                             
  }
  if(!validateProductRanges()){
    printToLCD("Product data configuration error");
    Serial.println("Product data configuration error");
    blink();
  }
  

  //Initialise both load banks and the colour sensor chip

  loadInit();
  //colourInit();
  pinMode(HEADER_ID2, OUTPUT);
  pinMode(HEADER_ID1, INPUT);
  digitalWrite(HEADER_ID2, LOW);



//**************************************************Set up load calibration values*****************************************************
  analogReadResolution(12); //Set the ADC to its full 12 bit resolution

  #ifndef HARDWARE_TEST
  #ifndef DEV_CAL
  Serial.print("Calibration data found?: ");
  if (Calibrate.isBlank()) {                             // will execute each time the flash is wiped or the firmware is updated
    Serial.println("no");
    failout(0xE1, "Tester is uncalibrated. Press Left, Right and OK together to enter calibration mode");
    Serial.println("A 4+ digit multimeter with a JST 2-pin to banana plug cable is required");

    //Lock out with breakout code the same as the calibration start code - skips directly to cal if held
    while(1){
      if(digitalRead(LEFT) == LOW && digitalRead(RIGHT) == LOW && digitalRead(OK) == LOW) return;
      delay(10);
    }
  }
  else {
    Serial.println("yes");
    if (!Calibrate.loadData()){
      failout(0xE2, "Cal required on reboot");
      blink(); 
    }
    printToLCD("USB Universal Tester Ready");
    delay(1000);
  } 
  #endif
  #endif
}


void loop() {
  pollSerialController();
    //db.handleSerialCommands(); // non-blocking check for "GETLOG" etc.
//***************************************************************Hardware Test***************************************************************

#ifdef HARDWARE_TEST
Calibrate.setDefault();
digitalWrite(HV_ENABLE, HIGH);
printToLCD("LED is:", 0, 3, false);
while(1){
  
  Serial.println(" ");


  auto detectedPDOs1 = getPDOs(1);
  if(checkPDOsMatch(1, 1, detectedPDOs1)){ 
    printToLCD("USBC 1 connected    ", 0, 0, false);
  }
  else{
    printToLCD("USBC 1 not connected", 0, 0, false);
  }


  auto detectedPDOs2 = getPDOs(2);
  if(checkPDOsMatch(2, 1, detectedPDOs2)){       
    printToLCD("USBC 2 connected    ", 0, 1, false);
  }
  else{
    printToLCD("USBC 2 not connected", 0, 1, false);
  }
  float v1 = analogRead(CN1_VOLTAGE) * 0.00079728 * VOUT_MEASURE_DIVIDER;
  float v2 = analogRead(CN2_VOLTAGE) * 0.00079728 * VOUT_MEASURE_DIVIDER;


  printToLCD("1:" + String(v1, 1) + "V, 2:" + String(v2, 1) + "V",0,2,false);
  Serial.println(" ");
  String colour = getLEDColour(false);
  printToLCD(colour + "      ",8,3,false);
}
#endif

//***************************************************************Calibration***************************************************************
//If LEFT, RIGHT and OK are held simultaneously, enter load calibrate mode, with reduced debounce time for priority
  if(digitalRead(LEFT) == LOW && digitalRead(RIGHT) == LOW && digitalRead(OK) == LOW && millis() - lastActionTime + 100 > debounceMs){
    #ifndef DEV_CAL
    digitalWrite(HV_ENABLE, HIGH);  

    
    if(Calibrate.calibrateADC()){
      promptAndWait("ADC calibration success\n\nGain = " + String(Calibrate.ADCCalFactor, 8));
    }
    else{
      printToLCD("ADC calibration fail. Reboot tester and try again");
      blink();
    }


    if(Calibrate.calibrateLoad(1)){ //+++++++++++++++add sanity check
      promptAndWait("Load 1 calibration success\nGain: " + String(Calibrate.load1Cal.gain, 2) + "\nOffset: " + String(Calibrate.load1Cal.offset, 2));
    }
    else{
      printToLCD("Calibration failed: load 1 out of range. Reboot tester and try again");
      blink();
    }

    if(Calibrate.calibrateLoad(2)){ 
      promptAndWait("Load 2 calibration success\nGain: " + String(Calibrate.load2Cal.gain, 2) + "\nOffset: " + String(Calibrate.load2Cal.offset, 2));
    }
    else{
      printToLCD("Calibration failed: load 2 out of range. Reboot tester and try again");
      blink();
    }


    delay(1000);
    if(Calibrate.calibrateColour()){
      promptAndWait("Success, press OK then insert production unit(s) to validate");

      digitalWrite(HV_ENABLE, HIGH);
      printToLCD("Live sensor readout:\nLED is:\n \npress OK to continue");
      delay(1000);
      while(digitalRead(OK) == HIGH){
        String colour = getLEDColour();
        printToLCD(colour + "      ",8,1,false);
        delay(100);
      }
    }
    else{
      return;
    }

    printToLCD("Calibration complete\nSave data to flash?\nY<\nN");
    if(YNchoice()){
      Calibrate.save();
      promptAndWait("Calibration complete\nData saved");

    }   
    else{
      promptAndWait("Data save was cancelled but it is still in memory. Reboot or run cal again to wipe");
    }
    delay(1000); 
    #endif

    #ifdef DEV_CAL
    Calibrate.setDefault();       
    #endif                                
  }

//***************************************************************UI Product selection***************************************************************

  //Software debounce/skip prevention
  if (millis() - lastActionTime > debounceMs){

    // Product Range navigation
    if (digitalRead(LEFT) == LOW){
       range = selectRange(-1);
       selected = selectProduct(0);
    }

    if (digitalRead(RIGHT) == LOW){
      range = selectRange(+1);
      selected = selectProduct(0);
    }

    // Product navigation within the current range
    if (digitalRead(UP) == LOW)   selected = selectProduct(-1);
    if (digitalRead(DOWN) == LOW) selected = selectProduct(+1);
  }

  // Check for barcode scanner input (USB serial) and update selection if matched
  {
    uint16_t scanned = readBarcodeProductIndex();
    if (scanned != 0) {
      // Ensure scanned index is within bounds
      if (scanned < nProducts) {
        selected = scanned;
        needsRefresh = true;
      }
    }
  }

  //Update LCD only when needed, or after the idle timeout (feature currently disabled)
  if (needsRefresh /*|| millis() - lastActionTime > idleTimeout*/) {
    printToLCD(String(productRanges[range].name) + "\n" + products[selected].partNumber);
    needsRefresh = false;
    lastActionTime = millis();
  }




//*************************************************************Testing loop***************************************************************
  if (digitalRead(START) == LOW && millis() - lastActionTime > debounceMs)  //All button inputs are active low
  {
    resetIO(); //Make sure the IO pins are properly configured before anything

    lastActionTime = millis();
    printToLCD(" ");

    float VinF = measureVoltage(VINF_MEASURE);
    if(VinF > 30 || VinF < 22){
      failout(0xE5, "Check supply voltage \nAllowable input range 22-30V. Measured: " + String(VinF, 2) + "V");
      return;
    }

    float _10V_ = measureVoltage(_10V_MEASURE);
    if(_10V_ > 10.5 || _10V_ < 9.2){
      failout(0xE2, "Internal 10V supply AOZ1284 fault. Allowable range 9.5-10.5V. Measured: " + String(_10V_, 2) + "V"); 
      return;
    }           


    #ifndef IGNORE_CONNECTOR_ID

    float connectorIDVoltage = 3.3/(1 + products[selected].connectorID); //Converts potential divider ratio into expected voltage
    float measuredIDVoltage = analogRead(HEADER_ID1) * Calibrate.ADCCalFactor;
    Serial.println("ADC = " + String(analogRead(HEADER_ID1)) + ", Measured voltage = " + String(measuredIDVoltage) + ", ID voltage = " + String(connectorIDVoltage));
    
    if(abs(connectorIDVoltage - measuredIDVoltage) > 0.1){
      failout(0xE3, "Wrong USB daughterboard for selected product detected"); 
      return;
    }
    #endif

  //********************************************************************Non-USB tests********************************************************************     
    Serial.println("_________________________\n \nProduct test start");
    
    int waitTime = (products[selected].extraCapacitance == true) ? EXTRA_INVERSE_PUMP_TIME : STANDARD_INVERSE_PUMP_TIME;

    if(!(inversePolarity(waitTime))){      
      failout(0xF3, "Reverse polarity protection fail");
      return;
    };
    digitalWrite(HV_ENABLE, HIGH);
    printToLCD("Inverse voltage complete");

    delay(500); //Time for the voltage to rise and the LED to turn on

    #ifndef SKIP_LED_COLOUR
    String colour = getLEDColour();               

    if (colour == "Error"){
      failout(0xE2, "Colour sensor read error");
      return;
    }
    if (colour == "Saturated"){
      failout(0xE2, "Colour sensor is saturated - likely caused by sunlight leakage");
      return;
    }
    if (colour != products[selected].LEDColour){
      failout(0xF1, "LED colour failed. Expected: " + products[selected].LEDColour + ", Actual: " + colour);
      return;
    }
    
    printToLCD("LED colour test complete",0,2,false);
    #endif


  //*******************************************************************5V power tests*******************************************************************
    Serial.println("_________________________\n5V power test");
      
    int testResult = 0;
    
    //Lower port test
    if(products[selected].connectorLower == "A" || products[selected].connectorLower == "C"){
      testResult = measureDUT(2, products[selected].IOutMaxLower, products[selected].VOutMinLower, products[selected].VOutMaxLower);

      if(testResult != 0){
          (testResult == 1) ? failout(0xE4, " (5V test)")
        : (testResult == 2) ? failout(0xF4, " (5V test)")
                            : failout(testResult, " "); 
        return;
      }
    }

    //Upper port test
    if(products[selected].connectorUpper == "A" || products[selected].connectorUpper == "C"){
      testResult = measureDUT(1, products[selected].IOutMaxUpper, products[selected].VOutMinUpper, products[selected].VOutMaxUpper);

      if(testResult != 0){
          (testResult == 1) ? failout(0xE4, " (5V test)")
        : (testResult == 2) ? failout(0xF4, " (5V test)")
                            : failout(testResult, " "); 
        return;
      }
    }
    printToLCD("5V Power test complete");



//****************************************************************PD tests section************************************************************
    //Detect PD and attempt PD handshake for any PD ports
    if(products[selected].hasPD){
      RDO_DATA_T rdoData;
      rdoData.byte0 = 0;
      rdoData.byte1 = 0;
      int PDOsConfigsRow = products[selected].PDOsIndex;


      //Lower port PD test
      if(products[selected].connectorLower == "C"){
        Serial.println("_________________________\nLower port PD test:");

        //Read PD PDOs from the lower USBC port and compare them to the target PDOs
        auto detectedPDOs = getPDOs(2);
        Serial.println("Lower port 27V PDOS:");
        if(!(checkPDOsMatch(2, PDOsConfigsRow, detectedPDOs))){        //Target PDOs for lower port are the last six entries in the PDOsIndex row
          #ifndef SKIP_PDO_CHECK
          failout(0xF6, "Lower port PD PDOs dont match");
          return;
          #endif
        }

        //Select highest supported voltage
        bool match = false;
        for (int i = 0; i < MAX_PDO_ENTRIES; i ++) {
          if(((detectedPDOs[i] % 256 ) / 10) == products[selected].PDQCVMaxLower){
            rdoData.REQMSG_Fields.PDO_INDEX = i+1;
            match = true;
            Serial.println("Selecting PDO #" + String(i));
            break;
          }
        }
        if(!match){
          failout(0xE2, "PDO data matched but the max output voltage specified was not found - likely a config typo");
          return;
        }

        //Convert current in amps to AS33772S register values
        rdoData.REQMSG_Fields.CURRENT_SEL = (products[selected].PDQCIMaxLower - 1) * 4; 
        writeBuf[0] = rdoData.byte0;  // Store the upper 8 bits
        writeBuf[1] = rdoData.byte1;  // Store the lower 8 bits
        i2c_write(Wire1, PD_CHIP_ADDRESS, 0x31, writeBuf, 2);

        //Lower port PD power test
        testResult = measureDUT(2, products[selected].PDQCIMaxLower, (products[selected].PDQCVMaxLower - 1), (products[selected].PDQCVMaxLower + 1));
        if (testResult != 0){
           (testResult == 1) ? failout(0xE4, " (PD test)")
          :(testResult == 2) ? failout(0xF7, " (PD test)")
                             : failout(testResult, " "); 
          return;                 
        }

        rdoData.REQMSG_Fields.PDO_INDEX = 1;                                
        rdoData.REQMSG_Fields.CURRENT_SEL = (products[selected].PDQCIMaxLower - 1) * 4; 
        writeBuf[0] = rdoData.byte0;  // Store the upper 8 bits
        writeBuf[1] = rdoData.byte1;  // Store the lower 8 bits
        i2c_write(Wire1, PD_CHIP_ADDRESS, 0x31, writeBuf, 2);
      }
      rdoData.byte0 = 0;
      rdoData.byte1 = 0;


      //Upper port PD test
      if(products[selected].connectorUpper == "C"){
        Serial.println("_________________________\nUpper port PD test:");

        //Read PD PDOs from the upper USBC port and compare them to the target PDOs
        auto detectedPDOs = getPDOs(1);
        Serial.println("Upper port 27V PDOS:");
        if(!(checkPDOsMatch(1, PDOsConfigsRow, detectedPDOs))){        //Target PDOs for upper port are the first six entries in the PDOsIndex row
          #ifndef SKIP_PDO_CHECK
          failout(0xF6, "Upper port PD PDOs dont match");
          return;
          #endif
        }

        //Select highest supported voltage
        bool match = false;
        for (int i = 0; i < MAX_PDO_ENTRIES; i ++) {
          if(((detectedPDOs[i] % 256 ) / 10) == products[selected].PDQCVMaxUpper){
            rdoData.REQMSG_Fields.PDO_INDEX = i + 1;  //AP33772S PDO_INDEX register is 1-indexed (kill me)
            match = true;
            Serial.println("Selecting PDO #" + String(i));
            break;
          }
        }
        if(!match){
          failout(0xE2, "PDO data matched but the max output voltage specified was not found - likely a config typo");
          return;
        }

        //Convert current in amps to AS33772S register values
        rdoData.REQMSG_Fields.CURRENT_SEL = (products[selected].PDQCIMaxUpper - 1) * 4; 
        writeBuf[0] = rdoData.byte0;  // Store the upper 8 bits
        writeBuf[1] = rdoData.byte1;  // Store the lower 8 bits
        i2c_write(Wire, PD_CHIP_ADDRESS, 0x31, writeBuf, 2);

        testResult = measureDUT(1, products[selected].PDQCIMaxUpper, (products[selected].PDQCVMaxUpper - 1), (products[selected].PDQCVMaxUpper + 1));
        if (testResult != 0){
           (testResult == 1) ? failout(0xE4, " (PD test)")
          :(testResult == 2) ? failout(0xF7, " (PD test)")
                             : failout(testResult, " "); 
          return;
        }

        //Reset PD to 5V
        rdoData.REQMSG_Fields.PDO_INDEX = 1;                                
        rdoData.REQMSG_Fields.CURRENT_SEL = (products[selected].PDQCIMaxUpper - 1) * 4; 
        writeBuf[0] = rdoData.byte0;  // Store the upper 8 bits
        writeBuf[1] = rdoData.byte1;  // Store the lower 8 bits
        i2c_write(Wire, PD_CHIP_ADDRESS, 0x31, writeBuf, 2);
      }
      printToLCD("PD power tests complete");
    }


//**********************************************************10V derating/UVLO tests*********************************************************
    //derating test for 9-32Vin products

    digitalWrite(HV_ENABLE, LOW);       //Disable both rails to force reboot DUT
    digitalWrite(_10V_ENABLE, LOW);
    printToLCD("10V test running", 0,2,false);
    delay(200);

    digitalWrite(_10V_ENABLE, HIGH);  
    for(int i = 0; i < 10; i++){
      printToLCD(".", i,3,false);
      delay(200);
    }
    //delay(2000); //+++++++++++++1700 minimum validated (PD-AC). Test voltage fall time on scope

    if(!(products[selected].Is24VoltOnly) && products[selected].hasPD){
      Serial.println("_________________________\nLow Vin derating test");
      int PDOsConfigsRow = products[selected].DeratePDOsIndex;

      if(products[selected].connectorLower == "C"){
        auto detectedPDOs = getPDOs(2);
        Serial.println("Lower port 10V PDOS:");
        if(!(checkPDOsMatch(2, PDOsConfigsRow, detectedPDOs))){        //Target PDOs for lower port are the first six entries in the DeratePDOsIndex row
          #ifndef SKIP_PDO_CHECK
          failout(0xF6, "Lower port 10V derated PD PDOs dont match");
          return;
          #endif
        }
      }

      if(products[selected].connectorUpper == "C"){
        auto detectedPDOs = getPDOs(1);
        Serial.println("Upper port 10V PDOS:");
        if(!(checkPDOsMatch(1, PDOsConfigsRow, detectedPDOs))){        //Target PDOs for upper port are the last six entries in the DeratePDOsIndex row
          #ifndef SKIP_PDO_CHECK
          failout(0xF6, "Upper port 10V derated PD PDOs dont match");
          return;
          #endif
        }
      }
    }

    //24V only UVLO test
    if(products[selected].Is24VoltOnly){
      Serial.println("_________________________\nLow Vin UVLO test");

      //Enable loads, pull leakage current from the ports to discharge output caps
      digitalWrite(LOAD1_DISABLE, LOW);
      digitalWrite(LOAD2_DISABLE, LOW);

      delay(200);
      float v1 = measureVoltage(CN1_VOLTAGE);
      analogRead(CN2_VOLTAGE);
      float v2 = measureVoltage(CN2_VOLTAGE);
      Serial.println("Output V with 10V in :\nUpper port: " + String(v1) + "V\nLower port: " + String(v2) + "V");

      if(v1 > 3 && products[selected].connectorUpper == "C"){
          failout(0xF10, "24V product upper port did not shut down at 10V in");
          return;
      }      
      if(v2 > 3 && products[selected].connectorLower == "C"){
          failout(0xF10, "24V product lower port did not shut down at 10V in");
          return;
      }
    }
    
    printToLCD("10V test complete");  
    resetIO();              
    digitalWrite(HV_ENABLE, HIGH);                                       
    delay(100);

//*******************************************************************QC tests section******************************************************************

    //HS switches are active low, LS switches are active high, both HIGH = output grounded

    //Lower port test
    if(products[selected].hasQC && products[selected].connectorLower == "A"){   
      Serial.println("_________________________\nLower port QC test");

      //Enter QC mode
      digitalWrite(CN2_DPLUS_LS, HIGH);
      digitalWrite(CN2_DPLUS_HS, LOW);                               
      digitalWrite(CN2_DMINUS_LS, HIGH);
      digitalWrite(CN2_DMINUS_HS, HIGH); 

      //delay(1500);                 //delay time is part of QC handshake
      printToLCD("QC test Port 2");
      for(int i = 0; i < 7; i++){
        printToLCD(".", i,3,false);
        delay(200);
      }


      if(products[selected].PDQCVMaxLower == 9){
        Serial.println("QC test port 2\nRequesting 9V");
        digitalWrite(CN2_DMINUS_HS, LOW);
        digitalWrite(CN2_DPLUS_LS, LOW);
      }

      if(products[selected].PDQCVMaxLower == 12){         
        Serial.println("QC test port 2\nRequesting 12V");
        digitalWrite(CN2_DMINUS_HS, LOW); 
      }

      //If PDQCVMaxLower has any value other than 9 or 12 the QC setting will stay at default and the next test will fail. 
      //Add more if statements for different QC modes/voltages for this port, nothing else needs to be changed
      delay(100);

      testResult = measureDUT(2, products[selected].PDQCIMaxLower, (products[selected].PDQCVMaxLower - 1), (products[selected].PDQCVMaxLower + 1));
      if(testResult != 0){
          (testResult == 1) ? failout(0xE4, " (QC test)")
        : (testResult == 2) ? failout(0xF5, " (QC test)")
                            : failout(testResult, " "); 
        return;
      }

      resetIO();
      digitalWrite(HV_ENABLE, HIGH);
      printToLCD("Done",16,0,false);
    }


    //Upper port test
    if(products[selected].hasQC && products[selected].connectorUpper == "A"){    
      Serial.println("_________________________\nUpper port QC test");

      //Enter QC mode
      digitalWrite(CN1_DPLUS_LS, HIGH);
      digitalWrite(CN1_DPLUS_HS, LOW);                               
      digitalWrite(CN1_DMINUS_LS, HIGH);
      digitalWrite(CN1_DMINUS_HS, HIGH);

      //delay(1500);                 
      printToLCD("QC test Port 1");
      for(int i = 0; i < 7; i++){
        printToLCD(".", i,3,false);
        delay(200);
      }

      if(products[selected].PDQCVMaxUpper == 9){
        Serial.println("QC test port 1\nRequesting 9V");
        digitalWrite(CN1_DMINUS_HS, LOW);
        digitalWrite(CN1_DPLUS_LS, LOW);
      }

      if(products[selected].PDQCVMaxUpper == 12){         
        Serial.println("QC test port 1\nRequesting 12V");
        digitalWrite(CN1_DMINUS_HS, LOW); 
      }

      //If PDQCVMaxLower has any value other than 9 or 12 the QC setting will stay at default and the next test will fail. 
      //Add more if statements for different QC modes for this port, nothing else needs to be changed
      delay(100);

      testResult = measureDUT(1, products[selected].PDQCIMaxUpper, (products[selected].PDQCVMaxUpper - 1), (products[selected].PDQCVMaxUpper + 1));
      if(testResult != 0){
          (testResult == 1) ? failout(0xE4, " (QC test)")
        : (testResult == 2) ? failout(0xF5, " (QC test)")
                            : failout(testResult, " "); 
        return;
      }
    }
    resetIO();
    digitalWrite(HV_ENABLE,HIGH);
    passCount++;
    /*printToLCD("PASSED\n       " + String(millis() - lastActionTime) + "ms\n" +
    "Pass:" + String(passCount),7,1,true);*/

    printToLCD("PASSED\n \nPass:" + String(passCount),7,1,true);
    
    //Right-justify the fail count to look neater on the display
    uint32_t fails = failCount;
    uint8_t failsLength = 6;                                                    //length of string to right-justify, starts at 6 characters: "Fail:" plus one digit
    while (fails >= 10){                                                        //add 1 for every additional decimal digit
        fails /= 10;
        failsLength++;
    }
    printToLCD("Fail:" + String(failCount),(LCD_COLS - failsLength),3,false);   //Start printing (failsLength) columns from the right

    lastActionTime = millis();
    digitalWrite(PASS, HIGH);       //Product passed if all tests are completed

    detectRemoval(products[selected].LEDColour);    //Wait for the DUT to be removed before allowing another test     
  }
}