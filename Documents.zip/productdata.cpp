/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : productdata.h
 * Description  : Contains all inputtable data on the products and product ranges to be tested
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */

 #include "productdata.h"
 #include <stdint.h>



//Add rows to this to add more products. 
//The fields are explained below 
//Don't forget to assign new products to a product range
//Row 0 is reserved as an error catch
productStruct products[] = {
/*0*/   {" ",                    false, false, false, 0,0,0,"NA",0,0,                0,0,0,"NA",0,0,              "Error", 0,0,0, false},
/*1*/   {"PDA090CC Blue",        true, false, false,  5.5, 4.7, 3, "C", 20, 2.25,    5.5, 4.7, 3, "C", 20, 2.25,  "Blue", 2, 4, 2.2, false},
/*2*/   {"PDA060AC Blue",        true, true, false,   5.5, 4.7, 3, "C", 20, 2.25,    5.5, 4.4, 2, "A", 12, 1.2,   "Blue", 2, 4, 9999, false},
/*3*/   {"PDR060C Blue",         true, false, true,   5.5, 4.7, 3, "C", 20, 3,       0, 0, 0, "NA", 0, 0,         "Blue", 1, 0, 5.6, false},
/*4*/   {"PDR090CC Blue",        true, false, true,   5.5, 4.7, 3, "C", 20, 2.25,    5.5, 4.7, 3, "C", 20, 2.25,  "Blue", 2, 0, 2.2, false},
/*5*/   {"PDR075AC Blue",        true, true, true,    5.5, 4.4, 3, "C", 20, 3,       5.5, 4.4, 2, "A", 12, 1.2,   "Blue", 1, 0, 9999, false},
/*6*/   {"PD Marine Blue",       true, false, false,  5.5, 4.7, 3, "C", 20, 3,       0, 0, 0, "NA", 0, 0,         "Blue", 1, 3, 5.6, true},
/*7*/   {"PDA060C Blue",         true, false, false,  5.5, 4.7, 3, "C", 20, 3,       0, 0, 0, "NA", 0, 0,         "Blue", 1, 3, 5.6, false},
/*8*/   {"PDA075AC Blue",        true, true, true,    5.5, 4.4, 3, "C", 20, 3,       5.5, 4.4, 2, "A", 12, 1.2,   "Blue", 1, 0, 9999, false},
/*9*/   {"PDA090CC No LED",      true, false, false,  5.5, 4.7, 3, "C", 20, 2.25,    5.5, 4.7, 3, "C", 20, 2.25,  "Dark", 2, 4, 2.2, false},
/*10*/  {"B09NY54HR5PDA060AC No LED",      true, true, false,   5.5, 4.7, 3, "C", 20, 2.25,    5.5, 4.4, 2, "A", 12, 1.2,   "Dark", 2, 4, 9999, false},
/*11*/   {"PDR060C No LED",      true, false, true,   5.5, 4.7, 3, "C", 20, 3,       0, 0, 0, "NA", 0, 0,         "Dark", 1, 0, 5.6, false},
/*12*/   {"PDR090CC No LED",     true, false, true,   5.5, 4.7, 3, "C", 20, 2.25,    5.5, 4.7, 3, "C", 20, 2.25,  "Dark", 2, 0, 2.2, false},
/*13*/   {"PDR075AC No LED",     true, true, true,    5.5, 4.4, 3, "C", 20, 3,       5.5, 4.4, 2, "A", 12, 1.2,   "Dark", 1, 0, 9999, false},
/*14*/   {"PD Marine No LED",    true, false, false,  5.5, 4.7, 3, "C", 20, 3,       0, 0, 0, "NA", 0, 0,         "Dark", 1, 3, 5.6, true},
/*15*/   {"PDA060C No LED",      true, false, false,  5.5, 4.7, 3, "C", 20, 3,       0, 0, 0, "NA", 0, 0,         "Dark", 1, 3, 5.6, false},
/*16*/   {"PDA075AC No LED",     true, true, true,    5.5, 4.4, 3, "C", 20, 3,       5.5, 4.4, 2, "A", 12, 1.2,   "Dark", 1, 0, 9999, false},
};
//++++++++++++++++++++PDR UNITS WTH BROKEN UVLO CIRCUITS MUST BE MADE TO FAIL PDA TESTS++++++++++++++++++++++
/*Field definitions for the table
  String partNumber            0 - Product name that will be displayed on the LCD display, 20 character limit

  bool hasPD                   1 - True = Tester will run PD test on all C ports
  bool hasQC                   2 - True = Tester will run QC test on all ports
  bool Is24VoltOnly            3 - True = Test will fail if the unit still functions at 10V input

  float VOutMaxLower           4 - Max pass voltage in 5V mode
  float VOutMinLower           5 - Min pass voltage in 5V mode
  float IOutMaxLower           6 - Max current to test in 5V mode
  String connectorLower        7 - Lower connector type, A or C or NA
  uint16_t PDQCVMaxLower       8 - Max voltage to test in PD/QC mode. Valid voltages are 5,9,12,15,18,20. Others will cause errors or default to 5V
  float PDQCIMaxLower          9 - Test current at max PD/QC voltage

  float VOutMaxUpper           10- Max pass voltage in 5V mode
  float VOutMinUpper           11- Min pass voltage in 5V mode
  float IOutMaxUpper           12- Max current to test in 5V mode
  String connectorUpper        13- Upper connector type, A or C or NA
  uint16_t PDQCVMaxUpper       14- Max voltage to test in PD/QC mode. Valid voltages are 5,9,12,15,18,20. Others will cause errors or default to 5V
  float PDQCIMaxUpper          15- Test current at max PD/QC voltage
  
  String LEDColour             16- Indicator LED colour. Detectable colours are Red, Yellow, Green, Blue, Violet, White, Dark (ie no LED)
  uint16_t PDOsIndex           17- Row in PDOs array with the PD config data for this product. Multiple products can be assigned the same row
  uint16_t DeratePDOsIndex     18- Row in PDOs array with the low voltage derated config data. Multiple products can be assigned the same row
  uint16_t connectorID         19- Ratio of resistor values in the divider on the daughterboard. High side value / low side value
  bool extraCapacitance        20- True = wait longer during reverse polarity test to charge unprotected input capacitance - for marine input filters
  */



//These reference rows in the main data table. Each product can appear in any number of ranges. 
//Do not assign row 0 to any range, and don't leave any range blank
const uint16_t PDAutomotive[] = {1,2,7,8,9,10,15,16};
const uint16_t PDMarine[] = {6,14};
const uint16_t PDRail[] = {3,4,5,11,12,13};

//List of all product ranges. Make sure to add and populate a new index array above for any new added ranges
//Name strings over 20 characters will be split across multiple display lines
productRange productRanges[] = {
/*0*/  { "PD Automotive"                            , PDAutomotive,  sizeof(PDAutomotive)  / sizeof(PDAutomotive[0]) },
/*1*/  { "PD Marine"                                , PDMarine,   sizeof(PDMarine)   / sizeof(PDMarine[0])  },
/*2*/  { "PD Rail"                                  , PDRail,   sizeof(PDRail)   / sizeof(PDRail[0])  },
};
const size_t nRanges = sizeof(productRanges) / sizeof(productRanges[0]);
const size_t nProducts = sizeof(products) / sizeof(products[0]);
const size_t nPDOConfigs = sizeof(PDOsConfigs) / sizeof(PDOsConfigs[0]);


//List of different configurations for PD PDOs (ie voltage/current capabilities).
//The entries are raw two byte long register values in the AP33772S PD chips. 0x0000 means no PDO is expected
//The first six values in each row correspond to the upper port, the last six correspond to the lower port.
//The test will pass if each non zero entry matches a received PDO. Wrong order and multiple matches are ignored
uint16_t PDOsConfigs[][12]{
/*0*/ {0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,     0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000},   //Reserved for non-PD 
/*1*/ {0xa032, 0xa05a, 0xa096, 0xa0c8, 0x0000, 0x0000,     0xa032, 0xa05a, 0xa096, 0xa0c8, 0x0000, 0x0000},   //60W profile
/*2*/ {0xa032, 0xa05a, 0xa096, 0x94c8, 0x0000, 0x0000,     0xa032, 0xa05a, 0xa096, 0x94c8, 0x0000, 0x0000},   //45W profile
/*3*/ {0xa032, 0xa05a, 0x9878, 0x9096, 0x0000, 0x0000,     0xa032, 0xa05a, 0x9878, 0x9096, 0x0000, 0x0000},   //30W profile
/*4*/ {0xa032, 0x885a, 0x8478, 0x8096, 0x0000, 0x0000,     0xa032, 0x885a, 0x8478, 0x8096, 0x0000, 0x0000},   //15W profile
/*5*/ {0xa032, 0xa05a, 0x9878, 0x9096, 0x0000, 0x0000,     0xa032, 0xa05a, 0x9878, 0x9096, 0x0000, 0x0000},   //Unprogrammed PD at 10Vin
};

//AP33772S PDO REGISTER FORMATS:
//
//*****Fixed voltage (standard) PDOs*****
// Bits 7:0,    VOLTAGE_MAX field
// Bits 9:8,    PEAK_CURRENT field
// Bits 13:10,  CURRENT_MAX field
// Bit 14,      TYPE field
// Bit 15,      DETECT field

//******PPS (variable voltage) PDOs******
// Bits 7:0,    VOLTAGE_MAX field
// Bits 9:8,    VOLTAGE_MIN field
// Bits 13:10,  CURRENT_MAX field
// Bit 14,      TYPE field
// Bit 15,      DETECT field

//*********AVS (above 100W) PDOs*********
// Bits 7:0,    VOLTAGE_MAX field
// Bits 9:8,    VOLTAGE_MIN field
// Bits 13:10,  CURRENT_MAX field
// Bit 14,      TYPE field
// Bit 15,      DETECT field


bool validateProductRanges() {
  for (size_t r = 0; r < nRanges; r++) {
    if(productRanges[r].count == 0){
        Serial.println("The product range '" + String(productRanges[r].name) + "' is blank");
        return false;
    }
    for (size_t i = 0; i < productRanges[r].count; i++) {
      uint16_t idx = productRanges[r].items[i];
      if (idx >= sizeof(products) / sizeof(products[0])) {
        Serial.println("Invalid product index " + String(idx) + " in range " + String(r));
        return false;
      }
    }
  }
  return true;
}