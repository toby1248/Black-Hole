/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : productdata.h
 * Description  : See productdata.cpp to add new products to the tester
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */

#ifndef PRODUCTDATA_H
#define PRODUCTDATA_H

#include <stdint.h>
#include <Arduino.h>

struct productStruct {
  String partNumber;            //0 - Product name that will be displayed on the LCD display, 20 character limit
  bool hasPD;                   //1 - True = Tester will run PD test on all C ports
  bool hasQC;                   //2 - True = Tester will run QC test on all ports
  bool Is24VoltOnly;            //3 - True = Test will fail if the unit still functions at 10V input
  float VOutMaxLower;           //4 - Max pass voltage in 5V mode
  float VOutMinLower;           //5 - Min pass voltage in 5V mode
  float IOutMaxLower;           //6 - Max current in 5V mode
  String connectorLower;        //7 - Lower connector type, A or C or NA
  uint16_t PDQCVMaxLower;       //8 - Max voltage to test in PD/QC mode. Valid voltages are 5,9,12,15,18,20. Other values will default to 5V
  float PDQCIMaxLower;          //9 - Test current at max PD/QC voltage
  float VOutMaxUpper;           //10- Max pass voltage in 5V mode
  float VOutMinUpper;           //11- Min pass voltage in 5V mode
  float IOutMaxUpper;           //12- Max current in 5V mode
  String connectorUpper;        //13- Upper connector type, A or C or NA
  uint16_t PDQCVMaxUpper;       //14- Max voltage to test in PD/QC mode. Valid voltages are 5,9,12,15,18,20. Others will cause errors
  float PDQCIMaxUpper;          //15- Test current at max PD/QC voltage
  String LEDColour;             //16- Indicator LED colour. Detectable colours are Red, Yellow, Green, Blue, Violet, White, Dark (ie no LED)
  uint16_t PDOsIndex;           //17- Row in PDOs array with the PD config data for this product. Multiple products can be assigned the same row
  uint16_t DeratePDOsIndex;     //18- Row in PDOs array with the low voltage derated config data. Multiple products can be assigned the same row
  float connectorID;            //19- Ratio of resistor values in the divider on the daughterboard. High side value / low side value
  bool extraCapacitance;        //20- True = Tester will wait longer during reverse polarity test to ensure extra large unprotected input capacitance is charged
};    

struct productRange {
  const char*       name;
  const uint16_t*   items;
  const size_t      count;
};


extern productStruct products[];
extern productRange productRanges[];
extern uint16_t PDOsConfigs[][12];
//extern uint16_t connectorBoardIDs[][2];
extern const size_t nRanges;
extern const size_t nProducts;
extern const size_t nPDOConfigs;

bool validateProductRanges();
#endif

