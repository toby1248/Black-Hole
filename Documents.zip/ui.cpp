/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : ui.cpp
 * Description  : Functions to control the 20x4 LCD 
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */

 #include "ui.h"
 #include "productdata.h"
 #include "globaldefines.h"
 #include "database.h"
 #include <LiquidCrystal_PCF8574.h>
 #include <Arduino.h>
 
 LiquidCrystal_PCF8574 lcd(0x27);  // hardcoded LCD I2C address 0x27

uint16_t selectedRange;   // Index into productRanges[]
uint16_t selectedIndex;   // Index within the current range’s items[]


/**
 * @brief 
 * Print strings to the LCD with word wrapping and overflow prevention
 * 
 * @note 
 * - Passing a string as the only parameter (like `lcd.print(text)`) will cause this to wipe the display and print from the top row down.
 * - This function does NOT respect the cursor position outside of its own parameters.
 *
 * @param text         The string to be printed to the LCD.
 * @param startColumn  The starting column position on the LCD (0-based).
 * @param startRow     The starting row position on the LCD (0-based).
 * @param wipeDisplay  If true, clears the entire LCD before printing.
 *
 * Improvement to the standard `lcd.print(text)` function.
 * Parses the input text word by word, wrapping lines automatically when a word exceeds the remaining space.
 * It also handles explicit line break characters (`\n`) and prevents overflow beyond the LCD's row and column limits.
 */
void printToLCD(String text, int startColumn, int startRow, bool wipeDisplay) {
  if (wipeDisplay) {
    lcd.clear();
  }
  
  uint8_t row = startRow;
  uint8_t col = startColumn;
  String word;

  for (unsigned int i = 0; i <= text.length(); i++) {
    char c = text[i];

    // Handle line breaking
    if (c == '\n' || word.length() == LCD_COLS) {
      // Print any pending word before breaking line
      if (word.length() > 0) {
        if (col + word.length() > LCD_COLS) {
          row++;
          col = 0;
        }
        if (row >= LCD_ROWS) break;
        lcd.setCursor(col, row);
        lcd.print(word);
        col += word.length();
        word = "";
      }
      row++;
      col = 0;
      if (row >= LCD_ROWS) break;
      continue;
    }

    // Assemble word
    if (c != ' ' && c != '\0') {
      word += c;
    }

    // Word boundary
    if (c == ' ' || c == '\0') {
      if (word.length() > 0) {
        if (col + word.length() > LCD_COLS) {
          row++;
          col = 0;
        }
        if (row >= LCD_ROWS) break;
        lcd.setCursor(col, row);
        lcd.print(word);
        col += word.length();
        word = "";
      }

      // Print space if not end of string
      if (c == ' ' && col < LCD_COLS) {
        lcd.setCursor(col, row);
        lcd.print(" ");
        col++;
      }
    }
  }
}

//Starts up the LCD and enables the backlight
void initialiseLCD(){
    lcd.begin(LCD_COLS, LCD_ROWS);
    delay(10);
    lcd.setBacklight(255);
    printToLCD("Universal USB tester Starting....");
}


/**
 * @brief Selects a new product range based on directional input.
 *
 * @param direction  Direction of navigation (-1 for left, +1 for right).
 */
uint16_t selectRange(int direction) {
  selectedRange = (selectedRange + nRanges + direction) % nRanges;
  selectedIndex = 0;          // reset product selection
  lastActionTime = millis();
  needsRefresh = true;
  return selectedRange;
}


/**
 * @brief Selects a product within the currently active range.
 *
 * @param direction  Direction of navigation (-1 for up, +1 for down).
 *      
 */
uint16_t selectProduct(int direction) {
  auto cnt = productRanges[selectedRange].count;
  if(cnt == 0) return 0;

  selectedIndex = (selectedIndex + cnt + direction) % cnt;
  auto& r = productRanges[selectedRange];
  lastActionTime = millis();
  needsRefresh = true;
  return r.items[selectedIndex];
}

/**
 * @brief Y/N user selection interface for the LCD
 *
 * Prints Y and N on the bottom two rows of the LCD display without clearing any other content. 
 * Displays an arrow `<` next to Y or N
 * The arrow can be moved using the `UP` and `DOWN` buttons. The function returns when `OK` is pressed
 * It returns TRUE for Y and FALSE for N
 *      
 */
bool YNchoice(){
  bool choice = true;
  printToLCD("Y<\nN ", 0, 2, false);
  delay(500);
  while(digitalRead(OK)){
    
    if (digitalRead(UP) == LOW){
      choice = true;
      printToLCD("Y<\nN ", 0, 2, false);
      //delay(100);
    }
    if (digitalRead(DOWN) == LOW){
      choice = false;
      printToLCD("Y \nN<", 0, 2, false);
      //delay(100);
    }
  }
  return(choice);
}

/**
 * @brief Display a message on the LCD and wait for an input to continue
 *
 * @param message String to print on the LCD
 * @param delayMs Minimum pause duration before watching for inputs - default 1000ms
 * @param button  Button to watch for inputs - default OK
 *      
 */
void promptAndWait(const String& message, int delayMs, int button) {
  printToLCD(message);
  delay(delayMs);
  while (digitalRead(button) == HIGH) {}
}


/**
 * @brief Read plaintext product part number(s) from USB serial (barcode scanner)
 *
 * Reads available bytes from the primary Serial port and searches the
 * received data for exact matches against each entry in `products[]`.
 * If multiple matches are present the most recently-received (highest offset)
 * matching product index is returned. If no match is found 0 is returned.
 *
 * @return uint16_t Index into `products[]` (0 means no match)
 */
uint16_t readBarcodeProductIndex() {
  if (!Serial || !Serial.available()) return 0;

  // Read any available bytes into a local buffer (limit to reasonable size)
  const size_t BUF_LEN = 128;
  static char buf[BUF_LEN + 1];
  size_t pos = 0;
  unsigned long start = millis();
  // Read until no more data for a short timeout to collect multi-byte scans
  while (millis() - start < 50 && pos < BUF_LEN) {
    while (Serial.available() && pos < BUF_LEN) {
      int c = Serial.read();
      if (c < 0) break;
      // ignore CR/LF
      if (c == '\r' || c == '\n') continue;
      buf[pos++] = (char)c;
      start = millis(); // reset timeout on each received byte
    }
  }
  buf[pos] = '\0';
  const int MIN_LEN = 8; // per update: minimum barcode length
  if (pos < MIN_LEN) return 0;

  // Base sequence length to compare (first MIN_LEN characters)
  const int BASE_LEN = MIN_LEN;
  uint16_t bestIndex = 0; // 0 = no match per spec
  int bestOffset = -1;
  int bestExtraMatch = -1; // used to break ties: number of additional characters matched beyond BASE_LEN

  for (size_t off = 0; off + BASE_LEN <= pos; ++off) {
    char seq[129];
    int seqLen = (int)min((size_t)128, pos - off);
    memcpy(seq, buf + off, seqLen);
    seq[seqLen] = '\0';

    int matchCount = 0;
    uint16_t lastMatch = 0;
    int bestMatchExtraForThisSeq = -1;

    for (size_t i = 0; i < nProducts; ++i) {
      const String &pn = products[i].partNumber;
      if ((int)pn.length() < BASE_LEN) continue;

      // Compare the first BASE_LEN characters
      bool baseEqual = true;
      for (int k = 0; k < BASE_LEN; ++k) {
        if (pn[k] != seq[k]) { baseEqual = false; break; }
      }
      if (!baseEqual) continue;

      // Count how many additional characters beyond BASE_LEN also match inside seq
      int extraMatch = 0;
      int maxExtra = min((int)pn.length() - BASE_LEN, seqLen - BASE_LEN);
      for (int e = 0; e < maxExtra; ++e) {
        if (pn[BASE_LEN + e] == seq[BASE_LEN + e]) extraMatch++;
        else break;
      }

      matchCount++;
      lastMatch = (uint16_t)i;

      // Track the best extra-match for this sequence for tie-breaking
      if (extraMatch > bestMatchExtraForThisSeq) bestMatchExtraForThisSeq = extraMatch;
    }

    if (matchCount > 1) {
      Serial.print("Barcode ambiguous for code: ");
      Serial.println(String(seq).substring(0, BASE_LEN));
      // Attempt to resolve by choosing the product with the most extra match chars
      if (bestMatchExtraForThisSeq > 0) {
        // find the specific product with that extraMatch value
        for (size_t i = 0; i < nProducts; ++i) {
          const String &pn = products[i].partNumber;
          if ((int)pn.length() < BASE_LEN) continue;
          bool baseEqual = true;
          for (int k = 0; k < BASE_LEN; ++k) if (pn[k] != seq[k]) { baseEqual = false; break; }
          if (!baseEqual) continue;
          int extraMatch = 0;
          int maxExtra = min((int)pn.length() - BASE_LEN, seqLen - BASE_LEN);
          for (int e = 0; e < maxExtra; ++e) {
            if (pn[BASE_LEN + e] == seq[BASE_LEN + e]) extraMatch++; else break;
          }
          if (extraMatch == bestMatchExtraForThisSeq) {
            lastMatch = (uint16_t)i;
            break;
          }
        }
      }
    }

    if (matchCount > 0) {
      // If this occurrence is later in the buffer (more recent), or ties but has more extra matches, take it
      if ((int)off > bestOffset || ((int)off == bestOffset && bestMatchExtraForThisSeq > bestExtraMatch)) {
        bestOffset = (int)off;
        bestIndex = lastMatch;
        bestExtraMatch = bestMatchExtraForThisSeq;
      }
    }
  }

  return bestIndex;
}

// -----------------------------------------------------------------------------
// Serial protocol controller and JSON streaming helpers
// -----------------------------------------------------------------------------

namespace {
  constexpr uint8_t CMD_ESCAPE = 0xA3; // '£'
  constexpr uint8_t DATA_ESCAPE = 0xA7; // '§'

  enum class SerialParseState : uint8_t {
    Idle,
    Command,
    Data
  };

  SerialParseState serialState = SerialParseState::Idle;
  String serialBuffer;
  bool loopModeEnabled = false;
  uint8_t escapeRun = 0;
}

extern Database db;

static bool isWordBreak(uint8_t ch) {
  return ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r';
}

static void dispatchCommandToken(const String& token);
static void dispatchDataPacket(const String& payload);
static void handleProductDataUpload(const String& payload);
static void serialPrintEscaped(const String& value);
static void emitProductsJson();
static void emitRangesJson();
static void emitPdoJson();

void pollSerialController() {
  bool keepReading = true;
  while (keepReading && Serial.available()) {
    int incoming = Serial.read();
    if (incoming < 0) break;
    uint8_t byteVal = static_cast<uint8_t>(incoming);

    if (byteVal == CMD_ESCAPE) {
      escapeRun++;
      if (escapeRun >= 3) {
        loopModeEnabled = !loopModeEnabled;
        serialState = SerialParseState::Idle;
        serialBuffer = "";
        escapeRun = 0;
        continue;
      }
    } else {
      escapeRun = 0;
    }

    switch (serialState) {
      case SerialParseState::Idle:
        if (byteVal == CMD_ESCAPE) {
          serialState = SerialParseState::Command;
          serialBuffer = "";
        } else if (byteVal == DATA_ESCAPE) {
          serialState = SerialParseState::Data;
          serialBuffer = "";
        }
        break;

      case SerialParseState::Command:
        if (byteVal == CMD_ESCAPE || byteVal == DATA_ESCAPE) {
          dispatchCommandToken(serialBuffer);
          serialBuffer = "";
          serialState = (byteVal == CMD_ESCAPE) ? SerialParseState::Command : SerialParseState::Data;
          keepReading = loopModeEnabled;
        } else if (isWordBreak(byteVal)) {
          dispatchCommandToken(serialBuffer);
          serialBuffer = "";
          serialState = SerialParseState::Idle;
          keepReading = loopModeEnabled;
        } else {
          serialBuffer += static_cast<char>(byteVal);
        }
        break;

      case SerialParseState::Data:
        if (byteVal == CMD_ESCAPE || byteVal == DATA_ESCAPE) {
          dispatchDataPacket(serialBuffer);
          serialBuffer = "";
          serialState = (byteVal == CMD_ESCAPE) ? SerialParseState::Command : SerialParseState::Data;
        } else if (byteVal == '\n' || byteVal == '\r') {
          dispatchDataPacket(serialBuffer);
          serialBuffer = "";
          serialState = SerialParseState::Idle;
        } else {
          serialBuffer += static_cast<char>(byteVal);
        }
        break;
    }
  }
}

static void dispatchCommandToken(const String& token) {
  String cmd = token;
  cmd.trim();
  if (cmd.length() == 0) return;
  db.handleSerialCommands(cmd);
}

static void dispatchDataPacket(const String& payload) {
  String data = payload;
  data.trim();
  if (data.length() == 0) return;
  int delim = data.indexOf(':');
  String label = (delim >= 0) ? data.substring(0, delim) : data;
  label.trim();
  String body = (delim >= 0) ? data.substring(delim + 1) : "";

  if (label.equalsIgnoreCase("PRODUCTDATA")) {
    handleProductDataUpload(body);
  } else {
    Serial.write(DATA_ESCAPE);
    Serial.print("{\"warn\":\"UNHANDLED_DATA\",\"label\":\"");
    serialPrintEscaped(label);
    Serial.println("\"}");
  }
}

static void handleProductDataUpload(const String& payload) {
  Serial.write(DATA_ESCAPE);
  Serial.print("{\"ack\":\"PRODUCTDATA\",\"bytes\":");
  Serial.print(payload.length());
  Serial.println("}");
}

void streamProductTablesAsJson() {
  Serial.write(DATA_ESCAPE);
  Serial.print('{');
  Serial.print("\"products\":");
  emitProductsJson();
  Serial.print(',');
  Serial.print("\"ranges\":");
  emitRangesJson();
  Serial.print(',');
  Serial.print("\"pdo\":");
  emitPdoJson();
  Serial.println("}");
}

static void serialPrintEscaped(const String& value) {
    for (size_t i = 0; i < value.length(); ++i) {
      char c = value[i];
      switch (c) {
        case '\\': Serial.print("\\\\"); break;
        case '"': Serial.print("\\\""); break;
        case '\n': Serial.print("\\n"); break;
        case '\r': Serial.print("\\r"); break;
        case '\t': Serial.print("\\t"); break;
        default:
          if (static_cast<uint8_t>(c) < 0x20) {
            Serial.print("\\u00");
            uint8_t v = static_cast<uint8_t>(c);
            if (v < 16) Serial.print('0');
            Serial.print(v, HEX);
          } else {
            Serial.print(c);
          }
      }
    }
  }

static void emitProductsJson() {
    Serial.print('[');
    for (size_t i = 0; i < nProducts; ++i) {
      const auto& p = products[i];
      if (i) Serial.print(',');
      Serial.print('{');
      Serial.print("\"idx\":"); Serial.print(i);
      Serial.print(",\"part\":\""); serialPrintEscaped(p.partNumber); Serial.print("\"");
      Serial.print(",\"hasPD\":"); Serial.print(p.hasPD ? "true" : "false");
      Serial.print(",\"hasQC\":"); Serial.print(p.hasQC ? "true" : "false");
      Serial.print(",\"is24V\":"); Serial.print(p.Is24VoltOnly ? "true" : "false");
      Serial.print(",\"vOutMaxLower\":"); Serial.print(p.VOutMaxLower, 3);
      Serial.print(",\"vOutMinLower\":"); Serial.print(p.VOutMinLower, 3);
      Serial.print(",\"iOutMaxLower\":"); Serial.print(p.IOutMaxLower, 3);
      Serial.print(",\"connectorLower\":\""); serialPrintEscaped(p.connectorLower); Serial.print("\"");
      Serial.print(",\"pdVMaxLower\":"); Serial.print(p.PDQCVMaxLower);
      Serial.print(",\"pdIMaxLower\":"); Serial.print(p.PDQCIMaxLower, 3);
      Serial.print(",\"vOutMaxUpper\":"); Serial.print(p.VOutMaxUpper, 3);
      Serial.print(",\"vOutMinUpper\":"); Serial.print(p.VOutMinUpper, 3);
      Serial.print(",\"iOutMaxUpper\":"); Serial.print(p.IOutMaxUpper, 3);
      Serial.print(",\"connectorUpper\":\""); serialPrintEscaped(p.connectorUpper); Serial.print("\"");
      Serial.print(",\"pdVMaxUpper\":"); Serial.print(p.PDQCVMaxUpper);
      Serial.print(",\"pdIMaxUpper\":"); Serial.print(p.PDQCIMaxUpper, 3);
      Serial.print(",\"ledColour\":\""); serialPrintEscaped(p.LEDColour); Serial.print("\"");
      Serial.print(",\"pdoIndex\":"); Serial.print(p.PDOsIndex);
      Serial.print(",\"derateIndex\":"); Serial.print(p.DeratePDOsIndex);
      Serial.print(",\"connectorId\":"); Serial.print(p.connectorID, 3);
      Serial.print(",\"extraCap\":"); Serial.print(p.extraCapacitance ? "true" : "false");
      Serial.print('}');
    }
    Serial.print(']');
  }

static void emitRangesJson() {
    Serial.print('[');
    for (size_t r = 0; r < nRanges; ++r) {
      if (r) Serial.print(',');
      Serial.print('{');
      Serial.print("\"idx\":"); Serial.print(r);
      Serial.print(",\"name\":\""); serialPrintEscaped(String(productRanges[r].name)); Serial.print("\"");
      Serial.print(",\"items\":[");
      for (size_t j = 0; j < productRanges[r].count; ++j) {
        if (j) Serial.print(',');
        Serial.print(productRanges[r].items[j]);
      }
      Serial.print("]}");
    }
    Serial.print(']');
  }

static void emitPdoJson() {
    Serial.print('[');
    for (size_t idx = 0; idx < nPDOConfigs; ++idx) {
      if (idx) Serial.print(',');
      Serial.print('{');
      Serial.print("\"idx\":"); Serial.print(idx);
      Serial.print(",\"values\":[");
      for (uint8_t col = 0; col < 12; ++col) {
        if (col) Serial.print(',');
        Serial.print(PDOsConfigs[idx][col]);
      }
      Serial.print("]}");
    }
    Serial.print(']');
  }