/*
 * =============================================================================
 * Project      : USB Universal Tester
 * File         : ui.h
 * Description  : Functions to control the 20x4 LCD
 * Author       : Toby Mardlin 
 * 
 *   Date       | Author            | Comments
 * -----------------------------------------------------------------------------
 * 2025-08-09   | Toby Mardlin      | Initial release
 *              |                   |
 * =============================================================================
 */

#ifndef UI_H
#define UI_H

#include <LiquidCrystal_PCF8574.h>
#include <stdint.h>
#include "globaldefines.h"
 #include "database.h"



extern bool needsRefresh;
extern unsigned long lastActionTime;



void printToLCD(String text, int startColumn = 0, int startRow = 0, bool wipeDisplay = true);

uint16_t selectRange(int direction);

uint16_t selectProduct(int direction);

void initialiseLCD();

bool YNchoice();

void promptAndWait(const String& message, int delayMs = 1000, int button = OK);

// Read barcode scanner input from USB serial and return matching product index
// Returns 0 if no match. If multiple product numbers are present in the
// buffer, returns the index for the most recent valid match.
uint16_t readBarcodeProductIndex();

void pollSerialController();

void streamProductTablesAsJson();

#endif